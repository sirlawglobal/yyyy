// const loginForm = document.getElementById("form");

// var authUser = JSON.parse(window.localStorage.getItem('admin'));
// window.onload = function(){
//     if(authUser){
//         history.back();
//     }
// }
// var serverUrl = "https://backend.osheacrm.com/request.php";
// const validateForm = (e) => {
//     e.preventDefault();
//     const username = document.getElementById('username').value
//     const password = document.getElementById('password').value
//     var loginBtn = document.getElementById('login-btn');
//     var msg = document.getElementById('error-message');
    
//     if (username === ''){
//         const usernameError = document.getElementById('username-error');
//         usernameError.innerHTML = 'Please input your username';
//     }else {
//         const usernameError = document.getElementById('username-error');
//         usernameError.innerHTML = '';
//     }
//     if (password === '') {
//         const passwordError = document.getElementById('password-error');
//         passwordError.innerHTML = 'Please input your password';
//     }else {
//         const passwordError = document.getElementById('password-error');
//         passwordError.innerHTML = '';
//     }
//     if (username !== '' && password !== ''  ) {
//         var formData = new FormData();
//         formData.append('username', username);
//         formData.append('password', password);
//         loginBtn.disabled = true;
//         loginBtn.innerHTML = "Logging in...";
//         var xhttp = new XMLHttpRequest();
//         xhttp.onload = function(){
//             document.getElementById('form').reset();
//             loginBtn.disabled = false;
//             loginBtn.innerHTML = "Login";
//             var response = JSON.parse(xhttp.response);
//             if(response.user){
//                 window.localStorage.setItem('admin', JSON.stringify(response.user));
//                 window.location.href = './dashboard/dashboard.html';
//             }
//             else{
//                 msg.innerHTML = response.error;
//                 msg.style.marginTop = "180px";
                
//             }
//         }
//         xhttp.onerror = function(error){
//             loginBtn.disabled = false;
//             loginBtn.innerHTML = "Login";
//             msg.innerHTML = "An error occured, try again!";
//             msg.style.marginTop = "180px";
//         }
//         xhttp.open("POST", serverUrl+'?function=admin-login', true);
//         xhttp.send(formData);
//     }

// }
// loginForm.addEventListener('submit', validateForm)