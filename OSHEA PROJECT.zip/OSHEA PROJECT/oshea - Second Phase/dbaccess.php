<?php

//fetch a data from backend
$worksites = $db->get('worksite');

$saveData = [
    'username'=>$name,
    'phone'=>$phone
];

$save = $db->insert('users', $saveData);
if($save){
    echo json_encode(['projects'=>$projects]);
}else{
    
}


//For update
$saveData = [
    'username'=>$name,
    'phone'=>$phone
];//table,user, id
$save = $db->update('users', $saveData, $id);
if($save){
    echo json_encode(['projects'=>$projects]);
}else{
    
}


//DELETE...
// delete takes in two parameters
// table name and id
$db->delete('worksite_2', $_POST['worksite_id']);
 echo json_encode(['success'=>"Data deleted successfully!"]);



