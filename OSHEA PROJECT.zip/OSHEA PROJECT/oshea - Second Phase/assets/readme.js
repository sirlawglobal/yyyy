function updateContact(contact_id){
    var modal = document.getElementById('myModal');
    var openModalBtn = document.getElementById("save-btn");
    
    // var contactId = document.getElementById("contactID").value;
    var contactName = document.getElementById("contactName").value;
    var company_name = document.getElementById("company_name").value;
    var position = document.getElementById("position").value;
    var address = document.getElementById("address").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var source = document.getElementById("source").value;
    var modifiedDate = document.getElementById("modifiedDate").value;
    var status = document.getElementById("status").value;
    
    if(contactName == ''){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
        formData.append('contactName', contactName);
        formData.append('company_name', company_name);
        formData.append('position', position);
        formData.append('address', address);
        formData.append('email', email);
        formData.append('phone', phone);
        formData.append('source', source);
        formData.append('modifiedDate', modifiedDate);
        formData.append('status', status);
        formData.append('contact_id', contact_id);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Updating...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            document.getElementById('form-edit').reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
            }
            else{
                swal('Sorry', response.error, 'error');
                
            }
            getContacts();
        }
        xhttp.onerror = function(error){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=update-contact', true);
        xhttp.send(formData);
    }
}
