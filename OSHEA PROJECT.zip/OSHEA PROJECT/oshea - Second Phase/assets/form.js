var projectOptionsContainer;
var clickedBtn;
function showOngoingProjectOptions(product_id){
    projectOptionsContainer = document.getElementById('ongoing-project-'+product_id);
    clickedBtn = document.getElementById('clicked-btn-'+product_id);
    projectOptionsContainer.style.display = "block";
}

var projectOptionsContainer2;
var clickedBtn2;
function showCompletedProjectOptions(product_id){
    projectOptionsContainer2 = document.getElementById('completed-project-'+product_id);
    clickedBtn2 = document.getElementById('completed-clicked-btn-'+product_id);
    projectOptionsContainer2.style.display = "block";
}


var projectOptionsContainer3;
var clickedBtn3;
function showPendingProjectOptions(product_id){
    projectOptionsContainer3 = document.getElementById('pending-project-'+product_id);
    clickedBtn3 = document.getElementById('pending-clicked-btn-'+product_id);
    projectOptionsContainer3.style.display = "block";
}
// document.addEventListener('click', (event)=>{
//     projectOptionsContainer = document.getElementById('pending-project-'+product_id);
//     var clickedElement = event.target;
//     if(!projectOptionsContainer.contains(clickedElement) && !clickedBtn.contains(clickedElement)){
//         projectOptionsContainer.style.display = "none";
//     }
    
//     if(!projectOptionsContainer2.contains(clickedElement) && !clickedBtn2.contains(clickedElement)){
//         projectOptionsContainer2.style.display = "none";
//     }
    
//     if(!projectOptionsContainer3.contains(clickedElement) && !clickedBtn3.contains(clickedElement)){
//         projectOptionsContainer3.style.display = "none";
//     }
// });



// New Screens for PROJECT MANAGEMENT
// Project Display
    

    const downloadButton = document.getElementById('download-button');

    const downloadButtonContent = `
        <div>
            <button id="show-options-download" onclick="showThingsDownload()" class="challenge-button" style="cursor: pointer;">
                Download 
                <svg width="15" height="10" viewBox="0 0 15 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M0 0L7.5 10L15 0H0Z" fill="#0047B3"/>
                </svg>
            </button>
            <div id="options-download" class="options-dropdown" style="display: none; ">
                <button onclick="" class="openModalBtnEdit option-button">
                    <img src="../assetsPeter/smaller-pdf.png"/> Pdf
                </button>
                <button onclick="" class="openModalBtnView option-button">
                    <img src="../assetsPeter/excel-icon.png" /> Excel
                </button>
            </div>
        </div>
    `;

    if (downloadButton) {
        downloadButton.innerHTML = downloadButtonContent;
    }



    const filterButton = document.getElementById('filter-button');

    const filterButtonContent = `
        <div>
            <button id="show-options-filter" onclick="showThingsFilter()" class="nav-btn" style="cursor: pointer;">
                Filter 
               
            </button>
            <div id="options-filter" class="options-dropdown" style="display: none; ">
                <button onclick="" class="openModalBtnEdit option-button">
                    Date
                </button>
                <button onclick="" class="openModalBtnView option-button">
                    Status
                </button>
            </div>
        </div>
    `;

    if (filterButton) {
        filterButton.innerHTML = filterButtonContent;
    }

    const i = 1
    const statusButton = document.getElementById('status-button');

    const statusButtonContent = `
        <div>
            <p id="show-options-${i}" onclick="showThings(${i})" class="status-text" style="cursor: pointer; ">
                Status 
            </p>
            <div id="options-${i}" class="options-dropdown2" style="display: none; right:5px">
                <button onclick="replaceNotResolved(${i})" class="openModalBtnEdit option-button not-resolved" id="not-resolved-${i}">
                    Not Yet Resolved
                </button>
                <button onclick="replaceInProgress(${i})" class="openModalBtnView option-button in-progress" id="in-progress-${i}">
                    In Progress
                </button>
                <button onclick="replaceResolved(${i})" class="openModalBtnView option-button resolved" id="resolved-${i}">
                    Resolved
                </button>
            </div>
        </div>
    `;

    if (statusButton) {
        statusButton.innerHTML = statusButtonContent;
    }
    
    function replaceNotResolved(indexNumber){
        const oldText = document.getElementById('show-options-'+indexNumber);
        const notResolved = document.getElementById('not-resolved-'+indexNumber)
        const getNewText = notResolved.innerText
        oldText.innerText = getNewText
         oldText.style.color = 'red'
    }

    function replaceInProgress(indexNumber){
        const oldText = document.getElementById('show-options-'+indexNumber);
        const inProgress = document.getElementById('in-progress-'+indexNumber)
        const getNewText = inProgress.innerText
        oldText.innerText = getNewText
        oldText.style.color = 'green'
    }

    function replaceResolved(indexNumber){
        const oldText = document.getElementById('show-options-'+indexNumber);
        const resolved = document.getElementById('resolved-'+indexNumber)
        const getNewText = resolved.innerText
        oldText.innerText = getNewText
        oldText.style.color = 'blue'
    }



var selectedIndex = "";
var globarOption;
var openOptionBtn;
function showThings(indexNumber) {
    selectedIndex = indexNumber;
    openOptionBtn = document.getElementById('show-options-'+indexNumber);
    globarOption= document.getElementById('options-'+indexNumber);
    globarOption.style.display = 'flex'
}
function showThingsDownload() {
   
    openOptionBtn = document.getElementById('show-options-download');
    globarOption= document.getElementById('options-download');
    globarOption.style.display = 'flex'
}
function showThingsFilter() {
   
    openOptionBtn = document.getElementById('show-options-filter');
    globarOption= document.getElementById('options-filter');
    globarOption.style.display = 'flex'
}
// document.addEventListener('click', function(event){
//     var clickedElement = event.target;
//     globarOption= document.getElementById('options-filter');
//     if(globarOption){
//         if(!globarOption.contains(clickedElement) && !openOptionBtn.contains(clickedElement)){
//             globarOption.style.display = 'none';
//         }
//     }
    
// });

function addProject(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Project</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Project Tile">Project Tile</label>
                        <input type="text" id="project_title" />
                    </div>
                    <div class="longer-form">
                        <label for="email">Email</label>
                        <input type="email" id="email" />
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="start date">Start date</label>
                            <input type="date" id="start_date" />
                        </div>
                        <div class="single-form">
                            <label for="due date">Due Date</label>
                            <input type="date" id="end_date" name="end_date" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Project lead">Project Lead</label>
                            <input type="text" id="lead" />
                        </div>
                        <div class="single-form">
                            <label for="status">status</label>
                            <select id="status">
                                <option value=""></option>
                                <option value="Not Started">Not Started</option>
                                <option value="Pending">Pending</option>
                                <option value="On-Hold">On-Hold</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Priority">Priority</label>
                            <select id="priority">
                                <option value=""></option>
                                <option value="Urgent">Urgent</option>
                                <option value="High">High</option>
                                <option value="On-Hold">Normal</option>
                                <option value="In Progress">Low</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="completion">%Completion</label>
                            <input type="text" id="completion" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="cost">Cost</label>
                            <input type="text" id="cost" />
                        </div>
                        <div class="single-form">
                            <label for="level of supervision">Level Of Supervision</label>
                            <select id="supervision_level">
                                <option value=""></option>
                                <option value="Project Manager">Project Manager</option>
                                <option value="Project Engineer">Project Engineer</option>
                                <option value="Project Assignee">Project Assignee</option>
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="description">Description</label>
                         <textarea rows="10" id="description" cols="50"></textarea>
                    </div>
                    <div class="longer-form">
                        <label for="description">Remark</label>
                       <textarea rows="10" cols="50" id="remark"></textarea>
                    </div>
                    
                    
                    

                    <button type='button' class="edit-button" onclick="saveProject()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editProject(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Project Tile">Project Tile</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="email">Email</label>
                        <input type="email" />
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="start date">Start date</label>
                            <input type="date" />
                        </div>
                        <div class="single-form">
                            <label for="due date">Due Date</label>
                            <input type="date" id="address" name="address" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Project lead">Project Lead</label>
                            <input type="text" />
                        </div>
                        <div class="single-form">
                            <label for="status">status</label>
                            <select>
                                <option value=""></option>
                                <option value="Not Started">Not Started</option>
                                <option value="Pending">Pending</option>
                                <option value="On-Hold">On-Hold</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Priority">Priority</label>
                            <select>
                                <option value=""></option>
                                <option value="Urgent">Urgent</option>
                                <option value="High">High</option>
                                <option value="On-Hold">Normal</option>
                                <option value="In Progress">Low</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="completion">%Completion</label>
                            <input type="text" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="cost">Cost</label>
                            <input type="text" />
                        </div>
                        <div class="single-form">
                            <label for="level of supervision">Level Of Supervision</label>
                            <select>
                                <option value=""></option>
                                <option value="Project Manager">Project Manager</option>
                                <option value="Project Engineer">Project Engineer</option>
                                <option value="Project Assignee">Project Assignee</option>
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="description">Description</label>
                         <textarea rows="10" cols="50"></textarea>
                    </div>
                    <div class="longer-form">
                        <label for="description">Remark</label>
                       <textarea rows="10" cols="50"></textarea>
                    </div>
                    
                    
                    

                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function viewProject(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Project Tile">Project Tile</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="email">Email</label>
                        <input type="email" />
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="start date">Start date</label>
                            <input type="date" />
                        </div>
                        <div class="single-form">
                            <label for="due date">Due Date</label>
                            <input type="date" id="address" name="address" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Project lead">Project Lead</label>
                            <input type="text" />
                        </div>
                        <div class="single-form">
                            <label for="status">status</label>
                            <select>
                                <option value=""></option>
                                <option value="Not Started">Not Started</option>
                                <option value="Pending">Pending</option>
                                <option value="On-Hold">On-Hold</option>
                                <option value="In Progress">In Progress</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Priority">Priority</label>
                            <select>
                                <option value=""></option>
                                <option value="Urgent">Urgent</option>
                                <option value="High">High</option>
                                <option value="On-Hold">Normal</option>
                                <option value="In Progress">Low</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="completion">%Completion</label>
                            <input type="text" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="cost">Cost</label>
                            <input type="text" />
                        </div>
                        <div class="single-form">
                            <label for="level of supervision">Level Of Supervision</label>
                            <select>
                                <option value=""></option>
                                <option value="Project Manager">Project Manager</option>
                                <option value="Project Engineer">Project Engineer</option>
                                <option value="Project Assignee">Project Assignee</option>
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="description">Description</label>
                         <textarea rows="10" cols="50"></textarea>
                    </div>
                    <div class="longer-form">
                        <label for="description">Remark</label>
                       <textarea rows="10" cols="50"></textarea>
                    </div>
                    
                    
                    

                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}



function addActivity(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description">Task Description</label>
                        <input type="text" id="task_description"/>
                    </div>
                    <div class="longer-form">
                        <label for="Project Name">Project Name</label>
                        <input type="text" id="project_name"/>
                    </div>
                    <div class="longer-form">
                        <label for="Activity">Activity</label>
                        <input type="text" id="activity"/>
                    </div>
                    <div class="longer-form">
                        <label for="Expected Start Date">Expected Start Date</label>
                        <input type="date" id="expected_start_date"/>
                    </div>
                    <div class="longer-form">
                        <label for="Expected Finish Date">Expected Finish Date</label>
                        <input type="date" id="expected_finish_date"/>
                    </div>
                    <div class="longer-form">
                        <label for="Planned Activity%">Planned Activity%</label>
                        <input type="number" id="planned_activity_percentage"/>
                    </div>
                    <div class="longer-form">
                        <label for="Actual Activity%">Actual Activity%</label>
                        <input type="number" id="actual_activity_percentage"/>
                    </div>
                    <div class="longer-form">
                        <label for="Activity inProgress %">Activity inProgress %</label>
                        <input type="text" id="activity_in_progress"/>
                    </div>
                    <div class="longer-form">
                        <label for="Latest Expected Finish Date">Latest Expected Finish Date</label>
                        <input type="date" id="latest_finish_date"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" id="remark"/>
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Role/Schedular</label>
                        <input type="text" id="role_scheduler"/>
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select id="period">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    
                    
                    
                    

                    <button type='button' class="edit-button" onclick="saveActivityPhase_1()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function addActivity2(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" id="required_number1" />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" id="actual_number1" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of project Engineer">Name of project Engineer</label>
                        <input type="text" id="name_of_project_engineer" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" id="required_number_false" />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" id="actual_number_false" />
                    </div>
                     <div class="longer-form">
                        <label for="Name of contractor supervisor">Name of contractor supervisor</label>
                        <input type="text" id="name_of_contractor_supervisor" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" id="remarks" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period" >
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation" >
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                   
                    
                    

                    <button type='button' class="edit-button" onclick="saveActivityPhase_2()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function addActivity3(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Material Specification">Material Specification</label>
                        <input type="text" id="material_specification"/>
                    </div>
                    <div class="longer-form">
                        <label for="Requested/Requisition Number">Requested/Requisition Number</label>
                        <input type="text" id="requested_number"/>
                    </div>
                    <div class="longer-form">
                        <label for="Received/Delivery Number">Received/Delivery Number</label>
                        <input type="text" id="delivery_number"/>
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" id="date_recieved"/>
                    </div>
                    <div class="longer-form">
                        <label for="Utilized">Utilized</label>
                        <input type="text" id="utilized"/>
                    </div>
                     <div class="longer-form">
                        <label for="Date Outstanding">Date Outstanding</label>
                        <input type="date" id="date_outstanding"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" id="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Quality">Quality</label>
                        <input type="text" id="quality"/>
                    </div>
                    <div class="longer-form">
                        <label for="Accept/Reject">Accept/Reject</label>
                          <select id="accept_reject">
                            <option value=""></option>
                            <option value="Accept">Accept</option>
                            <option value="Reject">Reject</option>
                        </select>
                        
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation">
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <button type='button' class="edit-button" onclick="saveActivityPhase_1()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}


function addActivity4(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>

    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Mat. Requested/REQN NO">Mat. Requested/REQN NO</label>
                        <input type="text" id="Material_requested_number"/>
                    </div>
                    <div class="longer-form">
                        <label for="Types of Materials Requested">Types of Materials Requested</label>
                        <input type="text" id="types_of_materials_requested"/>
                    </div>
                    <div class="longer-form">
                        <label for="Mat Received/Del NO">Mat Received/Del NO</label>
                        <input type="text" id="material_received_number"/>
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Delivered By">Delivered By</label>
                        <input type="text" id="delivered_by"/>
                    </div>
                    <div class="longer-form">
                        <label for="Received By">Received By</label>
                        <input type="text" id="received_by"/>
                    </div>
                     <div class="longer-form">
                        <label for="Mat Inspection Remark">Mat Inspection Remark</label>
                        <input type="text" id="material_inspection_remark"/>
                    </div>
                     <div class="longer-form">
                        <label for="Qty. Mat Rejected at Site Remark">Qty. Mat Rejected at Site Remark</label>
                        <input type="text" id="qty_material_rejected_at_site_remark"/>
                    </div>
                     <div class="longer-form">
                        <label for="Mat Utilized">Mat Utilized</label>
                        <input type="text" id="material_utilized"/>
                    </div>
                     <div class="longer-form">
                        <label for="Outstanding Materials">Outstanding Materials</label>
                        <input type="text" id="outstanding_materials"/>
                    </div>
                     <div class="longer-form">
                        <label for="Date Outstanding">Date Outstanding</label>
                        <input type="date" id="date_outstanding" />
                    </div>
                     <div class="longer-form">
                        <label for="Bi- Weekly Remarks">Bi- Weekly Remarks</label>
                        <input type="text" id="bi_weekly_remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" id="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation">
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveActivityPhase_4()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}


function addActivity5(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Requisition Raised/ REQN NO">Requisition Raised/ REQN NO</label>
                        <input type="text" id="requisition_raised_reqn_number"/>
                    </div>
                    <div class="longer-form">
                        <label for="List Type of Tool/s Requested">List Type of Tool/s Requested</label>
                        <input type="text" id="list_type_of_tools_requested"/>
                    </div>
                    <div class="longer-form">
                        <label for="Tool Codes Tag">Tool Codes Tag</label>
                        <input type="text" id="tool_codes_tag"/>
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Received/Del No">Received/Del No</label>
                        <input type="text" id="received_del_no"/>
                    </div>
                    <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" id="date_received"/>
                    </div>
                     <div class="longer-form">
                        <label for="Delivered By">Delivered By</label>
                        <input type="text" id="delivered_by"/>
                    </div>
                     <div class="longer-form">
                        <label for="Received By">Received By</label>
                        <input type="text" id="received_by"/>
                    </div>
                     <div class="longer-form">
                        <label for="Inspection Remark at Delivery">Inspection Remark at Delivery</label>
                        <input type="text" id="Inspection_remark_at_delivery"/>
                    </div>
                     <div class="longer-form">
                        <label for="Use Status">Use Status</label>
                        <input type="text" id="use_status"/>
                    </div>
                     <div class="longer-form">
                        <label for="Date Returned">Date Returned</label>
                        <input type="date" id="date_returned"/>
                    </div>
                     <div class="longer-form">
                        <label for="Received By">Received By</label>
                        <input type="text" id="received_by" />
                    </div>
                     <div class="longer-form">
                        <label for="Bi- Weekly Remarks on Tools">Bi- Weekly Remarks on Tools</label>
                        <input type="text" id="bi_weekly_remarks_on_tools"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" id="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation">
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                    </div>
                    <button type='button' class="edit-button" onclick="saveActivityPhase_5()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}





function addWorksite(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description From Work Program">Task Description From Work Program</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Further Action">Further Action</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Close Out Date">Action Close Out Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select>
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewWorksite(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description From Work Program">Task Description From Work Program</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Further Action">Further Action</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Close Out Date">Action Close Out Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select>
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editWorksite(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description From Work Program">Task Description From Work Program</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Further Action">Further Action</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Close Out Date">Action Close Out Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select>
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function addPlannedScope(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewPlannedScope(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editPlannedScope(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function addPlannedScope2(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Weekly Schedule">Weekly Schedule</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewPlannedScope2(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Weekly Schedule">Weekly Schedule</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editPlannedScope2(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Daily Task">Daily Task</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Weekly Schedule">Weekly Schedule</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Start Date">Start Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Week">Week</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Phasing">% of Phasing</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Available">Contract Available</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract Number">Contract Number</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Contract End Date">Contract End Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="PO NO">PO NO</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Day">Day</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Duration">Duration</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="End Date">End Date</label>
                        <input type="date" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

// WORKSITE2

function addWorksite2(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Activity Description From Work Program">Activity Description From Work Program</label>
                        <input type="text" name="description" />
                    </div>
                    <div class="longer-form">
                        <label for="Expected Delivery Date">Expected Delivery Date</label>
                        <input type="date" name="delivery_date" />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" name="done_percentage" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Work In Progress">% of Work In Progress</label>
                        <input type="text" name="work_in_progress" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" name="remark" />
                    </div>
                    <div class="longer-form">
                        <label for="Issues to Address">Issues to Address</label>
                        <input type="text" name="address" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" name="action_party" />
                    </div>
                    <div class="longer-form">
                        <label for="Action close out Date">Action close out Date</label>
                        <input type="date" name="action_close_date" />
                    </div>
                    <div class="longer-form">
                        <label for="Next Step to Close Out">Next Step to Close Out</label>
                        <input type="text" name="next_step" />
                    </div>

                     <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select name="period">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge">
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveWorkSite2()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}


// Issue.html

function addIssue(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Date written/Observed">Date written/Observed</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of Writers">Name of Writers</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Priority">Priority</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Status">Status</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Taken">Action Taken</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Date">Action Date</label>
                        <input type="date" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Close out Date">Close out Date</label>
                        <input type="date" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Issues/Compliants">Issues/Compliants</label>
                        <input type="text" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Demands">Demands</label>
                        <input type="text" />
                    </div>

                    <div class="longer-form">
                        <label for="Contract No">Contract No</label>
                        <input type="text" />
                    </div>
                    
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editIssue(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Date written/Observed">Date written/Observed</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of Writers">Name of Writers</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Priority">Priority</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Status">Status</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Taken">Action Taken</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Date">Action Date</label>
                        <input type="date" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Close out Date">Close out Date</label>
                        <input type="date" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Issues/Compliants">Issues/Compliants</label>
                        <input type="text" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Demands">Demands</label>
                        <input type="text" />
                    </div>

                    <div class="longer-form">
                        <label for="Contract No">Contract No</label>
                        <input type="text" />
                    </div>
                    
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function viewIssue(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Date written/Observed">Date written/Observed</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of Writers">Name of Writers</label>
                        <input type="text" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Priority">Priority</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Status">Status</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Taken">Action Taken</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Date">Action Date</label>
                        <input type="date" />
                    </div>
                     <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" />
                    </div>
                     <div class="longer-form">
                        <label for="Close out Date">Close out Date</label>
                        <input type="date" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Issues/Compliants">Issues/Compliants</label>
                        <input type="text" />
                    </div>
                    
                    <div class="longer-form">
                        <label for="Demands">Demands</label>
                        <input type="text" />
                    </div>

                    <div class="longer-form">
                        <label for="Contract No">Contract No</label>
                        <input type="text" />
                    </div>
                    
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select>
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

// Activity 3

function navigateToActivity() {
    var select = document.getElementById("period");
    var selectedValue = select.value;
    if (selectedValue) {
        window.location.href = selectedValue;
    }
}

function challengeForm(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Challenge Form</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Name">Name</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Department">Department</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Date">Date</label>
                        <input type="date" />
                    </div>
                    <div class="longer-form">
                        <label for="Challenge">Challenge</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Escalate to">Escalate to</label>
                        <input type="text" />
                    </div>
                    <div class="longer-form">
                        <label for="Comment">Comment</label>
                        <input type="text" />
                    </div>
                    
                    <button type='button' class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}



// Project Audit


function addAudit(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Project Audit</h3>
            </div>
            <form id="form">
                    
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="attribute">Attribute</label>
                            <textarea id="attribute" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="relevance">Relevance</label>
                            <textarea id="relevance" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="practice">Practice</label>
                            <textarea id="practice" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="assessment">Assessment</label>
                            <textarea id="assessment" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="saveAudit()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveAudit(){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
 
    var attribute = document.getElementById("attribute").value;
    var relevance = document.getElementById("relevance").value;
    var practice = document.getElementById("practice").value;
    var assessment = document.getElementById("assessment").value;
    if(attribute == '' && relevance == '' && practice == '' && assessment == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
    
        formData.append('attribute', attribute);
        formData.append('relevance', relevance);
        formData.append('practice', practice);
        formData.append('assessment', assessment);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               getAudit();
            }
            else{
                swal('Sorry', response.error, 'error');
            }
            // getContacts();
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-audit', true);
        xhttp.send(formData);
    }
    
    
}

var auditData = [];
function getAudit(){
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        auditData = response.audit;
        loopAudit(auditData);
    }
    xhttp.open("GET", serverUrl+'?function=get-audit');
    xhttp.send();
}

getAudit();

function loopAudit(data){
    var container = document.getElementById('audit-body');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){

        data.sort(function(a, b) {
            return parseInt(a.order_num) - parseInt(b.order_num);
        });

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                <td class="border-line">${'1000'+counter}</td>
                <td class="border-line" colspan="2">${data[i].attribute}</td>
                <td class="border-line">${data[i].relevance}</td>
                <td class="border-line">${data[i].practice}</td>
                <td class="border-line">${data[i].assessment}</td>
                <td class="border-line">
                    <div class="relative-position">
                        <button onclick="showOptions(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id="${i}" class="options-dropdown" style="right: 5px;">
                            <button onclick="addRowUnder(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img  src="../assetsPeter/add-icon.png"/> Add Row Under
                            </button>
                            <button onclick="editAudit(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewAudit(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteAudit(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function viewAudit(i){
    const data = auditData.filter(f => parseInt(f.id) == parseInt(i));
    console.log('data audit', data);
    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Project Audit</h3>
            </div>
            <form id="form">
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="attribute">Attribute</label>
                            <textarea  id="attribute" cols="4" rows="6" readonly>${data[0].attribute}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="relevance">Relevance</label>
                            <textarea  id="relevance" cols="4" rows="6" readonly>${data[0].relevance}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="practice">Practice</label>
                            <textarea  id="practice" cols="4" rows="6" readonly>${data[0].practice}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="assessment">Assessment</label>
                            <textarea  id="assessment" cols="4" rows="6" readonly>${data[0].assessment}</textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
              
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editAudit(i){
    const data = auditData.filter(f => parseInt(f.id) == parseInt(i));
    console.log('data audit', data);
    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Project Audit</h3>
            </div>
            <form id="form">
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="attribute">Attribute</label>
                            <textarea  id="attribute" cols="4" rows="6">${data[0].attribute}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="relevance">Relevance</label>
                            <textarea  id="relevance" cols="4" rows="6">${data[0].relevance}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="practice">Practice</label>
                            <textarea  id="practice" cols="4" rows="6">${data[0].practice}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="assessment">Assessment</label>
                            <textarea  id="assessment" cols="4" rows="6">${data[0].assessment}</textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="updateAudit(${data[0].id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateAudit(i){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'updating...';
    savebtn.disabled = true;
    var id = i
    var attribute = document.getElementById('attribute').value;
    var relevance = document.getElementById('relevance').value;
    var practice = document.getElementById('practice').value;
    var assessment = document.getElementById('assessment').value;

    
    var formData = new FormData();
    formData.append('attribute', attribute);
    formData.append('relevance', relevance);
    formData.append('practice', practice);
    formData.append('assessment', assessment);
    formData.append('id', id);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        form.reset();
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getAudit();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-audit', true);
    xhttp.send(formData);
}

function deleteAudit(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getAudit();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-audit', true);
            xhttp.send(formData);
        }
      });
}

function addRowUnder(i){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Project Audit</h3>
            </div>
            <form id="form">
                    
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="attribute">Attribute</label>
                            <textarea id="attribute" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="relevance">Relevance</label>
                            <textarea id="relevance" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="practice">Practice</label>
                            <textarea id="practice" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="assessment">Assessment</label>
                            <textarea id="assessment" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="saveUnderRowAudit(${i})" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveUnderRowAudit(i){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
    
    var id = i;
    var attribute = document.getElementById("attribute").value;
    var relevance = document.getElementById("relevance").value;
    var practice = document.getElementById("practice").value;
    var assessment = document.getElementById("assessment").value;
    if(attribute == '' && relevance == '' && practice == '' && assessment == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
    
        formData.append('id', id);
        formData.append('attribute', attribute);
        formData.append('relevance', relevance);
        formData.append('practice', practice);
        formData.append('assessment', assessment);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               getAudit();
            }
            else{
                swal('Sorry', response.error, 'error');
            }
            // getContacts();
        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-under-audit', true);
        xhttp.send(formData);
    }
}

// Task Hazard
function addTaskHazard(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Task Hazard</h3>
            </div>
            <form id="form">
                    
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="task_breakdown">Task Breakdown</label>
                            <textarea id="task_breakdown" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="hazard_threat">Hazard/ Threat</label>
                            <textarea id="hazard_threat" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls">Controls</label>
                            <textarea id="controls" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="responsible_person">Responsible Person To Take Action</label>
                            <textarea id="responsible_person" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls_in_place">Controls in Place</label>
                            <textarea id="controls_in_place" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="saveTaskHazard()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveTaskHazard(){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
 
    var task_breakdown = document.getElementById("task_breakdown").value;
    var hazard_threat = document.getElementById("hazard_threat").value;
    var controls = document.getElementById("controls").value;
    var responsible_person = document.getElementById("responsible_person").value;
    var controls_in_place = document.getElementById("controls_in_place").value;
    if(task_breakdown == '' && hazard_threat == '' && controls == '' && responsible_person == '' && controls_in_place == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();

    
        formData.append('task_breakdown', task_breakdown);
        formData.append('hazard_threat', hazard_threat);
        formData.append('controls', controls);
        formData.append('responsible_person', responsible_person);
        formData.append('controls_in_place', controls_in_place);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
          
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
                getTaskHazard();
            }
            else{
                swal('Sorry', response.error, 'error');
            }

        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-task-hazard', true);
        xhttp.send(formData);
    }
    
    
}

var taskHazardData = [];
function getTaskHazard(){
  
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        taskHazardData = response.task;
     
        loopTaskHazard(taskHazardData);
    }
    xhttp.open("GET", serverUrl+'?function=get-task-hazard');
    xhttp.send();
}

getTaskHazard();
 
function loopTaskHazard(data){
    var container = document.getElementById('task-hazard-body');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        data.sort(function(a, b) {
            return parseInt(a.order_num) - parseInt(b.order_num);
        });

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                <td class="border-line">${'Step' + counter}</td>
                <td class="border-line">${data[i].task_breakdown}</td>
                <td class="border-line">${data[i].hazard_threat}</td>
                <td class="border-line">${data[i].controls}</td>
                <td class="border-line">${data[i].responsible_person}</td>
                <td class="border-line">${data[i].controls_in_place}</td>
                <td class="border-line">
                    <div class="relative-position">
                        <button onclick="showOptions(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id="${i}" class="options-dropdown" style="right: 5px;">
                            <button onclick="addRowUnder(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img  src="../assetsPeter/add-icon.png"/> Add Row Under
                            </button>
                            <button onclick="editTaskHazard(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewTaskHazard(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteTaskHazard(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function editTaskHazard(i){
    const data = taskHazardData.filter(f => parseInt(f.id) == parseInt(i));
    console.log('data', data); 
    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Task Hazard</h3>
            </div>
            <form id="form">
                      <div class="double-form">
                        <div class="longer-form">
                            <label for="task_breakdown">Task Breakdown</label>
                            <textarea id="task_breakdown" cols="4" rows="6">${data[0].task_breakdown}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="hazard_threat">Hazard/ Threat</label>
                            <textarea id="hazard_threat" cols="4" rows="6">${data[0].hazard_threat}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls">Controls</label>
                            <textarea id="controls" cols="4" rows="6">${data[0].controls}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="responsible_person">Responsible Person To Take Action</label>
                            <textarea id="responsible_person" cols="4" rows="6">${data[0].responsible_person}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls_in_place">Controls in Place</label>
                            <textarea id="controls_in_place" cols="4" rows="6">${data[0].controls_in_place}</textarea>
                        </div>
                    </div>
                    
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="updateTaskHazard(${data[0].id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function viewTaskHazard(i){
    const data = taskHazardData.filter(f => parseInt(f.id) == parseInt(i));
    console.log('data', data);
    
    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Task Hazard</h3>
            </div>
            <form id="form">
                      <div class="double-form">
                        <div class="longer-form">
                            <label for="task_breakdown">Task Breakdown</label>
                            <textarea id="task_breakdown" cols="4" rows="6" readonly>${data[0].task_breakdown}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="hazard_threat">Hazard/ Threat</label>
                            <textarea id="hazard_threat" cols="4" rows="6" readonly>${data[0].hazard_threat}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls">Controls</label>
                            <textarea id="controls" cols="4" rows="6" readonly>${data[0].controls}</textarea>
                        </div>
                        <div class="longer-form">
                            <label for="responsible_person">Responsible Person To Take Action</label>
                            <textarea id="responsible_person" cols="4" rows="6" readonly>${data[0].responsible_person}</textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls_in_place">Controls in Place</label>
                            <textarea id="controls_in_place" cols="4" rows="6" readonly>${data[0].controls_in_place}</textarea>
                        </div>
                    </div>
                
                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateTaskHazard(i){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'updating...';
    savebtn.disabled = true;
    var id = parseInt(i)
    var task_breakdown = document.getElementById('task_breakdown').value;
    var hazard_threat = document.getElementById('hazard_threat').value;
    var controls = document.getElementById('controls').value;
    var responsible_person = document.getElementById('responsible_person').value;
    var controls_in_place = document.getElementById('controls_in_place').value;

    
    var formData = new FormData();
    formData.append('task_breakdown', task_breakdown);
    formData.append('hazard_threat', hazard_threat);
    formData.append('controls', controls);
    formData.append('responsible_person', responsible_person);
    formData.append('controls_in_place', controls_in_place);
    formData.append('id', id);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        form.reset();
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getTaskHazard();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-task-hazard', true);
    xhttp.send(formData);
}

function deleteTaskHazard(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
         
                    swal('Hurray', response.success, 'success');
                    getTaskHazard();
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-task-hazard', true);
            xhttp.send(formData);
        }
      });
}

function addRowUnder(i){
    alert(i)
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Project Audit</h3>
            </div>
            <form id="form">
                    
                   <div class="double-form">
                        <div class="longer-form">
                            <label for="task_breakdown">Task Breakdown</label>
                            <textarea id="task_breakdown" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="hazard_threat">Hazard/ Threat</label>
                            <textarea id="hazard_threat" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls">Controls</label>
                            <textarea id="controls" cols="4" rows="6"></textarea>
                        </div>
                        <div class="longer-form">
                            <label for="responsible_person">Responsible Person To Take Action</label>
                            <textarea id="responsible_person" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="controls_in_place">Controls in Place</label>
                            <textarea id="controls_in_place" cols="4" rows="6"></textarea>
                        </div>
                    </div>
                    
                   

                    <div class="error-container">
                        <p class="error-message"></p>
                    </div>
                    

                   
                    
                    <button type='button' class="edit-button" onclick="saveUnderRowTaskHazard(${i})" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveUnderRowTaskHazard(i){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
    
    var id = parseInt(i);
    var task_breakdown = document.getElementById("task_breakdown").value;
    var hazard_threat = document.getElementById("hazard_threat").value;
    var controls = document.getElementById("controls").value;
    var responsible_person = document.getElementById("responsible_person").value;
    var controls_in_place = document.getElementById("controls_in_place").value;
    if(task_breakdown == '' && hazard_threat == '' && controls == '' && responsible_person == '' && controls_in_place == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();

    
        formData.append('id', id);
        formData.append('task_breakdown', task_breakdown);
        formData.append('hazard_threat', hazard_threat);
        formData.append('controls', controls);
        formData.append('responsible_person', responsible_person);
        formData.append('controls_in_place', controls_in_place);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
          
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
                getTaskHazard();
            }
            else{
                swal('Sorry', response.error, 'error');
            }

        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-under-row-task-hazard', true);
        xhttp.send(formData);
    }
}

// Risk Identification

let chosen_file = null;
function onFileSelect(event){
    chosen_file = event.target.files[0];
    var url = URL.createObjectURL(chosen_file);
    var imageContent = `<img src="${url}" class="preview-image" />`;
    var previewContainer = document.getElementById('preview');
    previewContainer.innerHTML = imageContent;
}

function addRiskIdentification(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Risk Identification</h3>
            </div>
            <form id="form">
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="facility_project">Facility/Project</label>
                            <input id="facility_project" type="text" name="facility_project" />
                        </div>
                        <div class="longer-form">
                            <label for="location">Location/ Threat</label>
                            <input type="text" id="location" name="location" />
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="task">Task</label>
                            <input type="text" id="task" name="task" />
                        </div>
                        <div class="longer-form">
                            <label for="date">Date</label>
                            <input id="date" type="date" name="date" />
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="time">Time</label>
                            <input type="text" id="time" name="time" />
                        </div>
                        <div class="longer-form">
                            <label for="ptw_no">PTW No</label>
                            <input type="text" id="ptw_no" name="ptw_no" />
                        </div>
                    </div>
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="name">Name</label>
                            <input type="text" id="name"  />
                        </div>
                        <div class="longer-form">
                            <label for="signature">Signature</label>
                            <div class="add-signature">
                               
               
                                <input type='file' onchange="onFileSelect(event)" class="addbtn-signature" />
                                <div class="preview-signature">
                                    <div id="preview">Signature</div>
                                    <div class="signature-line"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                    <div class="longer-form">
                        <label for="tbm_leader">TBM Leader</label>
                        <input type="text" id="tbm_leader" name="tbm_leader" />
                    </div>
          
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                     <div class="double-form">
                        <div class="longer-form">
                            <label for="permit_holder">Permit Holder / Contract Supervisor</label>
                            <input type="text" id="permit_holder" name="permit_holder" />
                        </div>
                        <div class="longer-form">
                            <label for="project_supervisor">Project Supervisor</label>
                            <input type="text" id="project_supervisor" name="project_supervisor" />
                        </div>
                    </div>
                    <hr class="risk-hr">
                     <div class="attendee">
                        <h4 class="attendee-text">Action Required</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="update_work">Update work method statement</label>
                            <select id="update_work">
                                <option value=""></option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="longer-form">
                            <label for="update_plans">Update plans/procedures/JHA</label>
                            <select id="update_plans">
                                <option value=""></option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="feedback_others">Feedback/Others</label>
                        <textarea cols="4" rows="4" id="feedback_others"></textarea>
                    </div>
   
                    
                    <button type='button' class="edit-button" onclick="saveRiskIdentification()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveRiskIdentification(){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
 
    var facility_project = document.getElementById("facility_project").value;
    var location = document.getElementById("location").value;
    var task = document.getElementById("task").value;
    var date = document.getElementById("date").value;
    var time = document.getElementById("time").value;
    var ptw_no = document.getElementById("ptw_no").value;
    var name = document.getElementById("name").value;
    var tbm_leader = document.getElementById("tbm_leader").value;
    var permit_holder = document.getElementById("permit_holder").value;
    var project_supervisor = document.getElementById("project_supervisor").value;
    var update_work = document.getElementById("update_work").value;
    var update_plans = document.getElementById("update_plans").value;
    var feedback_others = document.getElementById("feedback_others").value;

   
    if(facility_project == '' && location == '' && task == '' && date == '' && time == '' && ptw_no == '' && name == '' && tbm_leader == '' && permit_holder == '' && project_supervisor == '' && update_work == '' && update_plans == '' && feedback_others == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();

    
        formData.append('facility_project', facility_project);
        formData.append('location', location);
        formData.append('task', task);
        formData.append('date', date);
        formData.append('time', time);
        formData.append('ptw_no', ptw_no);
        formData.append('name', name);
        formData.append('tbm_leader', tbm_leader);
        formData.append('permit_holder', permit_holder);
        formData.append('project_supervisor', project_supervisor);
        formData.append('update_work', update_work);
        formData.append('update_plans', update_plans);
        formData.append('feedback_others', feedback_others);
        formData.append('image', chosen_file);

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
          
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
               getRiskIdentification();

            }
            else{
                swal('Sorry', response.error, 'error');
            }

        }
        xhttp.onerror = function(error){
            // modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-risk-identification', true);
        xhttp.send(formData);
    }
    
    
}

var riskIdentificationData = [];
function getRiskIdentification(){
  
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        riskIdentificationData = response.risk;
     
        loopRiskIdentificationn(riskIdentificationData);
    }
    xhttp.open("GET", serverUrl+'?function=get-risk-identification');
    xhttp.send();
}

getRiskIdentification();


function loopRiskIdentificationn(data){
    var container = document.getElementById('risk-identification-body');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                <td class="border-line">${'100' + counter}</td>
                <td class="border-line">${data[i].facility_project}</td>
                <td class="border-line">${data[i].location}</td>
                <td class="border-line">${data[i].task}</td>
                <td class="border-line">${data[i].date}</td>
                <td class="border-line">${data[i].ptw_no}</td>
                <td class="border-line">${data[i].name}</td>
                <td class="border-line">${data[i].image}</td>
                <td class="border-line">
                    <div class="relative-position">
                        <button onclick="showOptions(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id="${i}" class="options-dropdown" style="right: 5px;">
                            <button onclick="editRiskIdentification(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewRiskIdentification(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteRiskIdentification(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}


function viewRiskIdentification(i){
    const data = riskIdentificationData.filter(f => parseInt(f.id) == parseInt(i));

    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Risk Identification</h3>
            </div>
            <form id="form">
                     <div class="double-form">
                        <div class="longer-form">
                            <label for="facility_project">Facility/Project</label>
                            <input value="${data[0].facility_project}" id="facility_project" type="text" name="facility_project" readonly/>
                        </div>
                        <div class="longer-form">
                            <label for="location">Location/ Threat</label>
                            <input value="${data[0].location}" type="text" id="location" name="location" readonly/>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="task">Task</label>
                            <input value="${data[0].task}" type="text" id="task" name="task" readonly/>
                        </div>
                        <div class="longer-form">
                            <label for="date">Date</label>
                            <input value="${data[0].date}" id="date" type="date" name="date" readonly/>
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="time">Time</label>
                            <input value="${data[0].time}" type="text" id="time" name="time" readonly/>
                        </div>
                        <div class="longer-form">
                            <label for="ptw_no">PTW No</label>
                            <input value="${data[0].ptw_no}" type="text" id="ptw_no" name="ptw_no" readonly/>
                        </div>
                    </div>
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="name">Name</label>
                            <input value="${data[0].name}" type="text" id="name"  readonly/>
                        </div>
                        <div class="longer-form">
                            <label for="signature">Signature</label>
                            <div class="add-signature">
                               
               
                                <input type='file' onchange="onFileSelect(event)" class="addbtn-signature" />
                                <div class="preview-signature">
                                    <div id="preview">Signature</div>
                                    <div class="signature-line"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                    <div class="longer-form">
                        <label for="tbm_leader">TBM Leader</label>
                        <input type="text" id="tbm_leader" name="tbm_leader" readonly/>
                    </div>
          
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                     <div class="double-form">
                        <div class="longer-form">
                            <label for="permit_holder">Permit Holder / Contract Supervisor</label>
                            <input value="${data[0].permit_holder}" type="text" id="permit_holder" name="permit_holder" readonly/>
                        </div>
                        <div class="longer-form">
                            <label for="project_supervisor">Project Supervisor</label>
                            <input value="${data[0].project_supervisor}" type="text" id="project_supervisor" name="project_supervisor" readonly/>
                        </div>
                    </div>
                    <hr class="risk-hr">
                     <div class="attendee">
                        <h4 class="attendee-text">Action Required</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="update_work">Update work method statement</label>
                            <select id="update_work">
                                <option value="${data[0].update_work}">${data[0].update_work}</option>
                
                            </select>
                        </div>
                        <div class="longer-form">
                            <label for="update_plans">Update plans/procedures/JHA</label>
                            <select id="update_plans">
                                <option value="${data[0].update_plans}">${data[0].update_plans}</option>
         
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="feedback_others">Feedback/Others</label>
                        <textarea  cols="4" rows="4" id="feedback_others" readonly>${data[0].feedback_others}</textarea>
                    </div>

                      
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editRiskIdentification(i){
    const data = riskIdentificationData.filter(f => parseInt(f.id) == parseInt(i));

    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Risk Identification</h3>
            </div>
            <form id="form">
                     <div class="double-form">
                        <div class="longer-form">
                            <label for="facility_project">Facility/Project</label>
                            <input value="${data[0].facility_project}" id="facility_project" type="text" name="facility_project" />
                        </div>
                        <div class="longer-form">
                            <label for="location">Location/ Threat</label>
                            <input value="${data[0].location}" type="text" id="location" name="location" />
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="task">Task</label>
                            <input value="${data[0].task}" type="text" id="task" name="task" />
                        </div>
                        <div class="longer-form">
                            <label for="date">Date</label>
                            <input value="${data[0].date}" id="date" type="date" name="date" />
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="time">Time</label>
                            <input value="${data[0].time}" type="text" id="time" name="time" />
                        </div>
                        <div class="longer-form">
                            <label for="ptw_no">PTW No</label>
                            <input value="${data[0].ptw_no}" type="text" id="ptw_no" name="ptw_no" />
                        </div>
                    </div>
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="name">Name</label>
                            <input value="${data[0].name}" type="text" id="name"  />
                        </div>
                        <div class="longer-form">
                            <label for="signature">Signature</label>
                            <div class="add-signature">
                               
               
                                <input type='file' onchange="onFileSelect(event)" class="addbtn-signature" />
                                <div class="preview-signature">
                                    <div id="preview">Signature</div>
                                    <div class="signature-line"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                 
                    <div class="longer-form">
                        <label for="tbm_leader">TBM Leader</label>
                        <input type="text" id="tbm_leader" name="tbm_leader" />
                    </div>
          
                    <hr class="risk-hr">
                    <div class="attendee">
                        <h4 class="attendee-text">Attendee: Member of Work Party</h4>
                    </div>
                     <div class="double-form">
                        <div class="longer-form">
                            <label for="permit_holder">Permit Holder / Contract Supervisor</label>
                            <input value="${data[0].permit_holder}" type="text" id="permit_holder" name="permit_holder" />
                        </div>
                        <div class="longer-form">
                            <label for="project_supervisor">Project Supervisor</label>
                            <input value="${data[0].project_supervisor}" type="text" id="project_supervisor" name="project_supervisor" />
                        </div>
                    </div>
                    <hr class="risk-hr">
                     <div class="attendee">
                        <h4 class="attendee-text">Action Required</h4>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="update_work">Update work method statement</label>
                            <select id="update_work">
                                <option value="${data[0].update_work}">${data[0].update_work}</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="longer-form">
                            <label for="update_plans">Update plans/procedures/JHA</label>
                            <select id="update_plans">
                                <option value="${data[0].update_plans}">${data[0].update_plans}</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                    </div>
                    <div class="longer-form">
                        <label for="feedback_others">Feedback/Others</label>
                        <textarea  cols="4" rows="4" id="feedback_others">${data[0].feedback_others}</textarea>
                    </div>

                       <button type='button' class="edit-button" onclick="updateRiskIdentification(${data[0].id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateRiskIdentification(i){
    var modal = document.getElementById('myModal');
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Updating...';
    savebtn.disabled = true;
    var id = parseInt(i)
    var facility_project = document.getElementById("facility_project").value;
    var location = document.getElementById("location").value;
    var task = document.getElementById("task").value;
    var date = document.getElementById("date").value;
    var time = document.getElementById("time").value;
    var ptw_no = document.getElementById("ptw_no").value;
    var name = document.getElementById("name").value;
    var tbm_leader = document.getElementById("tbm_leader").value;
    var permit_holder = document.getElementById("permit_holder").value;
    var project_supervisor = document.getElementById("project_supervisor").value;
    var update_work = document.getElementById("update_work").value;
    var update_plans = document.getElementById("update_plans").value;
    var feedback_others = document.getElementById("feedback_others").value;

    
    var formData = new FormData();
    formData.append('facility_project', facility_project);
    formData.append('location', location);
    formData.append('task', task);
    formData.append('date', date);
    formData.append('time', time);
    formData.append('ptw_no', ptw_no);
    formData.append('name', name);
    formData.append('tbm_leader', tbm_leader);
    formData.append('permit_holder', permit_holder);
    formData.append('project_supervisor', project_supervisor);
    formData.append('update_work', update_work);
    formData.append('update_plans', update_plans);
    formData.append('feedback_others', feedback_others);
    formData.append('image', chosen_file);
    formData.append('id', id);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        form.reset();
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getRiskIdentification();
        modal.style.display = 'none';
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
        modal.style.display = 'none';
    }
    xhttp.open('POST', serverUrl+'?function=update-risk-identification', true);
    xhttp.send(formData);
}

function deleteRiskIdentification(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
         
                    swal('Hurray', response.success, 'success');
                    getRiskIdentification();
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-risk-identification', true);
            xhttp.send(formData);
        }
      });
}

// Hazard/Risk Identification

function addHazardRiskIdentification(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Hazard/Risk Identification</h3>
            </div>
            <form id="form">
                <div class="longer-form">
                    <label for="work_involve">Work Involve</label>
                    <input type="text" id="work_involve" name="work_involve" />
                </div>
                <button type='button' class="edit-button" onclick="saveHazardRiskIdentification()" id="save-btn">Save</button>  
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveHazardRiskIdentification(){
    var modal = document.getElementById('myModal');
    var form = document.getElementById('form')
    var openModalBtn = document.getElementById("save-btn");
 
    var work_involve = document.getElementById("work_involve").value;

   
    if(work_involve == '' ){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();

    
        formData.append('work_involve', work_involve);

        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
          
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
            //    getHazardRiskIdentification();

            }
            else{
                swal('Sorry', response.error, 'error');
            }

        }
        xhttp.onerror = function(error){
          
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-hazard-risk-identification', true);
        xhttp.send(formData);
    }
    
    
}

var hazardRiskIdentificationData = [];
function getHazardRiskIdentification(){
  
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        hazardRiskIdentificationData = response.risk;
     
        loopHazardRiskIdentificationn(hazardRiskIdentificationData);
    }
    xhttp.open("GET", serverUrl+'?function=get-hazard-risk-identification');
    xhttp.send();
}

getHazardRiskIdentification();


function loopHazardRiskIdentificationn(data){
    var container = document.getElementById('hazard-risk-identification-body');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){

        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                <td class="border-line">${'100' + counter}</td>
                <td class="border-line">${data[i].work_involve}</td>
                <td class="border-line"><input type="radio" name="work-${i}"/></td>
                <td class="border-line"><input type="radio" name="work-${i}"/></td>
                <td class="border-line">
                    <div class="relative-position">
                        <button onclick="showOptions(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id="${i}" class="options-dropdown" style="right: 5px;">
                            <button onclick="editHazardRiskIdentification(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewHazardRiskIdentification(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteHazardRiskIdentification(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}

function viewHazardRiskIdentification(i){
    const data = hazardRiskIdentificationData.filter(f => parseInt(f.id) == parseInt(i));

    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Hazard Risk Identification</h3>
            </div>
            <form id="form">
                <div class="longer-form">
                    <label for="work_involve">Work Involve</label>
                    <input value="${data[0].work_involve}" type="text" id="work_involve" name="work_involve" readonly/>
                </div>
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function editHazardRiskIdentification(i){
    const data = hazardRiskIdentificationData.filter(f => parseInt(f.id) == parseInt(i));

    
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Hazard Risk Identification</h3>
            </div>
            <form id="form">
                <div class="longer-form">
                    <label for="work_involve">Work Involve</label>
                    <input value="${data[0].work_involve}" type="text" id="work_involve" name="work_involve" />
                </div>

                <button type='button' class="edit-button" onclick="updateHazardRiskIdentification(${data[0].id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function updateHazardRiskIdentification(i){
    var modal = document.getElementById('myModal');
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Updating...';
    savebtn.disabled = true;
    var id = parseInt(i)
    var work_involve = document.getElementById("work_involve").value;

    
    var formData = new FormData();
    formData.append('work_involve', work_involve);
    formData.append('id', id);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        form.reset();
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getHazardRiskIdentification();
        modal.style.display = 'none';
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
        modal.style.display = 'none';
    }
    xhttp.open('POST', serverUrl+'?function=update-hazard-risk-identification', true);
    xhttp.send(formData);
}

function deleteHazardRiskIdentification(i){
    const id = i;
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('id', id);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
         
                    swal('Hurray', response.success, 'success');
                    getHazardRiskIdentification();
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-hazard-risk-identification', true);
            xhttp.send(formData);
        }
      });
}

// Site ToolBox


var toolBoxData = [];
function getToolBox(){
  
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        toolBoxData = response.toolbox;
     
        loopToolBox(toolBoxData);
    }
    xhttp.open("GET", serverUrl+'?function=get-toolbox');
    xhttp.send();
}
getToolBox();

function loopToolBox(data){
    var work_place = document.getElementById('work_place');
    var name_of_supervisor = document.getElementById('name_of_supervisor');
    var date = document.getElementById('date');
    var time = document.getElementById('time');

    if(work_place ){
        work_place.innerHTML = data[0].work_place
        name_of_supervisor.innerHTML = data[0].name_of_supervisor
        date.innerHTML = data[0].date
        time.innerHTML = data[0].time
    }
    
}



function editToolBox() {
    const data = toolBoxData;
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add Hazard/Risk Identification</h3>
            </div>
            <form id="form">
                <div class="double-form">
                    <div class="longer-form">
                            <label for="work_place">Work Place</label>
                            <input value="${data[0].work_place}" id="modal_work_place" type="text" name="work_place" />
                        </div>
                        <div class="longer-form">
                            <label for="name_of_supervisor">Name Of Supervisor</label>
                            <input value="${data[0].name_of_supervisor}" type="text" id="modal_name_of_supervisor" name="name_of_supervisor" />
                        </div>
                    </div>
                    <div class="double-form">
                        <div class="longer-form">
                            <label for="date">Date</label>
                            <input value="${data[0].date}" id="modal_date" type="date" name="date" />
                        </div>
                        <div class="longer-form">
                            <label for="time">Time</label>
                            <input value="${data[0].time}" type="text" id="modal_time" name="time" />
                        </div>
                    </div>
                <button type='button' class="edit-button" onclick="updateToolBox(${data[0].id})" id="save-btn">Update</button>  
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}



function updateToolBox(i){
    var modal = document.getElementById('myModal');
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Updating...';
    savebtn.disabled = true;
    var id = i;
    var work_place = document.getElementById("modal_work_place").value;
    var name_of_supervisor = document.getElementById("modal_name_of_supervisor").value;
    var date = document.getElementById("modal_date").value;
    var time = document.getElementById("modal_time").value;

    console.log('log the following', work_place, name_of_supervisor, date, time);
    

    
    var formData = new FormData();
    formData.append('work_place', work_place);
    formData.append('name_of_supervisor', name_of_supervisor);
    formData.append('date', date);
    formData.append('time', time);
    formData.append('id', id);

    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
     
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getToolBox();
        modal.style.display = 'none';
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
        modal.style.display = 'none';
    }
    xhttp.open('POST', serverUrl+'?function=update-toolbox', true);
    xhttp.send(formData);
}




