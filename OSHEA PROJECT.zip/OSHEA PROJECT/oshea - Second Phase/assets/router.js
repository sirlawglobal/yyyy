// // if(window.location.pathname.includes("dashboard/dashboard")){
// //     window.location.href = '../dashboard/dashboard.html';
// // }
// $(document).ready(function() {
//     var path = window.location.pathname;
//     // if(path === '/dashboard/dashboard'){
//     //     window.location.href = '/dashboard/dashboard.html';
//     // }
// });
// document.addEventListener('DOMContentLoaded', function(){
//     var http = "https://test.osheacrm.com";
//     var currentPath = window.location.pathname;
//     // var splitPath = currentPath.split('/');
//     // var lastPath = splitPath[splitPath.length - 1];
//     if(currentPath == '/dashboard/dashboard.html'){
//         var newUrl = currentPath.replace("dashboard/dashboard.html", 'dashboard/dashboard');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/active-contact.html'){
//         var newUrl = currentPath.replace("contact/active-contact.html", 'contact/active-contact');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/active-lead.html'){
//         var newUrl = currentPath.replace("contact/active-lead.html", 'contact/active-lead');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/analytics.html'){
//         var newUrl = currentPath.replace("contact/analytics.html", 'contact/analytics');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/archive.html'){
//         var newUrl = currentPath.replace("contact/archive.html", 'contact/archive');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/average-contact.html'){
//         var newUrl = currentPath.replace("contact/average-contact.html", 'contact/average-contact');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/contactdashboard.html'){
//         var newUrl = currentPath.replace("contact/contactdashboard.html", 'contact/contactdashboard');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/contactlist.html'){
//         var newUrl = currentPath.replace("contact/contactlist.html", 'contact/contactlist');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/inactive-contact.html'){
//         var newUrl = currentPath.replace("contact/inactive-contact.html", 'contact/inactive-contact');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/leadlist.html'){
//         var newUrl = currentPath.replace("contact/leadlist.html", 'contact/leadlist');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
//     if(currentPath == '/contact/pending-contact.html'){
//         var newUrl = currentPath.replace("contact/pending-contact.html", 'contact/pending-contact');
//         var fullUrl = newUrl;
//         history.pushState({}, "", fullUrl);

//         var newPath = window.location.pathname;
//         console.log(newPath);
//     }
// });

