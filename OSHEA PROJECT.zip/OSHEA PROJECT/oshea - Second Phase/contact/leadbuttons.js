document.addEventListener('DOMContentLoaded', function() {

    // FOR THE MODALS
    const leadAdd = document.getElementById('newleadbutton');
    const modalAdd = document.getElementById("myModalAdd");
    const spanAdd = document.querySelector('.close-add');
    const leadEdit = document.querySelectorAll('.openModalBtnEdit');
    const modalleadEdit = document.getElementById('myModalEdit');
    const spanEdit = document.querySelector('.close-edit');
    const leadView = document.querySelectorAll('.openModalBtnView');
    const modalleadView = document.getElementById('myModalView');
    const spanView = document.querySelector('.close');

    if(spanView) {
        spanView.onclick = () => {
            modalleadView.style.display = 'none';
        }
    }


    if(leadView) {
        leadView.forEach(view => {
            view.addEventListener('click', () => {
                modalleadView.style.display = 'block';
                optionList.style.display = 'none';
            })
        });
    }

    if(spanEdit) {
        spanEdit.onclick = () => {
            modalleadEdit.style.display = 'none'
        }
    }

    if(leadEdit) {
        leadEdit.forEach(edit => {
            edit.addEventListener('click', () => {
                modalleadEdit.style.display = 'block'
                optionList.style.display = 'none';
            })
        });
    }



  
        const openModalAdd = () => {
            modalAdd.style.display = 'block'
        };
    


    if(leadAdd) {
        leadAdd.addEventListener('click', openModalAdd);
    }

   
    if(spanAdd) {
        spanAdd.onclick = () => {
            modalAdd.style.display = 'none'
        }
    }


    // FOR THE THREE DOTS
    const threeDot = document.querySelectorAll(".three");
    const optionList = document.querySelector('.options-dropdown');
    let toggleButton = false;

    if(threeDot) {
        threeDot.forEach(eachThree => {
            eachThree.addEventListener('click', () => {
              
                if (toggleButton) {
                    optionList.style.display = 'none';
                } else {
                    optionList.style.display = 'flex';
                }
                toggleButton = !toggleButton;
            });
        });
    }
    

    

    const selectDropdown = document.querySelector('.dropdown-icon')
    const selectContainer = document.querySelector('.select-options')


    if(selectDropdown) {
        selectDropdown.onclick = () => {
            if (toggleButton) {
                selectContainer.style.display = 'none'
            } else {
                selectContainer.style.display = 'block'
            }
            toggleButton = !toggleButton
        };
    }

   
    if(selectContainer) {
        const closeDown = () => {
        selectContainer.style.display = 'none'
    }

    }

    


    const selectOption = document.querySelectorAll('.select-dropdown')
    const selectInput = document.querySelector('.dropdown-select')

    if(selectOption) {
        selectOption.forEach(option => {
        option.addEventListener('click', () => {
            const optionValue = option.innerHTML
            selectInput.value = optionValue
            closeDown()
        })
    })
    }

    // Close modal when clicking outside
    window.onclick = event => {
        if (event.target == modalAdd) {
            modalAdd.style.display = 'none';
        }
        if (event.target == modalleadEdit) {
            modalleadEdit.style.display = 'none'
        }
        if (event.target == modalleadView) {
            
            modalleadView.style.display = 'none'
        }
        if (event.target == optionList) {
            alert('event all')
            optionList.style.display = 'none';
        }
    };



    // Prevent click event propagation for optionList
    if(optionList) {
        optionList.onclick = event => {
        event.stopPropagation();
    };
    }

});


// ARCHIVE BUTTON

let archiveButton = false;

const threeArchive = document.querySelectorAll('.archive-three')

const optionDrop = document.querySelector('.options-dropdown')

if(threeArchive) {
    
threeArchive.forEach(threeArch => {
    threeArch.addEventListener('click', () => {
        
        if (archiveButton) {
            optionDrop.style.display = 'none';
        } else {
            optionDrop.style.display = 'block';
        }
        archiveButton = !archiveButton
    })
})
}



