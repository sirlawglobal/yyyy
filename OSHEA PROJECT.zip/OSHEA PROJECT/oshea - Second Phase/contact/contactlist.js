

// TO BRING OUT THE VIEW MODAL

const buttons = document.querySelectorAll('.openModalBtn')

const modal = document.getElementById("myModal")

const span = document.querySelector('.close')

const openModal = () => {
    modal.style.display = 'block'
}

if(buttons) {
    buttons.forEach(button => {
        button.addEventListener('click', openModal)
        console.log('it clicked');
    })
}

if(span) {
    span.onclick = () => {
        modal.style.display = 'none'
    }
}




// TO BRING OUT THE EDIT MODAL

const buttonsEdit = document.querySelectorAll('.openModalBtnEdit')

const modalEdit = document.getElementById('myModalEdit')


const openModalEdit = () => {
    modalEdit.style.display = 'block'
}

if(buttonsEdit) {
    buttonsEdit.forEach(newbutton => {
        newbutton.addEventListener('click', openModalEdit)
    })
}


const spanEdit = document.querySelector('.close-edit')

if(spanEdit) {
    spanEdit.onclick = () => {
        modalEdit.style.display = 'none'
    }
}






// TO BRING OUT THE ADD CONTACT MODAL

const buttonAdd = document.getElementById('openModalBtnAdd')

const modalAdd = document.getElementById("myModalAdd")

const spanAdd = document.querySelector('.close-add')

const openModalAdd = () => {
    modalAdd.style.display = 'block'
}

if (buttonAdd) {
buttonAdd.addEventListener('click', openModalAdd)
}

if(spanAdd) {
    spanAdd.onclick = () => {
        modalAdd.style.display = 'none'
    }
}

// Close modal when clicking outside
window.onclick = event => {
    if (event.target == modal) {
        modal.style.display = 'none';
    }
    if (event.target == modalEdit) {
        modalEdit.style.display = 'none';
    }
    if (event.target == modalAdd) {
        modalAdd.style.display = 'none';
    }
};


// Lead.html
