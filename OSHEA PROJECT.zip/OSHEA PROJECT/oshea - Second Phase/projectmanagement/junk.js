i worked on these two screens with their both FE AND BE.

STAKEHOLDER INSTRUCTION TEMPLATE
http://test.osheacrm.com/projectmanagement/SCInstruction.html   

RMP INSTRUCTION TEMPLATE
 http://test.osheacrm.com/projectmanagement/RmpInstruction.html