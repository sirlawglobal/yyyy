var modalContent = `
 
<style>
       
   
           .select-input{
               display: flex;
               width: 88%;
               height: 24px;
               padding: 7px 17px;
               align-items: flex-start;
               gap: 10px;
               flex-shrink: 0;
               border-radius: 8px;
               border: 1px solid var(--Foundation-Primary-P400, #0047B3);
               background: var(--Foundation-White-W300, #F6F6F6);
           }

           .dashboard-rightbar, body{
       background-color: #fff;
       /* font-family: Archivo; */
   }
   .sign_btn{
           padding: 10px;
           gap: 10px;
           flex-shrink: 0;
           border-radius: 10px;
           background: #6F6DEB;
           color: #FFF;
           text-align: center;
           font-family: Archivo;
           font-size: 18px;
           font-style: normal;
           font-weight: 600;
           line-height: 120%;
           border: 0;
       }

       .address_row{
           display: flex;
           justify-content: space-between;
           align-items: center;
       }

       .addres > a{
           text-decoration: none;
           color:black;
       }
       *,::after,::after{
           margin: 0;
           padding: 0;
           box-sizing: border-box;
       }
</style>

   <div id="myModal" class="modal-container">
       <div class="modal-content">
           <span onclick="closeModal()" class="close">&times;</span>
           <div class="add-text">
               <h3>Edit </h3>
           </div>

           
               <img src="http://test.osheacrm.com/assetsPeter/engr_form_head.png" alt=""  width="100%" height="100%">
           
          
               <div style="padding: 30px 0;" class="addres">
                   <div class="address_row">
                       <span><h4>Acme Corporation</h4></span>
                       <span><h4>P.O.BOX 3380</h4></span>
                   </div>
                   <div class="address_row">
                       <span><h4>Mende - Maryland,</h4></span>
                       <span><h4>Yaba, Lagos</h4></span>
                   </div>
               
                   <div>

                   <h4>Lagos, Nigeria.</h4>
                       <h4>456 Corporate Blvd, Suite 100</h4>
                       <h4>San Francisco, CA 94105</h4>
                      <a href="tel:+234-1-7742609" style="color:black">Tel: 234-1-7742609, 08096004705, 08023134810</a><br>
                      <a href="mailto:info@osheaprojects.com" style="color:black">Email: info@osheaprojects.com; osheaprojects@yahoo.com</a><br>
                      <a href="www.osheaprojects.com" style="color:black">Website: www.osheaprojects.com</a>

                   </div>
                    
               
               </div>


           <form id="form">
                  
                   <h3 style="text-align:center; margin:20px 0">ENGINEERING'S CORRESPONDENCE</h3>
               
                   <div class="longer-form">
                       <label for="From">From</label>
                       <input type="text" id="From" required value="${data.Fromm}"/>
                   </div>
                   <div class="longer-form">
                       <label for="To">To</label>
                       <input type="text" id="To" required value="${data.Too}"/>
                   </div>

                   <div class="longer-form">
                       <label for="Subject">Subject</label>
                       <input type="text" id="Subject" required value="${data.Subjectt}"/>
                   </div>

                  
                   <div class="longer-form">
                       <label for="Job_NO">Job NO</label>
                       <input type="text" id="Job_NO" required value="${data.Job_NO}" />
                   </div>

                   <div class="longer-form">
                       <label for="Memo_NO">Memo NO</label>
                       <input type="text" id="Memo_NO" required  value="${data.Memo_NO}"/>
                   </div>

                  
                   <div class="longer-form">
                       <label for="Date">Date</label>
                       <input type="text" id="Date" required value="${data.Datee}" />
                   </div>

                  

                   <div class="longer-form">
                       <label for="">Notes</label>
                      <textarea rows="10" cols="50" id="Notes" required style="height: 177px! important;"></textarea>
                   </div>
               
                   <div class="" style="display: flex; justify-content: space-between;align-items: center;margin: 40px 0;">
                       <label for="">Signature.................</label>

                       <button type='button' class="sign_btn" id="">+ Add Signature</button> 

                       <button type='button' class="sign_btn" onclick="" id="" style="background: #6F6DEB;color:white">Change Signature</button> 
                   </div>
               
               
                  <button type='button' class="edit-button" onclick="saveEngnrData()" id="save-btn">Update</button>
               </form> 
       </div>
   </div>
 

`;