document.addEventListener('DOMContentLoaded', function(){
    var admin = JSON.parse(window.localStorage.getItem('admin'));
    if(!admin){
        window.location.href = '../index.html';
    }
});
function limitString(value, limit){
    if(value && value.length > limit){
        return str.substring(0, limit);
    }else{
        return value;
    }
}
var serverUrl = "http://backend.osheacrm.com/request.php";
function saveContact(){
    var modal = document.getElementById('myModal');
    var openModalBtn = document.getElementById("save-btn");
    
    // var contactId = document.getElementById("contactID").value;
    var contactName = document.getElementById("contactName2").value;
    var company_name = document.getElementById("company_name2").value;
    var position = document.getElementById("position2").value;
    var address = document.getElementById("address2").value;
    var email = document.getElementById("email2").value;
    var phone = document.getElementById("phone2").value;
    var source = document.getElementById("source2").value;
    var modifiedDate = document.getElementById("modifiedDate2").value;
    var status = document.getElementById("status2").value;
    if(contactName == ''){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
        formData.append('contactName', contactName);
        formData.append('company_name', company_name);
        formData.append('position', position);
        formData.append('address', address);
        formData.append('email', email);
        formData.append('phone', phone);
        formData.append('source', source);
        formData.append('modifiedDate', modifiedDate);
        formData.append('status', status);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            document.getElementById('contact-form').reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
            }
            else{
                swal('Sorry', response.error, 'error');
                
            }
            getContacts();
        }
        xhttp.onerror = function(error){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-contact', true);
        xhttp.send(formData);
    }
    
    
}
var contacts = [];
function getContacts(){
    var tbody = document.getElementById("tbody");
    var active_container_container = document.getElementById('active-contact-container');
    var inactive_contact_container = document.getElementById('inactive-contact-container');
    var pending_contact_container = document.getElementById('pending-contact-container');
    if(tbody){
        tbody.innerHTML = 'Please wait...';
        tbody.style.color = 'white';
        tbody.style.background = '#091e42';
    }
    var contactContainer = document.getElementById('contact-container');
    if(contactContainer){
        contactContainer.innerHTML = 'Please wait...';
        contactContainer.style.color = 'white';
        contactContainer.style.background = '#091e42';
    }
    if(active_container_container){
        active_container_container.innerHTML = 'Please wait...';
        active_container_container.style.color = 'white';
        active_container_container.style.background = '#091e42';
    }
    if(inactive_contact_container){
        inactive_contact_container.innerHTML = 'Please wait...';
        inactive_contact_container.style.color = 'white';
        inactive_contact_container.style.background = '#091e42';
    }
    if(pending_contact_container){
        pending_contact_container.innerHTML = 'Please wait...';
        pending_contact_container.style.color = 'white';
        pending_contact_container.style.background = '#091e42';
    }
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        contacts = response.contacts;
        filterContacts(contacts);
        loopContacts(contacts);
        if(contacts.length == 0){
            tbody.innerHTML = "No record found!";
        }
        if(active_container_container){
            if(contacts.length == 0){
                active_container_container.innerHTML = "No record found!";
                active_container_container.style.color = 'white';
                active_container_container.style.background = '#091e42';
            }
        }
        if(response.error){
            if(tbody){
                tbody.innerHTML = response.error;
                tbody.style.color = 'white';
                tbody.style.background = '#091e42';
            }
            if(active_container_container){
                active_container_container.innerHTML = "No record found!";
                active_container_container.style.color = 'white';
                active_container_container.style.background = '#091e42';
            }
            if(inactive_contact_container){
                inactive_contact_container.innerHTML = "No record found!";
                inactive_contact_container.style.color = 'white';
                inactive_contact_container.style.background = '#091e42';
            }
            if(pending_contact_container){
                pending_contact_container.innerHTML = "No record found!";
                pending_contact_container.style.color = 'white';
                pending_contact_container.style.background = '#091e42';
            }
        }
    }
    xhttp.open("GET", serverUrl+'?function=get-contacts');
    xhttp.send();
}
getContacts();
var active_contacts = [];
var inactive_contacts = [];
var pending_contacts = [];
function loopContacts(contacts){
    var tbody = document.getElementById("tbody");
    var contactContainer = document.getElementById('contact-container');
    var active_container_container = document.getElementById('active-contact-container');
    var inactive_contact_container = document.getElementById('inactive-contact-container');
    var pending_contact_container = document.getElementById('pending-contact-container');
    var tr = "";
    if(contacts.length > 0){
        var counter = 0;
        for(var i=0; i<contacts.length; i++){
            counter++;
            tr += `
                <tr style="padding-top: 10px;background: #EBEDF017;border-bottom: 10px solid #091e42;
                ">
                    <td>${counter < 10 ? '00'+counter : counter}</td>
                    <td>${contacts[i].contactName}</td>
                    <td>${contacts[i].company_name ? contacts[i].company_name : 'No data'}</td>
                    <td>${contacts[i].position ? contacts[i].position : 'No data'}</td>
                    <td>${contacts[i].email}</td>
                    <td>${contacts[i].phone}</td>
                    <td>${contacts[i].source}</td>
                </tr>
            `;
        }
        if(tbody){
            tbody.innerHTML = tr;
            tbody.style.color = 'white';
            tbody.style.background = '#091e42';
        }
    }else{
        if(tbody){
            tbody.innerHTML = "No record found!";
            tbody.style.color = 'white';
            tbody.style.background = '#091e42';
        }
    }
    
    if(contactContainer){
        var details = "";
        if(contacts.length > 0){
            var counter = 0;
            for(var i=0; i<contacts.length; i++){
                counter++;
                var indexNumber = i+1;
                details += `
                
                <tr style="padding-top: 10px;background: #EBEDF017;border-bottom: 10px solid #091e42;
                ">
                <td style="padding-top: 15px;">${counter < 10 ? '00'+counter : counter}</td>
                <td style="padding-top: 15px;">${contacts[i].contactName}</td>
                <td style="padding-top: 15px;">${contacts[i].company_name ? contacts[i].company_name : 'No data'}</td>
                <td style="padding-top: 15px;">${contacts[i].position ? contacts[i].position : 'No data'}</td>
                <td style="padding-top: 15px;">${contacts[i].email}</td>
                <td style="padding-top: 10px;">
                    <span class="${contacts[i].status.toLowerCase()}">${contacts[i].status}</span>
                </td>
                <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="viewContact(${i})">View</a></td>
                <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="editModal(${i})" class="openModalBtnEdit">Edit</a></td>
                <td style="padding-top: 15px;" class="delete" onclick="deleteContact(${i})">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="25" viewBox="0 0 26 25" fill="none">
                    <path d="M8.00555 18.75L12.5087 14.25L17.0118 18.75L18.763 17L14.2599 12.5L18.763 8L17.0118 6.25L12.5087 10.75L8.00555 6.25L6.25434 8L10.7575 12.5L6.25434 17L8.00555 18.75ZM12.5087 25C10.7783 25 9.15218 24.6717 7.6303 24.015C6.10841 23.3583 4.78457 22.4679 3.65879 21.3437C2.53301 20.2188 1.64197 18.8958 0.985684 17.375C0.329395 15.8542 0.000833912 14.2292 0 12.5C0 10.7708 0.328561 9.14583 0.985684 7.625C1.64281 6.10417 2.53384 4.78125 3.65879 3.65625C4.78457 2.53125 6.10841 1.64083 7.6303 0.985C9.15218 0.329167 10.7783 0.000833333 12.5087 0C14.239 0 15.8652 0.328333 17.3871 0.985C18.909 1.64167 20.2328 2.53208 21.3586 3.65625C22.4844 4.78125 23.3758 6.10417 24.0329 7.625C24.69 9.14583 25.0182 10.7708 25.0174 12.5C25.0174 14.2292 24.6888 15.8542 24.0317 17.375C23.3746 18.8958 22.4835 20.2188 21.3586 21.3437C20.2328 22.4687 18.909 23.3596 17.3871 24.0162C15.8652 24.6729 14.239 25.0008 12.5087 25ZM12.5087 22.5C15.3023 22.5 17.6685 21.5312 19.6074 19.5937C21.5462 17.6562 22.5156 15.2917 22.5156 12.5C22.5156 9.70833 21.5462 7.34375 19.6074 5.40625C17.6685 3.46875 15.3023 2.5 12.5087 2.5C9.71507 2.5 7.34885 3.46875 5.41 5.40625C3.47116 7.34375 2.50174 9.70833 2.50174 12.5C2.50174 15.2917 3.47116 17.6562 5.41 19.5937C7.34885 21.5312 9.71507 22.5 12.5087 22.5Z" fill="white"/>
                    </svg>
                </td>
            </tr>
                `
            }
    
            contactContainer.innerHTML = details;
            contactContainer.style.color = 'white';
            contactContainer.style.background = '#091e42';
        }else{
            contactContainer.innerHTML = 'No record found!';
            contactContainer.style.color = 'white';
            contactContainer.style.background = '#091e42';
        }
    }
    if(active_container_container){
        var details = "";
        if(contacts.length > 0){
            active_contacts = contacts.filter((contact)=>{
                return contact.status == 'Active';
            });
            if(active_contacts.length > 0){
                var counter = 0;
                for(var i=0; i<active_contacts.length; i++){
                    counter++;
                    var indexNumber = i+1;
                    details += `
                        
                <tr style="padding-top: 10px;background: #EBEDF017;border-bottom: 10px solid #091e42;
                ">
                <td style="padding-top: 15px;">${counter < 10 ? '00'+counter : counter}</td>
                <td style="padding-top: 15px;">${active_contacts[i].contactName}</td>
                <td style="padding-top: 15px;">${active_contacts[i].company_name ? active_contacts[i].company_name : 'No data'}</td>
                <td style="padding-top: 15px;">${active_contacts[i].position ? active_contacts[i].position : 'No data'}</td>
                <td style="padding-top: 15px;">${active_contacts[i].email}</td>
                <td style="padding-top: 10px;">
                    <span class="${active_contacts[i].status.toLowerCase()}">${active_contacts[i].status}</span>
                </td>
                <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="viewContact(${i})">View</a></td>
                <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="editModal(${i})" class="openModalBtnEdit">Edit</a></td>
                <td style="padding-top: 15px;" class="delete" onclick="deleteContact(${i})">
                    <svg xmlns="http://www.w3.org/2000/svg" width="26" height="25" viewBox="0 0 26 25" fill="none">
                    <path d="M8.00555 18.75L12.5087 14.25L17.0118 18.75L18.763 17L14.2599 12.5L18.763 8L17.0118 6.25L12.5087 10.75L8.00555 6.25L6.25434 8L10.7575 12.5L6.25434 17L8.00555 18.75ZM12.5087 25C10.7783 25 9.15218 24.6717 7.6303 24.015C6.10841 23.3583 4.78457 22.4679 3.65879 21.3437C2.53301 20.2188 1.64197 18.8958 0.985684 17.375C0.329395 15.8542 0.000833912 14.2292 0 12.5C0 10.7708 0.328561 9.14583 0.985684 7.625C1.64281 6.10417 2.53384 4.78125 3.65879 3.65625C4.78457 2.53125 6.10841 1.64083 7.6303 0.985C9.15218 0.329167 10.7783 0.000833333 12.5087 0C14.239 0 15.8652 0.328333 17.3871 0.985C18.909 1.64167 20.2328 2.53208 21.3586 3.65625C22.4844 4.78125 23.3758 6.10417 24.0329 7.625C24.69 9.14583 25.0182 10.7708 25.0174 12.5C25.0174 14.2292 24.6888 15.8542 24.0317 17.375C23.3746 18.8958 22.4835 20.2188 21.3586 21.3437C20.2328 22.4687 18.909 23.3596 17.3871 24.0162C15.8652 24.6729 14.239 25.0008 12.5087 25ZM12.5087 22.5C15.3023 22.5 17.6685 21.5312 19.6074 19.5937C21.5462 17.6562 22.5156 15.2917 22.5156 12.5C22.5156 9.70833 21.5462 7.34375 19.6074 5.40625C17.6685 3.46875 15.3023 2.5 12.5087 2.5C9.71507 2.5 7.34885 3.46875 5.41 5.40625C3.47116 7.34375 2.50174 9.70833 2.50174 12.5C2.50174 15.2917 3.47116 17.6562 5.41 19.5937C7.34885 21.5312 9.71507 22.5 12.5087 22.5Z" fill="white"/>
                    </svg>
                </td>
            </tr>
                    `
                }
        
                active_container_container.innerHTML = details;
                active_container_container.style.color = 'white';
                active_container_container.style.background = '#091e42';
            }else{
                active_container_container.innerHTML = 'No record found!';
                active_container_container.style.color = 'white';
                active_container_container.style.background = '#091e42';
            }
            
        }else{
            active_container_container.innerHTML = 'No record found!';
            active_container_container.style.color = 'white';
            active_container_container.style.background = '#091e42';
        }
    }
    if(inactive_contact_container){
        var details = "";
        if(contacts.length > 0){
            inactive_contacts = contacts.filter((contact)=>{
                return contact.status == 'Inactive';
            });
            if(inactive_contacts.length > 0){
                var counter = 0;
                for(var i=0; i<inactive_contacts.length; i++){
                    counter++;
                    var indexNumber = i+1;
                    details += `
                    <tr style="padding-top: 10px;background: #EBEDF017;border-bottom: 10px solid #091e42;
                    ">
                    <td style="padding-top: 15px;">${counter < 10 ? '00'+counter : counter}</td>
                    <td style="padding-top: 15px;">${inactive_contacts[i].contactName}</td>
                    <td style="padding-top: 15px;">${inactive_contacts[i].company_name ? inactive_contacts[i].company_name : 'No data'}</td>
                    <td style="padding-top: 15px;">${inactive_contacts[i].position ? inactive_contacts[i].position : 'No data'}</td>
                    <td style="padding-top: 15px;">${inactive_contacts[i].email}</td>
                    <td style="padding-top: 10px;">
                        <span class="${inactive_contacts[i].status.toLowerCase()}">${inactive_contacts[i].status}</span>
                    </td>
                    <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="viewContact(${i})">View</a></td>
                    <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="editModal(${i})" class="openModalBtnEdit">Edit</a></td>
                    <td style="padding-top: 15px;" class="delete" onclick="deleteContact(${i})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="25" viewBox="0 0 26 25" fill="none">
                        <path d="M8.00555 18.75L12.5087 14.25L17.0118 18.75L18.763 17L14.2599 12.5L18.763 8L17.0118 6.25L12.5087 10.75L8.00555 6.25L6.25434 8L10.7575 12.5L6.25434 17L8.00555 18.75ZM12.5087 25C10.7783 25 9.15218 24.6717 7.6303 24.015C6.10841 23.3583 4.78457 22.4679 3.65879 21.3437C2.53301 20.2188 1.64197 18.8958 0.985684 17.375C0.329395 15.8542 0.000833912 14.2292 0 12.5C0 10.7708 0.328561 9.14583 0.985684 7.625C1.64281 6.10417 2.53384 4.78125 3.65879 3.65625C4.78457 2.53125 6.10841 1.64083 7.6303 0.985C9.15218 0.329167 10.7783 0.000833333 12.5087 0C14.239 0 15.8652 0.328333 17.3871 0.985C18.909 1.64167 20.2328 2.53208 21.3586 3.65625C22.4844 4.78125 23.3758 6.10417 24.0329 7.625C24.69 9.14583 25.0182 10.7708 25.0174 12.5C25.0174 14.2292 24.6888 15.8542 24.0317 17.375C23.3746 18.8958 22.4835 20.2188 21.3586 21.3437C20.2328 22.4687 18.909 23.3596 17.3871 24.0162C15.8652 24.6729 14.239 25.0008 12.5087 25ZM12.5087 22.5C15.3023 22.5 17.6685 21.5312 19.6074 19.5937C21.5462 17.6562 22.5156 15.2917 22.5156 12.5C22.5156 9.70833 21.5462 7.34375 19.6074 5.40625C17.6685 3.46875 15.3023 2.5 12.5087 2.5C9.71507 2.5 7.34885 3.46875 5.41 5.40625C3.47116 7.34375 2.50174 9.70833 2.50174 12.5C2.50174 15.2917 3.47116 17.6562 5.41 19.5937C7.34885 21.5312 9.71507 22.5 12.5087 22.5Z" fill="white"/>
                        </svg>
                    </td>
                </tr>
                    `
                }
        
                inactive_contact_container.innerHTML = details;
                inactive_contact_container.style.color = 'white';
                inactive_contact_container.style.background = '#091e42';
            }else{
                inactive_contact_container.innerHTML = 'No record found!';
                inactive_contact_container.style.color = 'white';
                inactive_contact_container.style.background = '#091e42';
            }
            
        }else{
            inactive_contact_container.innerHTML = 'No record found!';
            inactive_contact_container.style.color = 'white';
            inactive_contact_container.style.background = '#091e42';
        }
    }
    if(pending_contact_container){
        var details = "";
        if(contacts.length > 0){
            pending_contacts = contacts.filter((contact)=>{
                return contact.status == 'Pending';
            });
            if(pending_contacts.length > 0){
                var counter = 0;
                for(var i=0; i<pending_contacts.length; i++){
                    counter++;
                    var indexNumber = i+1;
                    details += `
                    <tr style="padding-top: 10px;background: #EBEDF017;border-bottom: 10px solid #091e42;
                    ">
                    <td style="padding-top: 15px;">${counter < 10 ? '00'+counter : counter}</td>
                    <td style="padding-top: 15px;">${pending_contacts[i].contactName}</td>
                    <td style="padding-top: 15px;">${pending_contacts[i].company_name ? pending_contacts[i].company_name : 'No data'}</td>
                    <td style="padding-top: 15px;">${pending_contacts[i].position ? pending_contacts[i].position : 'No data'}</td>
                    <td style="padding-top: 15px;">${pending_contacts[i].email}</td>
                    <td style="padding-top: 10px;">
                        <span class="${pending_contacts[i].status.toLowerCase()}">${pending_contacts[i].status}</span>
                    </td>
                    <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="viewContact(${i})">View</a></td>
                    <td style="padding-top: 15px;"><a href="javascript:void(0)" class="option-link" onclick="editModal(${i})" class="openModalBtnEdit">Edit</a></td>
                    <td style="padding-top: 15px;" class="delete" onclick="deleteContact(${i})">
                        <svg xmlns="http://www.w3.org/2000/svg" width="26" height="25" viewBox="0 0 26 25" fill="none">
                        <path d="M8.00555 18.75L12.5087 14.25L17.0118 18.75L18.763 17L14.2599 12.5L18.763 8L17.0118 6.25L12.5087 10.75L8.00555 6.25L6.25434 8L10.7575 12.5L6.25434 17L8.00555 18.75ZM12.5087 25C10.7783 25 9.15218 24.6717 7.6303 24.015C6.10841 23.3583 4.78457 22.4679 3.65879 21.3437C2.53301 20.2188 1.64197 18.8958 0.985684 17.375C0.329395 15.8542 0.000833912 14.2292 0 12.5C0 10.7708 0.328561 9.14583 0.985684 7.625C1.64281 6.10417 2.53384 4.78125 3.65879 3.65625C4.78457 2.53125 6.10841 1.64083 7.6303 0.985C9.15218 0.329167 10.7783 0.000833333 12.5087 0C14.239 0 15.8652 0.328333 17.3871 0.985C18.909 1.64167 20.2328 2.53208 21.3586 3.65625C22.4844 4.78125 23.3758 6.10417 24.0329 7.625C24.69 9.14583 25.0182 10.7708 25.0174 12.5C25.0174 14.2292 24.6888 15.8542 24.0317 17.375C23.3746 18.8958 22.4835 20.2188 21.3586 21.3437C20.2328 22.4687 18.909 23.3596 17.3871 24.0162C15.8652 24.6729 14.239 25.0008 12.5087 25ZM12.5087 22.5C15.3023 22.5 17.6685 21.5312 19.6074 19.5937C21.5462 17.6562 22.5156 15.2917 22.5156 12.5C22.5156 9.70833 21.5462 7.34375 19.6074 5.40625C17.6685 3.46875 15.3023 2.5 12.5087 2.5C9.71507 2.5 7.34885 3.46875 5.41 5.40625C3.47116 7.34375 2.50174 9.70833 2.50174 12.5C2.50174 15.2917 3.47116 17.6562 5.41 19.5937C7.34885 21.5312 9.71507 22.5 12.5087 22.5Z" fill="white"/>
                        </svg>
                    </td>
                </tr>
                    `
                }
        
                pending_contact_container.innerHTML = details;
                pending_contact_container.style.color = 'white';
                pending_contact_container.style.background = '#091e42';
            }else{
                pending_contact_container.innerHTML = 'No record found!';
                pending_contact_container.style.color = 'white';
                pending_contact_container.style.background = '#091e42';
            }
            
        }else{
            pending_contact_container.innerHTML = 'No record found!';
            pending_contact_container.style.color = 'white';
            pending_contact_container.style.background = '#091e42';
        }
    }
}
function filterContacts(contacts){
    var activeContactElement = document.getElementById('active-contact');
    var inactiveContactElement = document.getElementById('inactive-contact');
    var pendingContactElement = document.getElementById('pending-contact');
    var activeContacts = [];
    var inactiveContacts = [];
    var pendingContacts = [];
   for(let contact of contacts){
    if(contact.status.toLowerCase() == 'active'){
        activeContacts.push(contact);
    }
    if(contact.status.toLowerCase() == 'inactive'){
        inactiveContacts.push(contact);
    }
    if(contact.status.toLowerCase() == 'pending'){
        pendingContacts.push(contact);
    }
   }
   if(activeContactElement){
    activeContactElement.innerHTML = activeContacts.length;
   }
   if(inactiveContactElement){
    inactiveContactElement.innerHTML = inactiveContacts.length;
   }
   if(pendingContactElement){
    pendingContactElement.innerHTML = pendingContacts.length;
   }
}
function addContactModal(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New Contact</h3>
            </div>
            <form id="contact-form">
                  
                    <div class="form-class">
                        <label for="contactName">Contact Name</label>
                        <input type="text" id="contactName2" name="contactName" />
                    </div>
                    <div class="form-class">
                        <label for="company_name2">Company Name</label>
                        <input type="text" id="company_name2" name="company_name" />
                    </div>
                    <div class="form-class">
                        <label for="position2">Position</label>
                        <input type="text" id="position2" name="position" />
                    </div>
                    <div class="form-class">
                        <label for="address">Address</label>
                        <input type="text" id="address2" name="address" />
                    </div>
                    <div class="form-class">
                        <label for="email">Email</label>
                        <input type="email" id="email2" name="email" />
                    </div>
               
                    <div class="form-class">
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone2" name="phone" />
                    </div>
                    <div class="form-class">
                        <label for="source">Source</label>
                        <input type="text" id="source2" name="source" />
                    </div>
                    <div class="form-class">
                        <label for="Web link">Web link</label>
                        <input type="text" id="source2" name="source" />
                    </div>
               
                    <div class="form-class">
                        <label for="modifiedDate">Modified Date</label>
                        <input type="date" id="modifiedDate2" name="modifiedDate" />
                    </div>
                    <div class="form-class">
                        <label for="status">Status</label>
                        <select name="" id="status2" class="select-input">
                            <option value="">Please select status</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Pending">Pending</option>
                        </select>
                    </div>
                    <button type="button" class="edit-button" id="save-btn" onclick="saveContact()">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewContact(indexNumber){
    var contact = contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form class="top-form">
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" readonly name="contactName" value="${contact.contactName}">
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position2">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" readonly name="address" value="${contact.address}">
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" readonly name="email" value="${contact.email}">
                </div>
                <div class="form-class">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" readonly name="phone" value="${contact.phone}">
                </div>
                <div class="form-class">
                    <label for="source">Source</label>
                    <input type="text" id="source" readonly name="source" value="${contact.source}">
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" readonly name="modifiedDate" value="${contact.modifiedDate}">
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <input type="text" id="status" name="status" readonly value="${contact.status}">
                </div>
                
                
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewActiveContact(indexNumber){
    var contact = active_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form class="top-form">
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" readonly name="contactName" value="${contact.contactName}">
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" readonly name="address" value="${contact.address}">
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" readonly name="email" value="${contact.email}">
                </div>
                <div class="form-class">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" readonly name="phone" value="${contact.phone}">
                </div>
                <div class="form-class">
                    <label for="source">Source</label>
                    <input type="text" id="source" readonly name="source" value="${contact.source}">
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" readonly name="modifiedDate" value="${contact.modifiedDate}">
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <input type="text" id="status" name="status" readonly value="${contact.status}">
                </div>
                
                
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewInactiveContact(indexNumber){
    var contact = inactive_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form class="top-form">
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" readonly name="contactName" value="${contact.contactName}">
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" readonly name="address" value="${contact.address}">
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" readonly name="email" value="${contact.email}">
                </div>
                <div class="form-class">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" readonly name="phone" value="${contact.phone}">
                </div>
                <div class="form-class">
                    <label for="source">Source</label>
                    <input type="text" id="source" readonly name="source" value="${contact.source}">
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" readonly name="modifiedDate" value="${contact.modifiedDate}">
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <input type="text" id="status" name="status" readonly value="${contact.status}">
                </div>
                
                
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewPendingContact(indexNumber){
    var contact = pending_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View</h3>
            </div>
            <form class="top-form">
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" readonly name="contactName" value="${contact.contactName}">
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" readonly name="address" value="${contact.address}">
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" readonly name="email" value="${contact.email}">
                </div>
                <div class="form-class">
                    <label for="phone">Phone</label>
                    <input type="tel" id="phone" readonly name="phone" value="${contact.phone}">
                </div>
                <div class="form-class">
                    <label for="source">Source</label>
                    <input type="text" id="source" readonly name="source" value="${contact.source}">
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" readonly name="modifiedDate" value="${contact.modifiedDate}">
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <input type="text" id="status" name="status" readonly value="${contact.status}">
                </div>
                
                
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
const closeElement = document.querySelector('.close')

const openModal = () => {
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'block'
    }
}
function closeModal(){
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'none';
    }
}

function editModal(indexNumber){
    var contact = contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form-edit">
                
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" value="${contact.contactName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" value="${contact.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="${contact.email}" name="email" />
                </div>
                <div class="form-class">
                    <div>
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" value="${contact.phone}" name="phone" />
                    </div>
                    <div>
                        <label for="source">Source</label>
                        <input type="text" id="source" value="${contact.source}" name="source" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" value="${contact.modifiedDate}" name="modifiedDate" />
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <select name="" id="status" class="select-input">
                        <option value="${contact.status}">Please select status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending">Pending</option>
                    </select>
                </div>
                <button id="save-btn" class="edit-button" onclick="updateContact(${contact.id})">Update</button>
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editActiveModal(indexNumber){
    var contact = active_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form-edit">
                
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" value="${contact.contactName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" value="${contact.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="${contact.email}" name="email" />
                </div>
                <div class="form-class">
                    <div>
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" value="${contact.phone}" name="phone" />
                    </div>
                    <div>
                        <label for="source">Source</label>
                        <input type="text" id="source" value="${contact.source}" name="source" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" value="${contact.modifiedDate}" name="modifiedDate" />
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <select name="" id="status" class="select-input">
                        <option value="${contact.status}">Please select status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending">Pending</option>
                    </select>
                </div>
                <button id="save-btn" class="edit-button" onclick="updateContact(${contact.id})">Update</button>
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editInactiveModal(indexNumber){
    var contact = inactive_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form-edit">
                
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" value="${contact.contactName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" value="${contact.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="${contact.email}" name="email" />
                </div>
                <div class="form-class">
                    <div>
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" value="${contact.phone}" name="phone" />
                    </div>
                    <div>
                        <label for="source">Source</label>
                        <input type="text" id="source" value="${contact.source}" name="source" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" value="${contact.modifiedDate}" name="modifiedDate" />
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <select name="" id="status" class="select-input">
                        <option value="${contact.status}">Please select status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending">Pending</option>
                    </select>
                </div>
                <button id="save-btn" class="edit-button" onclick="updateContact(${contact.id})">Update</button>
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editPendingModal(indexNumber){
    var contact = pending_contacts[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form-edit">
                
                <div class="form-class">
                    <label for="contactName">Contact Name</label>
                    <input type="text" id="contactName" value="${contact.contactName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="company_name">Company Name</label>
                    <input type="text" id="company_name" value="${contact.company_name}" readonly name="company_name" />
                </div>
                <div class="form-class">
                    <label for="position">Position</label>
                    <input type="text" id="position" value="${contact.position}" readonly name="position" />
                </div>
                <div class="form-class">
                    <label for="address">Address</label>
                    <input type="text" id="address" value="${contact.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="email">Email</label>
                    <input type="email" id="email" value="${contact.email}" name="email" />
                </div>
                <div class="form-class">
                    <div>
                        <label for="phone">Phone</label>
                        <input type="tel" id="phone" value="${contact.phone}" name="phone" />
                    </div>
                    <div>
                        <label for="source">Source</label>
                        <input type="text" id="source" value="${contact.source}" name="source" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="modifiedDate">Modified Date</label>
                    <input type="date" id="modifiedDate" value="${contact.modifiedDate}" name="modifiedDate" />
                </div>
                <div class="form-class">
                    <label for="status">Status</label>
                    <select name="" id="status" class="select-input">
                        <option value="${contact.status}">Please select status</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                        <option value="Pending">Pending</option>
                    </select>
                </div>
                <button id="save-btn" class="edit-button" onclick="updateContact(${contact.id})">Update</button>
                
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function updateContact(contact_id){
    var modal = document.getElementById('myModal');
    var openModalBtn = document.getElementById("save-btn");
    
    // var contactId = document.getElementById("contactID").value;
    var contactName = document.getElementById("contactName").value;
    var company_name = document.getElementById("company_name").value;
    var position = document.getElementById("position").value;
    var address = document.getElementById("address").value;
    var email = document.getElementById("email").value;
    var phone = document.getElementById("phone").value;
    var source = document.getElementById("source").value;
    var modifiedDate = document.getElementById("modifiedDate").value;
    var status = document.getElementById("status").value;
    
    if(contactName == ''){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
        formData.append('contactName', contactName);
        formData.append('company_name', company_name);
        formData.append('position', position);
        formData.append('address', address);
        formData.append('email', email);
        formData.append('phone', phone);
        formData.append('source', source);
        formData.append('modifiedDate', modifiedDate);
        formData.append('status', status);
        formData.append('contact_id', contact_id);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Updating...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            document.getElementById('form-edit').reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
               swal('Hurray', response.success, 'success');
            }
            else{
                swal('Sorry', response.error, 'error');
                
            }
            getContacts();
        }
        xhttp.onerror = function(error){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=update-contact', true);
        xhttp.send(formData);
    }
}

function deleteContact(indexNumber){
    var contact = contacts[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('contact_id', contact.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getContacts();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-contact', true);
            xhttp.send(formData);
        }
      });
}
function deleteActiveContact(indexNumber){
    var contact = active_contacts[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('contact_id', contact.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getContacts();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-contact', true);
            xhttp.send(formData);
        }
    });
}
function deleteInactiveContact(indexNumber){
    var contact = inactive_contacts[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('contact_id', contact.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getContacts();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-contact', true);
            xhttp.send(formData);
        }
    });
}
function deletePendingContact(indexNumber){
    var contact = pending_contacts[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('contact_id', contact.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getContacts();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-contact', true);
            xhttp.send(formData);
        }
    });
}
function searchContact(){
    var value = document.getElementById('search-contact').value;
    var newContacts = contacts.filter(function(contact){
        return contact.contactName.toLowerCase().includes(value.toLowerCase());
    });
    loopContacts(newContacts);
}
function addNewLead(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add New Lead</h3>
            </div>
            <form id="form">
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="contactName">Company Name</label>
                            <input type="text" id="companyName" name="contactName" />
                        </div>
                        <div class="single-form">
                            <label for="address">Title</label>
                            <input type="text" id="address" name="address" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="amount">Value</label>
                            <input type="text" id="amount" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="descripition">Contact Name</label>
                            <input type="text" id="contact-name" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="rgistration">CAC Registration</label>
                            <input type="text" id="cac_reg" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="ownership">Ownership Type</label>
                            <input type="text" id="owner_type" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="tax">Tax Number(TIN)</label>
                            <input type="text" id="tax_number" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="vat">VAT Number</label>
                            <input type="text" id="vat_number" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="bank name">Bank Name</label>
                            <input type="text" id="bank_name" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank country">Bank Country</label>
                            <input type="text" id="bank_country" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="account name">Account Name</label>
                            <input type="text" id="account_name" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="account number">Account Number</label>
                            <input type="text" id="account_number" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Sort Code</label>
                            <input type="text" id="bank_code" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank branch">Bank Branch</label>
                            <input type="text" id="bank_branch" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Address</label>
                            <input type="text" id="bank_address" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="business category">Business Category</label>
                            <input type="text" id="business_category" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="web link">Web Link</label>
                            <input type="text" id="web_link" name="text" />
                        </div>
                        <div class="single-form">
                            <label>Social media handles</label>
                            <input type="text" id="social_handle" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="status">Status</label>
                            <select id='status' class="select-input">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="endDate">Date Of Connection</label>
                            <input type="date" id="endDate" name="modifiedDate" />
                        </div>
                    </div>

                    <button type='button' onclick="saveLead()" class="edit-button" onclick="saveLead()" id="save-btn">Save</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function saveLead(){
    var modal = document.getElementById('myModal');
    var openModalBtn = document.getElementById("save-btn");
    var form = document.getElementById('form');
    
    var companyName = document.getElementById("companyName").value;
    var address = document.getElementById("address").value;
    var amount = document.getElementById("amount").value;
    var contact_name = document.getElementById("contact-name").value;
    var cac_reg = document.getElementById("cac_reg").value;
    var owner_type = document.getElementById("owner_type").value;
    var tax_number = document.getElementById("tax_number").value;
    var vat_number = document.getElementById("vat_number").value;
    var bank_name = document.getElementById("bank_name").value;
    var bank_country = document.getElementById("bank_country").value;
    var account_name = document.getElementById("account_name").value;
    var account_number = document.getElementById("account_number").value;
    var bank_code = document.getElementById("bank_code").value;
    var bank_branch = document.getElementById("bank_branch").value;
    var bank_address = document.getElementById("bank_address").value;
    var business_category = document.getElementById("business_category").value;
    var web_link = document.getElementById("web_link").value;
    var social_handle = document.getElementById("social_handle").value;
    var status = document.getElementById("status").value;
    var endDate = document.getElementById("endDate").value;
    
    if(companyName == ''){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        formData.append('companyName', companyName);
        formData.append('address', address);
        formData.append('amount', amount);
        formData.append('contact_name', contact_name);
        formData.append('cac_reg', cac_reg);
        formData.append('owner_type', owner_type);
        formData.append('tax_number', tax_number);
        formData.append('vat_number', vat_number);
        formData.append('bank_name', bank_name);
        formData.append('bank_country', bank_country);
        formData.append('account_name', account_name);
        formData.append('account_number', account_number);
        formData.append('bank_code', bank_code);
        formData.append('bank_branch', bank_branch);
        formData.append('bank_address', bank_address);
        formData.append('business_category', business_category);
        formData.append('web_link', web_link);
        formData.append('social_handle', social_handle);
        formData.append('status', status);
        formData.append('endDate', endDate);
       
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Saving...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
                getLeads();
               swal('Hurray', response.success, 'success');
            }
            else{
                swal('Sorry', response.error, 'error');
            }
        }
        xhttp.onerror = function(error){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Save";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=save-lead', true);
        xhttp.send(formData);
    }
}
var leads = [];
function getLeads(){
    var leadsContainer = document.getElementById('all-lead-table');
    var active_leads_table = document.getElementById('active-leads-table');
    var average_leads_table = document.getElementById('average-leads-table');
    if(leadsContainer){
        leadsContainer.innerHTML = 'Please wait...';
        leadsContainer.style.background = '#091e42';
        leadsContainer.style.color = 'white';
    }
    if(active_leads_table){
        active_leads_table.innerHTML = 'Please wait...';
        active_leads_table.style.background = '#091e42';
        active_leads_table.style.color = 'white';
    }
    if(average_leads_table){
        average_leads_table.innerHTML = 'Please wait...';
        average_leads_table.style.background = '#091e42';
        average_leads_table.style.color = 'white';
    }
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        leads = response.leads;
        filterLeads(leads);
        if(leads){
            loopLeads(leads);
        }else{
            if(leadsContainer){
                leadsContainer.innerHTML = 'No record found!';
                leadsContainer.style.background = '#091e42';
                leadsContainer.style.color = 'white';
            }
            if(active_leads_table){
                active_leads_table.innerHTML = 'No record found!';
                active_leads_table.style.background = '#091e42';
                active_leads_table.style.color = 'white';
            }
            if(average_leads_table){
                average_leads_table.innerHTML = 'No record found!';
                average_leads_table.style.background = '#091e42';
                average_leads_table.style.color = 'white';
            }
        }
    }
    xhttp.open('GET', serverUrl+'?function=get-leads');
    xhttp.send();
}
getLeads();
var activeLeads = [];
var firstHalfData = [];
function loopLeads(leads){
    var leadsContainer = document.getElementById('all-lead-table');
    var active_leads_table = document.getElementById('active-leads-table');
    var average_leads_table = document.getElementById('average-leads-table');
    var leadDetails = '';
    var counter = 0;
    for(var i=0; i < leads.length; i++){
        counter++;
        if(leads[i].status == 'Active'){
            leadDetails += `
            <tr >
                <td>${counter < 10 ? '00'+counter : counter}</td>
                <td>${leads[i].address}</td>
                <td>${leads[i].amount}</td>
                <td>${leads[i].companyName}</td>
                <td>${leads[i].contact_name}</td>
                <td>${leads[i].endDate}</td>
                <td>${leads[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown">
                            <button  class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Approve
                            </button>
                            <button onclick="editLead(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewLead(${i})" class="openModalBtnView option-button">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button type="button" id="archive${i}" onclick="archiveLead(${i})" class="option-button">
                                <img src="../assetsPeter/leadarchive.png" />
                                Archive
                            </button>
                            <button onclick="deleteLead(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
                    <style>
                    .completed {
                        border-radius: 12px;
                        background: rgba(84, 181, 129, 0.92);
                        display: flex;
                        width: 65px;
                        padding: 5px;
                        justify-content: center;
                        align-items: center;
                    }
                    </style>
                    <img src="../assets/icons/fade-active.png">
                    &nbsp;&nbsp;
                    <img src="../assets/icons/fade-inactive.png">
                </td>
            </tr>
            `;
        }else if(leads[i].status == 'Inactive'){
            leadDetails += `
            <tr >
                <td>${leads[i].address}</td>
                <td>${leads[i].amount}</td>
                <td>${leads[i].companyName}</td>
                <td>${leads[i].contact_name}</td>
                <td>${leads[i].endDate}</td>
                <td>${leads[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown">
                            <button onclick="editLead(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewLead(${i})" class="openModalBtnView option-button">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button type="button" id="archive${i}" onclick="archiveLead(${i})" class="option-button">
                                <img src="../assetsPeter/leadarchive.png" />
                                Archive
                            </button>
                            <button onclick="deleteLead(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
                    <img src="../assets/icons/inactive.png">
                </td>
            </tr>
            `;
        }else{
            leadDetails += `
            <tr >
                <td>${leads[i].address}</td>
                <td>${leads[i].amount}</td>
                <td>${leads[i].companyName}</td>
                <td>${leads[i].contact_name}</td>
                <td>${leads[i].endDate}</td>
                <td>${leads[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown">
                            <button onclick="editLead(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewLead(${i})" class="openModalBtnView option-button">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button type="button" id="archive${i}" onclick="archiveLead(${i})" class="option-button">
                                <img src="../assetsPeter/leadarchive.png" />
                                Archive
                            </button>
                            <button onclick="deleteLead(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
                    <img src="../assets/icons/active.png">
                </td>
            </tr>
            `;
        }
        
    }
    if(leadsContainer){
        leadsContainer.innerHTML = leadDetails;
        leadsContainer.style.background = 'white';
        leadsContainer.style.color = 'black';
    }
    if(active_leads_table){
        activeLeads = leads.filter((lead)=>{
            return lead.status == 'Active';
        });
        var column = "";
        if(activeLeads.length > 0){
            for(var i=0; i < activeLeads.length; i++){
                column += `
            <tr >
                <td>${activeLeads[i].address}</td>
                <td>${activeLeads[i].amount}</td>
                <td>${activeLeads[i].companyName}</td>
                <td>${activeLeads[i].contact_name}</td>
                <td>${activeLeads[i].endDate}</td>
                <td>${activeLeads[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showActiveLeadsOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown">
                            <button onclick="editActiveLead(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewActiveLead(${i})" class="openModalBtnView option-button">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button type="button" id="archive${i}" onclick="archiveActiveLead(${i})" class="option-button">
                                <img src="../assetsPeter/leadarchive.png" />
                                Archive
                            </button>
                            <button onclick="deleteActiveLead(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
                    <style>
                    .completed {
                        border-radius: 12px;
                        background: rgba(84, 181, 129, 0.92);
                        display: flex;
                        width: 65px;
                        padding: 5px;
                        justify-content: center;
                        align-items: center;
                    }
                    </style>
                    <button class="option-button active">Won 
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="Cancel">
                        <path id="Vector" fill-rule="evenodd" clip-rule="evenodd" d="M8.10645 1.5C4.51645 1.5 1.60645 4.41 1.60645 8C1.60645 11.59 4.51645 14.5 8.10645 14.5C11.6964 14.5 14.6064 11.59 14.6064 8C14.6064 4.41 11.6964 1.5 8.10645 1.5ZM6.95978 6.14667C6.914 6.09754 6.8588 6.05814 6.79747 6.03081C6.73614 6.00348 6.66993 5.98879 6.60279 5.98761C6.53566 5.98642 6.46897 5.99877 6.40671 6.02392C6.34445 6.04907 6.2879 6.0865 6.24042 6.13398C6.19294 6.18145 6.15551 6.23801 6.13036 6.30027C6.10522 6.36253 6.09287 6.42921 6.09405 6.49635C6.09524 6.56348 6.10993 6.62969 6.13726 6.69103C6.16459 6.75236 6.20399 6.80756 6.25311 6.85333L7.39978 8L6.25311 9.14667C6.20399 9.19244 6.16459 9.24764 6.13726 9.30897C6.10993 9.37031 6.09524 9.43652 6.09405 9.50365C6.09287 9.57079 6.10522 9.63747 6.13036 9.69973C6.15551 9.76199 6.19294 9.81855 6.24042 9.86603C6.2879 9.9135 6.34445 9.95093 6.40671 9.97608C6.46897 10.0012 6.53566 10.0136 6.60279 10.0124C6.66993 10.0112 6.73614 9.99652 6.79747 9.96919C6.8588 9.94186 6.914 9.90246 6.95978 9.85333L8.10645 8.70667L9.25311 9.85333C9.29889 9.90246 9.35409 9.94186 9.41542 9.96919C9.47675 9.99652 9.54296 10.0112 9.6101 10.0124C9.67723 10.0136 9.74392 10.0012 9.80618 9.97608C9.86844 9.95093 9.92499 9.9135 9.97247 9.86603C10.0199 9.81855 10.0574 9.76199 10.0825 9.69973C10.1077 9.63747 10.12 9.57079 10.1188 9.50365C10.1177 9.43652 10.103 9.37031 10.0756 9.30897C10.0483 9.24764 10.0089 9.19244 9.95978 9.14667L8.81311 8L9.95978 6.85333C10.0089 6.80756 10.0483 6.75236 10.0756 6.69103C10.103 6.62969 10.1177 6.56348 10.1188 6.49635C10.12 6.42921 10.1077 6.36253 10.0825 6.30027C10.0574 6.23801 10.0199 6.18145 9.97247 6.13398C9.92499 6.0865 9.86844 6.04907 9.80618 6.02392C9.74392 5.99877 9.67723 5.98642 9.6101 5.98761C9.54296 5.98879 9.47675 6.00348 9.41542 6.03081C9.35409 6.05814 9.29889 6.09754 9.25311 6.14667L8.10645 7.29333L6.95978 6.14667Z" fill="#9A1D1D"/>
                        </g>
                        </svg>
                    </button>&nbsp;&nbsp;
                    <button class="option-button inactive">Lost 
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="Cancel">
                        <path id="Vector" fill-rule="evenodd" clip-rule="evenodd" d="M8.10645 1.5C4.51645 1.5 1.60645 4.41 1.60645 8C1.60645 11.59 4.51645 14.5 8.10645 14.5C11.6964 14.5 14.6064 11.59 14.6064 8C14.6064 4.41 11.6964 1.5 8.10645 1.5ZM6.95978 6.14667C6.914 6.09754 6.8588 6.05814 6.79747 6.03081C6.73614 6.00348 6.66993 5.98879 6.60279 5.98761C6.53566 5.98642 6.46897 5.99877 6.40671 6.02392C6.34445 6.04907 6.2879 6.0865 6.24042 6.13398C6.19294 6.18145 6.15551 6.23801 6.13036 6.30027C6.10522 6.36253 6.09287 6.42921 6.09405 6.49635C6.09524 6.56348 6.10993 6.62969 6.13726 6.69103C6.16459 6.75236 6.20399 6.80756 6.25311 6.85333L7.39978 8L6.25311 9.14667C6.20399 9.19244 6.16459 9.24764 6.13726 9.30897C6.10993 9.37031 6.09524 9.43652 6.09405 9.50365C6.09287 9.57079 6.10522 9.63747 6.13036 9.69973C6.15551 9.76199 6.19294 9.81855 6.24042 9.86603C6.2879 9.9135 6.34445 9.95093 6.40671 9.97608C6.46897 10.0012 6.53566 10.0136 6.60279 10.0124C6.66993 10.0112 6.73614 9.99652 6.79747 9.96919C6.8588 9.94186 6.914 9.90246 6.95978 9.85333L8.10645 8.70667L9.25311 9.85333C9.29889 9.90246 9.35409 9.94186 9.41542 9.96919C9.47675 9.99652 9.54296 10.0112 9.6101 10.0124C9.67723 10.0136 9.74392 10.0012 9.80618 9.97608C9.86844 9.95093 9.92499 9.9135 9.97247 9.86603C10.0199 9.81855 10.0574 9.76199 10.0825 9.69973C10.1077 9.63747 10.12 9.57079 10.1188 9.50365C10.1177 9.43652 10.103 9.37031 10.0756 9.30897C10.0483 9.24764 10.0089 9.19244 9.95978 9.14667L8.81311 8L9.95978 6.85333C10.0089 6.80756 10.0483 6.75236 10.0756 6.69103C10.103 6.62969 10.1177 6.56348 10.1188 6.49635C10.12 6.42921 10.1077 6.36253 10.0825 6.30027C10.0574 6.23801 10.0199 6.18145 9.97247 6.13398C9.92499 6.0865 9.86844 6.04907 9.80618 6.02392C9.74392 5.99877 9.67723 5.98642 9.6101 5.98761C9.54296 5.98879 9.47675 6.00348 9.41542 6.03081C9.35409 6.05814 9.29889 6.09754 9.25311 6.14667L8.10645 7.29333L6.95978 6.14667Z" fill="#9A1D1D"/>
                        </g>
                        </svg>
                    </button>
                </td>
            </tr>
            `;
            }
            if(active_leads_table){
                active_leads_table.innerHTML = column;
                active_leads_table.style.background = 'white';
                active_leads_table.style.color = 'black';
            }
        }else{
            active_leads_table.innerHTML = 'No record found!';
            active_leads_table.style.background = '#091e42';
            active_leads_table.style.color = 'white';
        }
    }
    if(average_leads_table){
        var averageLeads = leads.filter((lead)=>{
            return lead.status == 'Completed';
        });
        var midPoint = Math.floor(averageLeads.length / 2);
        firstHalfData = averageLeads.slice(0, midPoint);
        var column2 = "";
        if(firstHalfData.length > 0){
            for(var i=0; i < firstHalfData.length; i++){
                column2 += `
            <tr >
                <td>${firstHalfData[i].address}</td>
                <td>${firstHalfData[i].amount}</td>
                <td>${firstHalfData[i].companyName}</td>
                <td>${firstHalfData[i].contact_name}</td>
                <td>${firstHalfData[i].endDate}</td>
                <td>${firstHalfData[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showAverageOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown">
                            <button onclick="editAverageLead(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewAverageLead(${i})" class="openModalBtnView option-button">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button type="button" id="archive${i}" onclick="archiveAverageLead(${i})" class="option-button">
                                <img src="../assetsPeter/leadarchive.png" />
                                Archive
                            </button>
                            <button onclick="deleteAverageLead(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
                    <style>
                    .completed {
                        border-radius: 12px;
                        background: rgba(84, 181, 129, 0.92);
                        display: flex;
                        width: 65px;
                        padding: 5px;
                        justify-content: center;
                        align-items: center;
                    }
                    </style>
                    <button class="option-button active">Won 
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="Cancel">
                        <path id="Vector" fill-rule="evenodd" clip-rule="evenodd" d="M8.10645 1.5C4.51645 1.5 1.60645 4.41 1.60645 8C1.60645 11.59 4.51645 14.5 8.10645 14.5C11.6964 14.5 14.6064 11.59 14.6064 8C14.6064 4.41 11.6964 1.5 8.10645 1.5ZM6.95978 6.14667C6.914 6.09754 6.8588 6.05814 6.79747 6.03081C6.73614 6.00348 6.66993 5.98879 6.60279 5.98761C6.53566 5.98642 6.46897 5.99877 6.40671 6.02392C6.34445 6.04907 6.2879 6.0865 6.24042 6.13398C6.19294 6.18145 6.15551 6.23801 6.13036 6.30027C6.10522 6.36253 6.09287 6.42921 6.09405 6.49635C6.09524 6.56348 6.10993 6.62969 6.13726 6.69103C6.16459 6.75236 6.20399 6.80756 6.25311 6.85333L7.39978 8L6.25311 9.14667C6.20399 9.19244 6.16459 9.24764 6.13726 9.30897C6.10993 9.37031 6.09524 9.43652 6.09405 9.50365C6.09287 9.57079 6.10522 9.63747 6.13036 9.69973C6.15551 9.76199 6.19294 9.81855 6.24042 9.86603C6.2879 9.9135 6.34445 9.95093 6.40671 9.97608C6.46897 10.0012 6.53566 10.0136 6.60279 10.0124C6.66993 10.0112 6.73614 9.99652 6.79747 9.96919C6.8588 9.94186 6.914 9.90246 6.95978 9.85333L8.10645 8.70667L9.25311 9.85333C9.29889 9.90246 9.35409 9.94186 9.41542 9.96919C9.47675 9.99652 9.54296 10.0112 9.6101 10.0124C9.67723 10.0136 9.74392 10.0012 9.80618 9.97608C9.86844 9.95093 9.92499 9.9135 9.97247 9.86603C10.0199 9.81855 10.0574 9.76199 10.0825 9.69973C10.1077 9.63747 10.12 9.57079 10.1188 9.50365C10.1177 9.43652 10.103 9.37031 10.0756 9.30897C10.0483 9.24764 10.0089 9.19244 9.95978 9.14667L8.81311 8L9.95978 6.85333C10.0089 6.80756 10.0483 6.75236 10.0756 6.69103C10.103 6.62969 10.1177 6.56348 10.1188 6.49635C10.12 6.42921 10.1077 6.36253 10.0825 6.30027C10.0574 6.23801 10.0199 6.18145 9.97247 6.13398C9.92499 6.0865 9.86844 6.04907 9.80618 6.02392C9.74392 5.99877 9.67723 5.98642 9.6101 5.98761C9.54296 5.98879 9.47675 6.00348 9.41542 6.03081C9.35409 6.05814 9.29889 6.09754 9.25311 6.14667L8.10645 7.29333L6.95978 6.14667Z" fill="#9A1D1D"/>
                        </g>
                        </svg>
                    </button>&nbsp;&nbsp;
                    <button class="option-button inactive">Lost 
                        <svg width="17" height="16" viewBox="0 0 17 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <g id="Cancel">
                        <path id="Vector" fill-rule="evenodd" clip-rule="evenodd" d="M8.10645 1.5C4.51645 1.5 1.60645 4.41 1.60645 8C1.60645 11.59 4.51645 14.5 8.10645 14.5C11.6964 14.5 14.6064 11.59 14.6064 8C14.6064 4.41 11.6964 1.5 8.10645 1.5ZM6.95978 6.14667C6.914 6.09754 6.8588 6.05814 6.79747 6.03081C6.73614 6.00348 6.66993 5.98879 6.60279 5.98761C6.53566 5.98642 6.46897 5.99877 6.40671 6.02392C6.34445 6.04907 6.2879 6.0865 6.24042 6.13398C6.19294 6.18145 6.15551 6.23801 6.13036 6.30027C6.10522 6.36253 6.09287 6.42921 6.09405 6.49635C6.09524 6.56348 6.10993 6.62969 6.13726 6.69103C6.16459 6.75236 6.20399 6.80756 6.25311 6.85333L7.39978 8L6.25311 9.14667C6.20399 9.19244 6.16459 9.24764 6.13726 9.30897C6.10993 9.37031 6.09524 9.43652 6.09405 9.50365C6.09287 9.57079 6.10522 9.63747 6.13036 9.69973C6.15551 9.76199 6.19294 9.81855 6.24042 9.86603C6.2879 9.9135 6.34445 9.95093 6.40671 9.97608C6.46897 10.0012 6.53566 10.0136 6.60279 10.0124C6.66993 10.0112 6.73614 9.99652 6.79747 9.96919C6.8588 9.94186 6.914 9.90246 6.95978 9.85333L8.10645 8.70667L9.25311 9.85333C9.29889 9.90246 9.35409 9.94186 9.41542 9.96919C9.47675 9.99652 9.54296 10.0112 9.6101 10.0124C9.67723 10.0136 9.74392 10.0012 9.80618 9.97608C9.86844 9.95093 9.92499 9.9135 9.97247 9.86603C10.0199 9.81855 10.0574 9.76199 10.0825 9.69973C10.1077 9.63747 10.12 9.57079 10.1188 9.50365C10.1177 9.43652 10.103 9.37031 10.0756 9.30897C10.0483 9.24764 10.0089 9.19244 9.95978 9.14667L8.81311 8L9.95978 6.85333C10.0089 6.80756 10.0483 6.75236 10.0756 6.69103C10.103 6.62969 10.1177 6.56348 10.1188 6.49635C10.12 6.42921 10.1077 6.36253 10.0825 6.30027C10.0574 6.23801 10.0199 6.18145 9.97247 6.13398C9.92499 6.0865 9.86844 6.04907 9.80618 6.02392C9.74392 5.99877 9.67723 5.98642 9.6101 5.98761C9.54296 5.98879 9.47675 6.00348 9.41542 6.03081C9.35409 6.05814 9.29889 6.09754 9.25311 6.14667L8.10645 7.29333L6.95978 6.14667Z" fill="#9A1D1D"/>
                        </g>
                        </svg>
                    </button>
                </td>
            </tr>
            `;
            }
            if(average_leads_table){
                average_leads_table.innerHTML = column2;
                average_leads_table.style.background = 'white';
                average_leads_table.style.color = 'black';
            }
        }else{
            average_leads_table.innerHTML = 'No record found!';
            average_leads_table.style.background = '#091e42';
            average_leads_table.style.color = 'white';
        }
    }
}

function filterLeads(leads){
    var activeLeadsElement = document.getElementById('active-leads');
    var averageLeadWonElement = document.getElementById('average-lead-won');
    var activeLeads = [];
    var inactiveLeads = [];
    var averageLeads = [];
    var completedLeads = [];
    if(leads && leads.length > 0){
        for(let lead of leads){
            if(lead.status == 'Active'){
                activeLeads.push(lead);
            }
            if(lead.status == 'Inactive'){
                inactiveLeads.push(lead);
            }
            if(lead.status == 'Completed'){
                completedLeads.push(lead);
            }
        }
    }
    
    if(activeLeadsElement){
        if(activeLeads.length > 0){
            activeLeadsElement.innerHTML = activeLeads.length;
        }else{
            activeLeadsElement.innerHTML = 0;
        }
        
    }
    var averageWins = completedLeads.length / 2;
    if(averageLeadWonElement){
        if(averageWins > 0){
            averageLeadWonElement.innerHTML = averageWins;
        }else{
            averageLeadWonElement.innerHTML = 0;
        }
        
    }
}
function deleteActiveLead(indexNumber){
    var lead = activeLeads[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('lead_id', lead.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getLeads();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-lead', true);
            xhttp.send(formData);
        }
    });
}
function deleteLead(indexNumber){
    var lead = leads[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('lead_id', lead.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getLeads();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-lead', true);
            xhttp.send(formData);
        }
    });
}
function deleteAverageLead(indexNumber){
    var lead = firstHalfData[indexNumber];
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('lead_id', lead.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getLeads();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-lead', true);
            xhttp.send(formData);
        }
    });
}
var optionIndexNumber;
function showOptions(indexNumber){
    optionIndexNumber = indexNumber;
    var optionCard = document.getElementById(indexNumber);
    optionCard.style.display = 'block';
}
function showActiveLeadsOptions(indexNumber){
    optionIndexNumber = indexNumber;
    var optionCard = document.getElementById(indexNumber);
    optionCard.style.display = 'block';
}
function showAverageOptions(indexNumber){
    optionIndexNumber = indexNumber;
    var optionCard = document.getElementById(indexNumber);
    optionCard.style.display = 'block';
}
document.addEventListener('click', function(event){
    var optionCard = document.getElementById(optionIndexNumber);
    var threeDots = document.getElementsByClassName('three');
    
    for(var i=0; i < threeDots.length; i++){
        if(i == optionIndexNumber){
            if(!threeDots[i].contains(event.target)){
                optionCard.style.display = 'none';
            }
        }
        // if(optionCard && clickedElement.contains(dot)){
        //     optionCard.style.display = 'block';
        // }else{
        //     optionCard.style.display = 'none';
        // }
    }
});
function editLead(indexNumber){
    var lead = leads[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 50px;
            padding: 7px 17px;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Lead</h3>
            </div>
            <form id="form">
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="contactName">Company Name</label>
                            <input type="text" value="${lead.companyName}" id="companyName2" name="contactName" />
                        </div>
                        <div class="single-form">
                            <label for="address">Title</label>
                            <input type="text" value="${lead.address}" id="address2" name="address" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="amount">Value</label>
                            <input type="text" value="${lead.amount}" id="amount2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="descripition">Contact Name</label>
                            <input type="text" value="${lead.contact_name}" id="contact-name2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="rgistration">CAC Registration</label>
                            <input type="text" value="${lead.cac_reg}" id="cac_reg2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="ownership">Ownership Type</label>
                            <input type="text" value="${lead.owner_type}" id="owner_type2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="tax">Tax Number(TIN)</label>
                            <input type="text" value="${lead.tax_number}" id="tax_number2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="vat">VAT Number</label>
                            <input type="text" value="${lead.vat_number}" id="vat_number2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="bank name">Bank Name</label>
                            <input type="text" value="${lead.bank_name}" id="bank_name2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank country">Bank Country</label>
                            <input type="text" value="${lead.bank_country}" id="bank_country2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="account name">Account Name</label>
                            <input type="text" value="${lead.account_name}" id="account_name2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="account number">Account Number</label>
                            <input type="text" value="${lead.account_number}" id="account_number2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Sort Code</label>
                            <input type="text" value="${lead.bank_code}" id="bank_code2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank branch">Bank Branch</label>
                            <input type="text" value="${lead.bank_branch}" id="bank_branch2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Address</label>
                            <input type="text" value="${lead.bank_address}" id="bank_address2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="business category">Business Category</label>
                            <input type="text" value="${lead.business_category}" id="business_category2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="web link">Web Link</label>
                            <input type="text" value="${lead.web_link}" id="web_link2" name="text" />
                        </div>
                        <div class="single-form">
                            <label>Social media handles</label>
                            <input type="text" value="${lead.social_handle}" id="social_handle2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="status">Status</label>
                            <select id='status2' class="select-input">
                                <option value="${lead.status}">Please select</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="endDate">Date Of Connection</label>
                            <input type="date" value="${lead.endDate}" id="endDate2" name="modifiedDate" />
                        </div>
                    </div>

                    <button type='button' onclick="updateLead(${lead.id})" class="edit-button" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editActiveLead(indexNumber){
    var lead = activeLeads[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Lead</h3>
            </div>
            <form id="form">
                <div class="form-class">
                    <label for="contactName">Company Name</label>
                    <input type="text" id="companyName" value="${lead.companyName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="address">Title</label>
                    <input type="text" id="address" value="${lead.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="amount">Value</label>
                    <input type="text" id="amount" value="${lead.amount}" name="text" />
                </div>
                <div class="sub-form">
                    <div class="single-form">
                        <label for="status">Status</label>
                        <select id='status' class="select-input">
                            <option value="${lead.status}">Please select</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="single-form">
                        <label for="endDate">Due Date</label>
                        <input type="date" id="endDate" value="${lead.endDate}" name="modifiedDate" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="descripition">Contact Name</label>
                    <input type="text" id="descripition" style="text-align: left;" value="${lead.descripition}" />
                </div>
                        <button type='button' class="edit-button" onclick="updateLead(${lead.id})" id="save-btn">Update</button>  
                    </form> 
                </div>
            </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editAverageLead(indexNumber){
    var lead = firstHalfData[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Lead</h3>
            </div>
            <form id="form">
                <div class="form-class">
                    <label for="contactName">Company Name</label>
                    <input type="text" id="companyName" value="${lead.companyName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="address">Title</label>
                    <input type="text" id="address" value="${lead.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="amount">Value</label>
                    <input type="text" id="amount" value="${lead.amount}" name="text" />
                </div>
                <div class="sub-form">
                    <div class="single-form">
                        <label for="status">Status</label>
                        <select id='status' class="select-input">
                            <option value="${lead.status}">Please select</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="single-form">
                        <label for="endDate">Due Date</label>
                        <input type="date" id="endDate" value="${lead.endDate}" name="modifiedDate" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="descripition">Contact Name</label>
                    <input type="text" id="descripition" style="text-align: left;" value="${lead.descripition}" />
                </div>
                <button type='button' class="edit-button" onclick="updateLead(${lead.id})" id="save-btn">Update</button>  
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function updateLead(id){
    var modal = document.getElementById('myModal');
    var openModalBtn = document.getElementById("save-btn");
    var form = document.getElementById('form');
    
    var companyName = document.getElementById("companyName2").value;
    var address = document.getElementById("address2").value;
    var amount = document.getElementById("amount2").value;
    var contact_name = document.getElementById("contact-name2").value;
    var cac_reg = document.getElementById("cac_reg2").value;
    var owner_type = document.getElementById("owner_type2").value;
    var tax_number = document.getElementById("tax_number2").value;
    var vat_number = document.getElementById("vat_number2").value;
    var bank_name = document.getElementById("bank_name2").value;
    var bank_country = document.getElementById("bank_country2").value;
    var account_name = document.getElementById("account_name2").value;
    var account_number = document.getElementById("account_number2").value;
    var bank_code = document.getElementById("bank_code2").value;
    var bank_branch = document.getElementById("bank_branch2").value;
    var bank_address = document.getElementById("bank_address2").value;
    var business_category = document.getElementById("business_category2").value;
    var web_link = document.getElementById("web_link2").value;
    var social_handle = document.getElementById("social_handle2").value;
    var status = document.getElementById("status2").value;
    var endDate = document.getElementById("endDate2").value;
    
    if(companyName == ''){
        swal('Oops', 'Please fill out the form to proceed', 'error');
    }else{
        var formData = new FormData();
        // formData.append('contactId', contactId);
        formData.append('companyName', companyName);
        formData.append('address', address);
        formData.append('amount', amount);
        formData.append('contact_name', contact_name);
        formData.append('cac_reg', cac_reg);
        formData.append('owner_type', owner_type);
        formData.append('tax_number', tax_number);
        formData.append('vat_number', vat_number);
        formData.append('bank_name', bank_name);
        formData.append('bank_country', bank_country);
        formData.append('account_name', account_name);
        formData.append('account_number', account_number);
        formData.append('bank_code', bank_code);
        formData.append('bank_branch', bank_branch);
        formData.append('bank_address', bank_address);
        formData.append('business_category', business_category);
        formData.append('web_link', web_link);
        formData.append('social_handle', social_handle);
        formData.append('status', status);
        formData.append('endDate', endDate);
        formData.append('lead_id', id);
        openModalBtn.disabled = true;
        openModalBtn.innerHTML = "Updating...";
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            form.reset();
            var response = JSON.parse(xhttp.response);
            if(response.success){
                getLeads();
               swal('Hurray', response.success, 'success');
            }
            else{
                swal('Sorry', response.error, 'error');
                
            }
        }
        xhttp.onerror = function(error){
            modal.style.display = 'none';
            openModalBtn.disabled = false;
            openModalBtn.innerHTML = "Update";
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open("POST", serverUrl+'?function=update-lead', true);
        xhttp.send(formData);
    }
}
function viewLead(indexNumber){
    var lead = leads[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Lead</h3>
            </div>
            <form id="form">
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="contactName">Company Name</label>
                            <input type="text" readonly value="${lead.companyName}" id="companyName2" name="contactName" />
                        </div>
                        <div class="single-form">
                            <label for="address">Title</label>
                            <input type="text" readonly value="${lead.address}" id="address2" name="address" />
                        </div>
                    </div>
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="amount">Value</label>
                            <input type="text" readonly value="${lead.amount}" id="amount2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="descripition">Contact Name</label>
                            <input type="text" readonly value="${lead.contact_name}" id="contact-name2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="rgistration">CAC Registration</label>
                            <input type="text" readonly value="${lead.cac_reg}" id="cac_reg2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="ownership">Ownership Type</label>
                            <input type="text" readonly value="${lead.owner_type}" id="owner_type2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="tax">Tax Number(TIN)</label>
                            <input type="text" readonly value="${lead.tax_number}" id="tax_number2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="vat">VAT Number</label>
                            <input type="text" readonly value="${lead.vat_number}" id="vat_number2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="bank name">Bank Name</label>
                            <input type="text" readonly value="${lead.bank_name}" id="bank_name2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank country">Bank Country</label>
                            <input type="text" readonly value="${lead.bank_country}" id="bank_country2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="account name">Account Name</label>
                            <input type="text" readonly value="${lead.account_name}" id="account_name2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="account number">Account Number</label>
                            <input type="text" readonly value="${lead.account_number}" id="account_number2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Sort Code</label>
                            <input type="text" readonly value="${lead.bank_code}" id="bank_code2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="bank branch">Bank Branch</label>
                            <input type="text" readonly value="${lead.bank_branch}" id="bank_branch2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bank sort code">Bank Address</label>
                            <input type="text" readonly value="${lead.bank_address}" id="bank_address2" name="text" />
                        </div>
                        <div class="single-form">
                            <label for="business category">Business Category</label>
                            <input type="text" readonly value="${lead.business_category}" id="business_category2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="web link">Web Link</label>
                            <input type="text" readonly value="${lead.web_link}" id="web_link2" name="text" />
                        </div>
                        <div class="single-form">
                            <label>Social media handles</label>
                            <input type="text" readonly value="${lead.social_handle}" id="social_handle2" style="text-align: left;" />
                        </div>
                    </div>   
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="status">Status</label>
                            <select id='status2' readonly class="select-input">
                                <option value="${lead.status}">${lead.status}</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="endDate">Date Of Connection</label>
                            <input type="date" value="${lead.endDate}" readonly id="endDate2" name="modifiedDate" />
                        </div>
                    </div>

                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewActiveLead(indexNumber){
    var lead = activeLeads[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Lead</h3>
            </div>
            <form id="form">
                <div class="form-class">
                    <label for="contactName">Company Name</label>
                    <input type="text" id="companyName" readonly value="${lead.companyName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="address">Title</label>
                    <input type="text" id="address" readonly value="${lead.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="amount">Value</label>
                    <input type="text" id="amount" readonly value="${lead.amount}" name="text" />
                </div>
                <div class="sub-form">
                    <div class="single-form">
                        <label for="status">Status</label>
                        <select id='status' readonly class="select-input">
                            <option value="${lead.status}">Please select</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="single-form">
                        <label for="endDate">Due Date</label>
                        <input type="date" readonly id="endDate" value="${lead.endDate}" name="modifiedDate" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="descripition">Contact Name</label>
                    <input type="text" id="descripition" readonly style="text-align: left;" value="${lead.descripition}" />
                </div>   
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewAverageLead(indexNumber){
    var lead = firstHalfData[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Lead</h3>
            </div>
            <form id="form">
                <div class="form-class">
                    <label for="contactName">Company Name</label>
                    <input type="text" id="companyName" readonly value="${lead.companyName}" name="contactName" />
                </div>
                <div class="form-class">
                    <label for="address">Title</label>
                    <input type="text" id="address" readonly value="${lead.address}" name="address" />
                </div>
                <div class="form-class">
                    <label for="amount">Value</label>
                    <input type="text" id="amount" readonly value="${lead.amount}" name="text" />
                </div>
                <div class="sub-form">
                    <div class="single-form">
                        <label for="status">Status</label>
                        <select id='status' readonly class="select-input">
                            <option value="${lead.status}">Please select</option>
                            <option value="Active">Active</option>
                            <option value="Inactive">Inactive</option>
                            <option value="Completed">Completed</option>
                        </select>
                    </div>
                    <div class="single-form">
                        <label for="endDate">Due Date</label>
                        <input type="date" readonly id="endDate" value="${lead.endDate}" name="modifiedDate" />
                    </div>
                </div>
                <div class="form-class">
                    <label for="descripition">Contact Name</label>
                    <input type="text" id="descripition" readonly style="text-align: left;" value="${lead.descripition}" />
                </div>   
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function archiveLead(indexNumber){
    var archiveBtn = document.getElementById('archive'+indexNumber);
    var lead = leads[indexNumber];
    var formData = new FormData();
    formData.append('lead_id', lead.id);
    archiveBtn.innerHTML = 'Archiving...';
    archiveBtn.disabled = true;
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        var response = JSON.parse(xhttp.response);
        getLeads();
    }
    xhttp.onerror = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=archive-lead', true);
    xhttp.send(formData);
}
function archiveActiveLead(indexNumber){
    var archiveBtn = document.getElementById('archive'+indexNumber);
    var lead = activeLeads[indexNumber];
    var formData = new FormData();
    formData.append('lead_id', lead.id);
    archiveBtn.innerHTML = 'Archiving...';
    archiveBtn.disabled = true;
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        var response = JSON.parse(xhttp.response);
        getLeads();
    }
    xhttp.onerror = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=archive-lead', true);
    xhttp.send(formData);
}
function archiveAverageLead(indexNumber){
    var archiveBtn = document.getElementById('archive'+indexNumber);
    var lead = firstHalfData[indexNumber];
    var formData = new FormData();
    formData.append('lead_id', lead.id);
    archiveBtn.innerHTML = 'Archiving...';
    archiveBtn.disabled = true;
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        var response = JSON.parse(xhttp.response);
        getLeads();
    }
    xhttp.onerror = function(){
        archiveBtn.innerHTML = 'Archive';
        archiveBtn.disabled = false;
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=archive-lead', true);
    xhttp.send(formData);
}
var archives = [];
function getArchives(){
    var container = document.getElementById('archive-table');
    if(container){
        container.innerHTML = 'Please wait...';
        container.style.background = '#091e42';
        container.style.color = 'white';
    }
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        archives = response.archives;
        if(archives){
            loopArchives(archives);
        }else{
            if(container){
                container.innerHTML = 'No record found!';
                container.style.background = '#091e42';
                container.style.color = 'white';
            }
        }
    }
    xhttp.open('GET', serverUrl+'?function=get-archives');
    xhttp.send();
}
getArchives();
function loopArchives(archives){
    var container = document.getElementById('archive-table');
    var details = '';
    for(var i=0; i < archives.length; i++){
        if(archives[i].status == 'Active'){
            details += `
            <tr >
                <td>${archives[i].address}</td>
                <td>${archives[i].amount}</td>
                <td>${archives[i].companyName}</td>
                <td>${archives[i].descripition}</td>
                <td>${archives[i].endDate}</td>
                <td>${archives[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown" style="width: 200px;">
                            <button onclick="unArchiveLead(${i})" class="openModalBtnEdit option-button" style="display: contents;">
                                <img src="../assets/icons/delete.png"/> Unarchive
                            </button>
                            <br>
                            <button onclick="viewArchiveLead(${i})" class="openModalBtnView option-button" style="display: contents;">
    
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <br>
                            <button class="option-button" onclick="deleteArchive(${i})" style="display: contents;">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete permanently
                            </button>
                            
                        </div>
                    </div>
                    <img src="../assets/icons/fade-active.png">&nbsp;&nbsp;
                    <img src="../assets/icons/fade-inactive.png">
                </td>
            </tr>
            `;
        }else if(archives[i].status == 'Inactive'){
            details += `
            <tr >
                <td>${archives[i].address}</td>
                <td>${archives[i].amount}</td>
                <td>${archives[i].companyName}</td>
                <td>${archives[i].phone}</td>
                <td>${archives[i].endDate}</td>
                <td>${archives[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown" style="width: 200px;">
                            <button onclick="unArchiveLead(${i})" class="openModalBtnEdit option-button" style="display: contents;">
                                <img src="../assets/icons/delete.png"/> Unarchive
                            </button>
                            <br>
                            <button onclick="viewArchiveLead(${i})" class="openModalBtnView option-button" style="display: contents;">

                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <br>
                            <button class="option-button" onclick="deleteArchive(${i})" style="display: contents;">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete permanently
                            </button>
                            
                        </div>
                    </div>
                    <img src="../assets/icons/inactive.png">
                </td>
            </tr>
            `;
        }else{
            details += `
            <tr >
                <td>${archives[i].address}</td>
                <td>${archives[i].amount}</td>
                <td>${archives[i].companyName}</td>
                <td>${archives[i].phone}</td>
                <td>${archives[i].endDate}</td>
                <td>${archives[i].status}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button onclick="showOptions(${i})" class="three" >
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
    
                        <div id='${i}' class="options-dropdown" style="width: 200px;">
                            <button onclick="unArchiveLead(${i})" class="openModalBtnEdit option-button" style="display: contents;">
                                <img src="../assets/icons/delete.png"/> Unarchive
                            </button>
                            <br>
                            <button onclick="viewArchiveLead(${i})" class="openModalBtnView option-button" style="display: contents;">

                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <br>
                            <button class="option-button" onclick="deleteArchive(${i})" style="display: contents;">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete permanently
                            </button>
                            
                        </div>
                    </div>
                    <img src="../assets/icons/active.png">
                </td>
            </tr>
            `;
        }
        
    }
    if(container){
        container.innerHTML = details;
        container.style.background = 'white';
        container.style.color = 'black';
    }
}
function unArchiveLead(indexNumber){
    var archive = archives[indexNumber];
    var formData = new FormData();
    formData.append('lead_id', archive.lead_id);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        getArchives();
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=unarchive-lead', true);
    xhttp.send(formData);
}
function viewArchiveLead(indexNumber){
    var archive = archives[indexNumber];
    window.localStorage.setItem('archive', JSON.stringify(archive));
    window.location.href = '../contact/view.html';
    // var modals = document.getElementById('modals');
    // var modalContent = `
    // <style>
    //     .select-input{
    //         display: flex;
    //         width: 88%;
    //         height: 24px;
    //         padding: 7px 17px;
    //         align-items: flex-start;
    //         gap: 10px;
    //         flex-shrink: 0;
    //         border-radius: 8px;
    //         border: 1px solid var(--Foundation-Primary-P400, #0047B3);
    //         background: var(--Foundation-White-W300, #F6F6F6);
    //     }
    // </style>
    // <div id="myModal" class="modal-container">
    //     <div class="modal-content">
    //         <span onclick="closeModal()" class="close">&times;</span>
    //         <div class="add-text">
    //             <h3>View Lead</h3>
    //         </div>
    //         <form id="form">
    //                 <div class="form-class">
    //                     <label for="contactName">Company Name</label>
    //                     <input type="text" id="companyName" readonly value="${archive.companyName}" name="contactName" />
    //                 </div>
    //                 <div class="form-class">
    //                     <label for="address">Title</label>
    //                     <input type="text" id="address" readonly value="${archive.address}" name="address" />
    //                 </div>
    //                 <div class="sub-form">
    //                     <div class="single-form">
    //                         <label for="amount">Amount</label>
    //                         <input type="text" id="amount" readonly value="${archive.amount}" name="text" />
    //                     </div>
    //                     <div class="single-form">
    //                         <label>Currency</label>
    //                         <input type="text" id="currency" readonly value="${archive.currency}" name="text" />
    //                     </div>
                        
    //                 </div>
    //                 <div class="sub-form">
    //                     <div class="single-form">
    //                         <label for="status">Status</label>
    //                         <input type="text" id="status" readonly value="${archive.status}" name="text" />
    //                     </div>
    //                     <div class="single-form">
    //                         <label for="email">Email</label>
    //                         <input type="text" id="email" readonly value="${archive.email}" name="source" />
    //                     </div>
    //                 </div>
    //                 <div class="sub-form">
    //                     <div class="single-form">
    //                         <label for="startDate">Start Date</label>
    //                         <input type="date" id="startDate" readonly value="${archive.startDate}" name="modifiedDate" />
    //                     </div>
    //                     <div class="single-form">
    //                         <label for="endDate">Due Date</label>
    //                         <input type="date" id="endDate" readonly value="${archive.endDate}" name="modifiedDate" />
    //                     </div>
    //                 </div>
    //                 <div class="form-class">
    //                     <label for="descripition">Description</label>
    //                     <textarea rows="10" id="descripition" readonly cols="50">
    //                     ${archive.descripition}
    //                       </textarea>
    //                 </div>
    //             </form> 
    //     </div>
    // </div>
    // `;
    // if(modals){
    //     modals.innerHTML = modalContent;
    //     openModal();
    // }
}
function deleteArchive(indexNumber){
    var archive = archives[indexNumber];
    var formData = new FormData();
    formData.append('archive_id', archive.id);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        getArchives();
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=delete-archive', true);
    xhttp.send(formData);
}
var modals = document.getElementsByClassName('modal-container');
var forms = document.getElementsByTagName("form");


function saveProject(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
    var project_title = document.getElementById('project_title').value;
    var email = document.getElementById('email').value;
    var start_date = document.getElementById('start_date').value;
    var end_date = document.getElementById('end_date').value;
    var lead = document.getElementById('lead').value;
    var status = document.getElementById('status').value;
    var priority = document.getElementById('priority').value;
    var completion = document.getElementById('completion').value;
    var cost = document.getElementById('cost').value;
    var supervision_level = document.getElementById('supervision_level').value;
    var description = document.getElementById('description').value;
    var remark = document.getElementById('remark').value;
    
    var formData = new FormData();
    formData.append('project_title', project_title);
    formData.append('email', email);
    formData.append('start_date', start_date);
    formData.append('end_date', end_date);
    formData.append('lead', lead);
    formData.append('status', status);
    formData.append('priority', priority);
    formData.append('completion', completion);
    formData.append('cost', cost);
    formData.append('supervision_level', supervision_level);
    formData.append('description', description);
    formData.append('remark', remark);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Project saved!", 'success');
        getProjects();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-project', true);
    xhttp.send(formData);
}
var projects = [];
function getProjects(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        projects = response.projects;
        loopProjects();
    }
    xhttp.open('GET', serverUrl+'?function=get-projects', true);
    xhttp.send();
}
getProjects();
var ongoing_projects = [];
var completed_projects = [];
var pending_projects = [];
function loopProjects(){
    var ongoing_container = document.getElementById('ongoing-projects');
    var completed_container = document.getElementById('completed-projects');
    var pending_container = document.getElementById('pending-projects');
    var ongoing_tr="";
    var completed_tr="";
    var pending_tr="";
    ongoing_projects = projects.filter((project)=>{
        return project.status == "In Progress";
    });
    completed_projects = projects.filter((project)=>{
        return project.status == "Completed";
    });
    pending_projects = projects.filter((project)=>{
        return project.status == "Pending";
    });
    for(var i=0; i < ongoing_projects.length; i++){
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var start_date = ongoing_projects[i].start_date;
        var start_date_formatted = new Date(start_date).toDateString();
        
        //for end date as well
        var end_date = ongoing_projects[i].due_date;
        var end_date_formatted = new Date(end_date).toDateString();;
        var project_id = ongoing_projects[i].id;
        var email = ongoing_projects[i].email ? ongoing_projects[i].email : "No data";
        ongoing_tr += `
            <tr >
                <td>${ongoing_projects[i].project_title}</td>
                <td>${ongoing_projects[i].lead}</td>
                <td>${start_date_formatted}</td>
                <td>${end_date_formatted}</td>
                <td>${ongoing_projects[i].status}</td>
                <td>${ongoing_projects[i].completion}</td>
                <td>${ongoing_projects[i].priority}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button id="clicked-btn-${project_id}" onclick="showOngoingProjectOptions(${project_id})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
        
                        <div id="ongoing-project-${project_id}" class="options-dropdown" style="display: none;">
                            <a href="mailto:${email}" class="openModalBtnEdit option-button">
                                <img src="../assetsPeter/reminder.png"/> Send Reminder
                            </a>
                            <button onclick="window.location.href='./upload.html?project_id=${project_id}'" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/upload-bar.png"/> Upload
                            </button>
                            <button onclick="editProject()" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewProject()" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteLead()" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
               
                </td>
            </tr>
        `;
    }
    if(ongoing_container){
        ongoing_container.innerHTML = ongoing_tr;
    }
    //for completed projects
    for(var i=0; i < completed_projects.length; i++){
        var start_date = completed_projects[i].start_date;
        var start_date_formatted = new Date(start_date).toDateString();
        
        //for end date as well
        var end_date = completed_projects[i].due_date;
        var end_date_formatted = new Date(end_date).toDateString();;
        var project_id = completed_projects[i].id;
        completed_tr += `
            <tr >
                <td>${completed_projects[i].project_title}</td>
                <td>${completed_projects[i].lead}</td>
                <td>${start_date_formatted}</td>
                <td>${end_date_formatted}</td>
                <td>${completed_projects[i].status}</td>
                <td>${completed_projects[i].completion}</td>
                <td>${completed_projects[i].priority}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button id="completed-clicked-btn-${project_id}" onclick="showCompletedProjectOptions(${project_id})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
        
                        <div id="completed-project-${project_id}" class="options-dropdown" style="display: none;">
                            <button  class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/reminder.png"/> Send Reminder
                            </button>
                            <button onclick="window.location.href='./upload.html'" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/upload-bar.png"/> Upload
                            </button>
                            <button onclick="editProject()" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewProject()" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteLead()" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
               
                </td>
            </tr>
        `;
    }
    if(completed_container){
        completed_container.innerHTML = completed_tr;
    }
    //for pending projects
    for(var i=0; i < pending_projects.length; i++){
        var start_date = pending_projects[i].start_date;
        var start_date_formatted = new Date(start_date).toDateString();
        
        //for end date as well
        var end_date = pending_projects[i].due_date;
        var end_date_formatted = new Date(end_date).toDateString();;
        var project_id = pending_projects[i].id;
        pending_tr += `
            <tr >
                <td>${pending_projects[i].project_title}</td>
                <td>${pending_projects[i].lead}</td>
                <td>${start_date_formatted}</td>
                <td>${end_date_formatted}</td>
                <td>${pending_projects[i].status}</td>
                <td>${pending_projects[i].completion}</td>
                <td>${pending_projects[i].priority}</td>
                <td style="display: flex; gap: 10px;">
                    <div>
                        <button id="pending-clicked-btn-${project_id}" onclick="showPendingProjectOptions(${project_id})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
        
                        <div id="pending-project-${project_id}" class="options-dropdown" style="display: none;">
                            <button  class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/reminder.png"/> Send Reminder
                            </button>
                            <button onclick="window.location.href='./upload.html'" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/upload-bar.png"/> Upload
                            </button>
                            <button onclick="editProject()" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewProject()" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deleteLead()" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                            
                        </div>
                    </div>
               
                </td>
            </tr>
        `;
    }
    if(pending_container){
        pending_container.innerHTML = pending_tr;
    }
    
}

function saveActivityPhase_1(){
    var btn = document.getElementById('save-btn');
    btn.innerHTML = "Saving...";
    btn.disabled = true;
    var task_description = document.getElementById('task_description').value;
    var project_name = document.getElementById('project_name').value;
    var activity = document.getElementById('activity').value;
    var expected_start_date = document.getElementById('expected_start_date').value;
    var expected_finish_date = document.getElementById('expected_finish_date').value;
    var planned_activity_percentage = document.getElementById('planned_activity_percentage').value;
    var actual_activity_percentage = document.getElementById('actual_activity_percentage').value;
    var activity_in_progress = document.getElementById('activity_in_progress').value;
    var latest_finish_date = document.getElementById('latest_finish_date').value;
    var remark = document.getElementById('remark').value;
    var role_scheduler = document.getElementById('role_scheduler').value;
    var period = document.getElementById('period').value;
    
    var formData = new FormData();
    formData.append('task_description', task_description);
    formData.append('project_name', project_name);
    formData.append('activity', activity);
    formData.append('expected_start_date', expected_start_date);
    formData.append('expected_finish_date', expected_finish_date);
    formData.append('planned_activity_percentage', planned_activity_percentage);
    formData.append('actual_activity_percentage', actual_activity_percentage);
    formData.append('activity_in_progress', activity_in_progress);
    formData.append('latest_finish_date', latest_finish_date);
    formData.append('remark', remark);
    formData.append('role_scheduler', role_scheduler);
    formData.append('period', period);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        // alert("Activity phase 1 added successfully")
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        btn.innerHTML = "Save";
        btn.disabled = false;
        getActivities();
        swal('Success', 'Activity phase 1 added successfully', 'success');
    }
    xhttp.onerror = function(){
        btn.innerHTML = "Save";
        btn.disabled = false;
        alert("An error occured, try again!");
    }
    xhttp.open('POST', serverUrl+'?function=save-activity-phase1', true);
    xhttp.send(formData);
}

function saveActivityPhase_2(){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        btn.innerHTML = "Saving...";
        btn.disabled = true;
        var formData = new FormData(form);
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            modal.style.display = 'none';
            form.reset();
            btn.innerHTML = "Save";
            btn.disabled = false;
            getActivities();
            swal('Success', "Activity phase 2 added successfully", 'success');
        }
        xhttp.onerror = function(){
            btn.innerHTML = "Save";
            btn.disabled = false;
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=save-activity-phase2', true);
        xhttp.send(formData);
    }
}
function saveActivityPhase_3(){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        btn.innerHTML = "Saving...";
        btn.disabled = true;
        var formData = new FormData(form);
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            modal.style.display = 'none';
            form.reset();
            btn.innerHTML = "Save";
            btn.disabled = false;
            getActivities();
            swal('Success', "Activity phase 3 added successfully", 'success');
        }
        xhttp.onerror = function(){
            btn.innerHTML = "Save";
            btn.disabled = false;
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=save-activity-phase3', true);
        xhttp.send(formData);
    }
    
    
}
function saveActivityPhase_4(){
    var Material_requested_number = document.getElementById('Material_requested_number').value;
    var types_of_materials_requested = document.getElementById('types_of_materials_requested').value;
    var material_received_number = document.getElementById('material_received_number').value;
    var delivered_by = document.getElementById('delivered_by').value;
    var received_by = document.getElementById('received_by').value;
    var material_inspection_remark = document.getElementById('material_inspection_remark').value;
    var qty_material_rejected_at_site_remark = document.getElementById('qty_material_rejected_at_site_remark').value;
    var material_utilized = document.getElementById('material_utilized').value;
    var outstanding_materials = document.getElementById('outstanding_materials').value;
    var date_outstanding = document.getElementById('date_outstanding').value;
    var bi_weekly_remarks = document.getElementById('bi_weekly_remarks').value;
    var remarks = document.getElementById('remarks').value;
    var period = document.getElementById('period').value;
    var challenge_for_escalation = document.getElementById('challenge_for_escalation').value;
    
    var formData = new FormData();
    formData.append('Material_requested_number', Material_requested_number);
    formData.append('types_of_materials_requested', types_of_materials_requested);
    formData.append('material_received_number', material_received_number);
    formData.append('delivered_by', delivered_by);
    formData.append('received_by', received_by);
    formData.append('material_inspection_remark', material_inspection_remark);
    formData.append('qty_material_rejected_at_site_remark', qty_material_rejected_at_site_remark);
    formData.append('material_utilized', material_utilized);
    formData.append('outstanding_materials', outstanding_materials);
    formData.append('date_outstanding', date_outstanding);
    formData.append('bi_weekly_remarks', bi_weekly_remarks);
    formData.append('remarks', remarks);
    formData.append('period', period);
    formData.append('challenge_for_escalation', challenge_for_escalation);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        getActivities();
        swal('Success', "Activity phase 4 added successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-activity-phase4', true);
    xhttp.send(formData);
}
function saveActivityPhase_5(){
    var requisition_raised_reqn_number = document.getElementById('requisition_raised_reqn_number').value;
    var list_type_of_tools_requested = document.getElementById('list_type_of_tools_requested').value;
    var tool_codes_tag = document.getElementById('tool_codes_tag').value;
    var received_del_no = document.getElementById('received_del_no').value;
    var date_received = document.getElementById('date_received').value;
    var delivered_by = document.getElementById('delivered_by').value;
    var received_by = document.getElementById('received_by').value;
    var Inspection_remark_at_delivery = document.getElementById('Inspection_remark_at_delivery').value;
    var use_status = document.getElementById('use_status').value;
    var date_returned = document.getElementById('date_returned').value;
    var bi_weekly_remarks_on_tools = document.getElementById('bi_weekly_remarks_on_tools').value;
    var remarks = document.getElementById('remarks').value;
    var period = document.getElementById('period').value;
    var challenge_for_escalation = document.getElementById('challenge_for_escalation').value;
    
    var formData = new FormData();
    formData.append('requisition_raised_reqn_number', requisition_raised_reqn_number);
    formData.append('list_type_of_tools_requested', list_type_of_tools_requested);
    formData.append('tool_codes_tag', tool_codes_tag);
    formData.append('received_del_no', received_del_no);
    formData.append('date_received', date_received);
    formData.append('delivered_by', delivered_by);
    formData.append('received_by', received_by);
    formData.append('Inspection_remark_at_delivery', Inspection_remark_at_delivery);
    formData.append('use_status', use_status);
    formData.append('date_returned', date_returned);
    formData.append('bi_weekly_remarks_on_tools', bi_weekly_remarks_on_tools);
    formData.append('remarks', remarks);
    formData.append('period', period);
    formData.append('challenge_for_escalation', challenge_for_escalation);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        swal('Success', "Activity phase 5 added successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-activity-phase5', true);
    xhttp.send(formData);
}
function savePlannedScope_1(){
    var daily_task = document.getElementById('daily_task').value;
    var start_date = document.getElementById('start_date').value;
    var week = document.getElementById('week').value;
    var phasing_percentage = document.getElementById('phasing_percentage').value;
    var contract_available = document.getElementById('contract_available').value;
    var contract_number = document.getElementById('contract_number').value;
    var contract_end_date = document.getElementById('contract_end_date').value;
    var remarks = document.getElementById('remarks').value;
    var duration = document.getElementById('duration').value;
    var end_date = document.getElementById('end_date').value;
    var pono = document.getElementById('pono').value;
    var day = document.getElementById('day').value;
    
    var formData = new FormData();
    formData('daily_task', daily_task);
    formData('start_date', start_date);
    formData('week', week);
    formData('phasing_percentage', phasing_percentage);
    formData('contract_available', contract_available);
    formData('contract_number', contract_number);
    formData('contract_end_date', contract_end_date);
    formData('remarks', remarks);
    formData('duration', duration);
    formData('end_date', end_date);
    formData('pono', pono);
    formData('day', day);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        swal('Success', "Planned scope 1 added successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-planned-one', true);
    xhttp.send(formData);
}
function savePlannedScope_2(){
    var daily_task = document.getElementById('daily_task').value;
    var weekly_schedule = document.getElementById('weekly_schedule').value;
    var start_date = document.getElementById('start_date').value;
    var week = document.getElementById('week').value;
    var phasing_percentage = document.getElementById('phasing_percentage').value;
    var contract_available = document.getElementById('contract_available').value;
    var contract_number = document.getElementById('contract_number').value;
    var contract_end_date = document.getElementById('contract_end_date').value;
    var remarks = document.getElementById('remarks').value;
    var duration = document.getElementById('duration').value;
    var end_date = document.getElementById('end_date').value;
    var pono = document.getElementById('pono').value;
    var day = document.getElementById('day').value;
    
    var formData = new FormData();
    formData('daily_task', daily_task);
    formData('weekly_schedule', weekly_schedule);
    formData('start_date', start_date);
    formData('week', week);
    formData('phasing_percentage', phasing_percentage);
    formData('contract_available', contract_available);
    formData('contract_number', contract_number);
    formData('contract_end_date', contract_end_date);
    formData('remarks', remarks);
    formData('duration', duration);
    formData('end_date', end_date);
    formData('pono', pono);
    formData('day', day);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        swal('Success', "Planned scope 2 added successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-planned-two', true);
    xhttp.send(formData);
}

//update
function updateActivityPhase_1(activity_id){
    var btn = document.getElementById('save-btn');
    btn.innerHTML = "Updating...";
    btn.disabled = true;
    var id = activity_id;
    var task_description = document.getElementById('task_description1').value;
    var project_name = document.getElementById('project_name1').value;
    var activity = document.getElementById('activity1').value;
    var expected_start_date = document.getElementById('expected_start_date1').value;
    var expected_finish_date = document.getElementById('expected_finish_date1').value;
    var planned_activity_percentage = document.getElementById('planned_activity_percentage1').value;
    var actual_activity_percentage = document.getElementById('actual_activity_percentage1').value;
    var activity_in_progress = document.getElementById('activity_in_progress1').value;
    var latest_finish_date = document.getElementById('latest_finish_date1').value;
    var remark = document.getElementById('remark1').value;
    var role_scheduler = document.getElementById('role_scheduler1').value;
    var period = document.getElementById('period1').value;
    
    var formData = new FormData();
    formData.append('id', id);
    formData.append('task_description', task_description);
    formData.append('project_name', project_name);
    formData.append('activity', activity);
    formData.append('expected_start_date', expected_start_date);
    formData.append('expected_finish_date', expected_finish_date);
    formData.append('planned_activity_percentage', planned_activity_percentage);
    formData.append('actual_activity_percentage', actual_activity_percentage);
    formData.append('activity_in_progress', activity_in_progress);
    formData.append('latest_finish_date', latest_finish_date);
    formData.append('remark', remark);
    formData.append('role_scheduler', role_scheduler);
    formData.append('period', period);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        btn.disabled = false;
        btn.innerHTML = 'Update';
        getActivities();
        swal('Success', "Activity phase 1 updated successfully", 'success');
    }
    xhttp.onerror = function(){
        btn.disabled = false;
        btn.innerHTML = 'Update';
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-activity-phase1', true);
    xhttp.send(formData);
}
function updateActivityPhase_2(activity_id){
    var btn = document.getElementById('save-btn');
    btn.innerHTML = "Updating...";
    btn.disabled = true;
    var id = activity_id;
    var required_number1 = document.getElementById('required_number2').value;
    var actual_number = document.getElementById('actual_number2').value;
    var name_of_project_engineer = document.getElementById('name_of_project_engineer2').value;
    var required_number_false = document.getElementById('required_number_false2').value;
    var actual_number_false = document.getElementById('actual_number_false2').value;
    var name_of_contractor_supervisor = document.getElementById('name_of_contractor_supervisor2').value;
    var remarks = document.getElementById('remarks2').value;
    var period = document.getElementById('period2').value;
    var challenge_for_escalation = document.getElementById('challenge_for_escalation2').value;
    
    var formData = new FormData();
    formData.append('id', id);
    formData.append('required_number', required_number1);
    formData.append('actual_number', actual_number);
    formData.append('name_of_project_engineer', name_of_project_engineer);
    formData.append('required_number_false', required_number_false);
    formData.append('actual_number_false', actual_number_false);
    formData.append('name_of_contractor_supervisor', name_of_contractor_supervisor);
    formData.append('remarks', remarks);
    formData.append('period', period);
    formData.append('challenge_for_escalation', challenge_for_escalation);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        btn.innerHTML = "Update";
        btn.disabled = false;
        getActivities();
        swal('Success', "Activity phase 2 updated successfully", 'success');
    }
    xhttp.onerror = function(){
        btn.innerHTML = "Update";
        btn.disabled = false;
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-activity-phase2', true);
    xhttp.send(formData);
}
function updateActivityPhase_4(phase_id){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        var formData = new FormData(form);
        formData.append('id', phase_id);
        
        btn.innerHTML = "Please wait...";
        btn.disabled = true;

        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            if(modal){
                modal.style.display = 'none';
            }
            
            form.reset();
            getActivities();
            swal('Success', "Activity phase 4 updated successfully", 'success');
        }
        xhttp.onerror = function(){
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=update-activity-phase4', true);
        xhttp.send(formData);
    }else{
        alert('Please fill out the form to proceed');
    }
    
}
function updateActivityPhase_5(){
    var id = document.getElementById('activityphase5_id').value;
    var requisition_raised_reqn_number = document.getElementById('requisition_raised_reqn_number1').value;
    var list_type_of_tools_requested = document.getElementById('list_type_of_tools_requested1').value;
    var tool_codes_tag = document.getElementById('tool_codes_tag1').value;
    var received_del_no = document.getElementById('received_del_no1').value;
    var date_received = document.getElementById('date_received1').value;
    var delivered_by = document.getElementById('delivered_by1').value;
    var received_by = document.getElementById('received_by1').value;
    var Inspection_remark_at_delivery = document.getElementById('Inspection_remark_at_delivery1').value;
    var use_status = document.getElementById('use_status1').value;
    var date_returned = document.getElementById('date_returned1').value;
    var bi_weekly_remarks_on_tools = document.getElementById('bi_weekly_remarks_on_tools1').value;
    var remarks = document.getElementById('remarks1').value;
    var period = document.getElementById('period1').value;
    var challenge_for_escalation = document.getElementById('challenge_for_escalation1').value;
    
    var formData = new FormData();
    formData.append('id', id);
    formData.append('requisition_raised_reqn_number', requisition_raised_reqn_number);
    formData.append('list_type_of_tools_requested', list_type_of_tools_requested);
    formData.append('tool_codes_tag', tool_codes_tag);
    formData.append('received_del_no', received_del_no);
    formData.append('date_received', date_received);
    formData.append('delivered_by', delivered_by);
    formData.append('received_by', received_by);
    formData.append('Inspection_remark_at_delivery', Inspection_remark_at_delivery);
    formData.append('use_status', use_status);
    formData.append('date_returned', date_returned);
    formData.append('bi_weekly_remarks_on_tools', bi_weekly_remarks_on_tools);
    formData.append('remarks', remarks);
    formData.append('period', period);
    formData.append('challenge_for_escalation', challenge_for_escalation);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        swal('Success', "Activity phase 5 updated successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-activity-phase5', true);
    xhttp.send(formData);
}
function updatePlannedScope_1(){
    var id = document.getElementById('plannedscope1_id').value;
    var daily_task = document.getElementById('daily_task1').value;
    var start_date = document.getElementById('start_date1').value;
    var week = document.getElementById('week1').value;
    var phasing_percentage = document.getElementById('phasing_percentage1').value;
    var contract_available = document.getElementById('contract_available1').value;
    var contract_number = document.getElementById('contract_number1').value;
    var contract_end_date = document.getElementById('contract_end_date').value;
    var remarks = document.getElementById('remarks').value;
    var duration = document.getElementById('duration').value;
    var end_date = document.getElementById('end_date').value;
    var pono = document.getElementById('pono').value;
    var day = document.getElementById('day').value;
    
    var formData = new FormData();
    formData('daily_task', daily_task);
    formData('start_date', start_date);
    formData('week', week);
    formData('phasing_percentage', phasing_percentage);
    formData('contract_available', contract_available);
    formData('contract_number', contract_number);
    formData('contract_end_date', contract_end_date);
    formData('remarks', remarks);
    formData('duration', duration);
    formData('end_date', end_date);
    formData('pono', pono);
    formData('day', day);
    
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        swal('Success', "Planned scope 1 added successfully", 'success');
    }
    xhttp.onerror = function(){
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-planned-one', true);
    xhttp.send(formData);
}

var phase_one = [];
var phase_two = [];
var phase_three = [];
var phase_four = [];
var phase_five = [];
function getActivities(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        phase_one = response[0].phase_one;
        phase_two = response[1].phase_two;
        phase_three = response[2].phase_three;
        phase_four = response[3].phase_four;
        phase_five = response[4].phase_five;
        loopActPh1(phase_one);
        loopActPh2(phase_two);
        loopActPh3(phase_three);
        loopActPh4(phase_four); 
    }
    xhttp.open('GET', serverUrl+'?function=get-activities');
    xhttp.send();
}
getActivities();
// Looping through the data from Activity Phase 1 to Phase 5

function loopActPh1(data){
    var container = document.getElementById('act-phase-1');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                <td>${'100'+counter}</td>
                <td>${data[i].task_description}</td>
                <td>${data[i].project_name}</td>
                <td>${data[i].activity}</td>
                <td>${data[i].expected_start_date}</td>
                <td>${data[i].expected_finish_date}</td>
                <td>${data[i].planned_activity_percentage}%</td>
                <td>${data[i].actual_activity_percentage}%</td>
                <td>${data[i].remark}</td>
                <td>
                    <div>
                        <button id="show-options-${i}" onclick="showThings(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id='options-${i}' class="options-dropdown" style="right: 5px;">
                            <button onclick="editActivity(${i})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewActivity(${i})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deletePhase1(${i})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
function deletePhase1(indexNumber){
    var data = phase_one[indexNumber];
    
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('id', data.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                swal('Success', "Item deleted!", 'success');
                getActivities();
            }
            xhttp.onerror = function(){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-phase-one', true);
            xhttp.send(formData);
        }
      });
}
function viewActivity(indexNumber){
    var data = phase_one[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Activity</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description">Task Description</label>
                        <input type="text" value="${data.task_description}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Project Name">Project Name</label>
                        <input type="text" value="${data.project_name}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Activity">Activity</label>
                        <input type="text" value="${data.activity}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Expected Start Date">Expected Start Date</label>
                        <input type="text" value="${data.expected_start_date}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Expected Finish Date">Expected Finish Date</label>
                        <input type="text" value="${data.expected_finish_date}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Planned Activity%">Planned Activity%</label>
                        <input type="text" value="${data.planned_activity_percentage}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Activity%">Actual Activity%</label>
                        <input type="text" value="${data.actual_activity_percentage}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Activity inProgress %">Activity inProgress %</label>
                        <input type="number" value="${data.activity_in_progress}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Latest Expected Finish Date">Latest Expected Finish Date</label>
                        <input type="text" value="${data.latest_finish_date}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${data.remark}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Role/Schedular</label>
                        <input type="text" value="${data.role_scheduler}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select>
                            <option>${data.period}</option>
                        </select>
                    </div>
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function editActivity(indexNumber){
    var data = phase_one[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit activity</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Task Description">Task Description</label>
                        <input type="text" value="${data.task_description}" id="task_description1" />
                    </div>
                    <div class="longer-form">
                        <label for="Project Name">Project Name</label>
                        <input type="text" value="${data.project_name}" id="project_name1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Activity">Activity</label>
                        <input type="text" value="${data.activity}" id="activity1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Expected Start Date">Expected Start Date</label>
                        <input type="text" value="${data.expected_start_date}" id="expected_start_date1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Expected Finish Date">Expected Finish Date</label>
                        <input type="text" value="${data.expected_finish_date}" id="expected_finish_date1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Planned Activity%">Planned Activity%</label>
                        <input type="text" value="${data.planned_activity_percentage}" id="planned_activity_percentage1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Actual Activity%">Actual Activity%</label>
                        <input type="text" value="${data.actual_activity_percentage}" id="actual_activity_percentage1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Activity inProgress %">Activity inProgress %</label>
                        <input type="number" value="${data.activity_in_progress}" id="activity_in_progress1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Latest Expected Finish Date">Latest Expected Finish Date</label>
                        <input type="text" value="${data.latest_finish_date}" id="latest_finish_date1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${data.remark}" id="remark1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Role/Schedular</label>
                        <input type="text" value="${data.role_scheduler}" id="role_scheduler1"/>
                    </div>
                    <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select id="period1">
                            <option value="${data.period}">Please select</option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    
                    <button type='button' class="edit-button" onclick="updateActivityPhase_1(${data.id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function loopActPh2(data){
    var container = document.getElementById('act-phase-2');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i = 0; i < data.length; i++){
            counter++;
            tr += `
                <tr>
                    <td>${'100'+counter}</td>
                    <td>${data[i].required_number}</td>
                    <td>${data[i].actual_number}</td>
                    <td class="right-border-black">${data[i].name_of_project_engineer}</td>
                    <td>${data[i].required_number_false}</td>
                    <td>${data[i].actual_number_false}</td>
                    <td onclick="challengeForm()">${data[i].challenge_for_escalation}</td>
                    <td>${data[i].remarks}</td>
                    <td>
                        <div>
                            <button id="show-options-${i}" onclick="showThings(${i})" class="three" style="cursor: pointer;">
                                <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                            </button>
        
                            <div id='options-${i}' class="options-dropdown" style="right: 5px;">
                                <button onclick="editActivity2(${i})" class="openModalBtnEdit option-button" >
                                    <img src="../assetsPeter/leadedit.png"/> Edit
                                </button>
                                <button onclick="viewActivity2(${i})" class="openModalBtnView option-button">
                                    <img src="../assetsPeter/leadview.png" />
                                    View
                                </button>
                                <button onclick="deleteActivity2(${i})" class="option-button">
                                    <img src="../assetsPeter/leaddelete.png" />
                                    Delete
                                </button>
                                
                            </div>
                        </div>
                    
                    </td>
                </tr>
        `;
    }
        if(container){
            container.innerHTML = tr;
        }
    }else{
        if(container){
            container.innerHTML = "No data";
        }
        
    }
    
}
function editActivity2(indexNumber){
    var data = phase_two[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit activity</h3>
            </div>
            <form id="form">
                 <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" value="${data.required_number}" id="required_number2" />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" value="${data.actual_number}" id="actual_number2" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of project Engineer">Name of project Engineer</label>
                        <input type="text" value="${data.name_of_project_engineer}" id="name_of_project_engineer2" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" value="${data.required_number_false}" id="required_number_false2" />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" value="${data.actual_number_false}" id="actual_number_false2" />
                    </div>
                     <div class="longer-form">
                        <label for="Name of contractor supervisor">Name of contractor supervisor</label>
                        <input type="text" value="${data.name_of_contractor_supervisor}" id="name_of_contractor_supervisor2" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${data.remarks}" id="remarks2" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period2" >
                            <option value="${data.period}">Please select</option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation2" >
                            <option value="${data.challenge_for_escalation}">Please select</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>

                    <button type='button' class="edit-button" onclick="updateActivityPhase_2(${data.id})" id="save-btn">Update</button>
            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewActivity2(indexNumber){
    var data = phase_two[indexNumber];
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View activity</h3>
            </div>
            <form id="form">
                 <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" value="${data.required_number}" id="required_number2" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" value="${data.actual_number}" readonly id="actual_number2" />
                    </div>
                    <div class="longer-form">
                        <label for="Name of project Engineer">Name of project Engineer</label>
                        <input type="text" value="${data.name_of_project_engineer}" readonly id="name_of_project_engineer2" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Required Number">Required Number</label>
                        <input type="text" value="${data.required_number_false}" id="required_number_false2" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Actual Number">Actual Number</label>
                        <input type="text" value="${data.actual_number_false}" id="actual_number_false2" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Name of contractor supervisor">Name of contractor supervisor</label>
                        <input type="text" value="${data.name_of_contractor_supervisor}" readonly id="name_of_contractor_supervisor2" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${data.remarks}" readonly id="remarks2" />
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select id="period2" >
                            <option value="${data.period}">${data.period}</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select id="challenge_for_escalation2" >
                            <option value="${data.challenge_for_escalation}">${data.challenge_for_escalation}</option>
                        </select>
                        
                    </div>

            </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function deleteActivity2(indexNumber){
    var data = phase_two[indexNumber];
    
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('id', data.id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                swal('Success', "Item deleted!", 'success');
                getActivities();
            }
            xhttp.onerror = function(){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-phase-two', true);
            xhttp.send(formData);
        }
      });
}
function loopActPh3(data){
    var container = document.getElementById('act-phase-3');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        var act_id = data[i].id;
        tr += `
            <tr>
                <td>${'100'+counter}</td>
                <td>${data[i].requested_number}</td>
                <td>${data[i].delivery_number}</td>
                <td>${data[i].date_recieved}</td>
                <td>${data[i].utilized}</td>
                <td>${data[i].challenge_for_escalation}</td>
                <td>${data[i].remarks}%</td>
                <td>
                    <div>
                        <button id="show-options-${i}" onclick="showThings(${i})" class="three" style="cursor: pointer;">
                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                            </svg>
                        </button>
                        <div id='options-${i}' class="options-dropdown" style="right: 5px;">
                            <button onclick="editActivity3(${act_id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                            <button onclick="viewActivity3(${act_id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                            <button onclick="deletePhase3(${act_id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
}
function editActivity3(act_id){
    var activity = phase_three.find((activity)=>{
        return activity.id == act_id;
    });
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Material Specification">Material Specification</label>
                        <input type="text" value="${activity.material_specification}" name="material_specification"/>
                    </div>
                    <div class="longer-form">
                        <label for="Requested/Requisition Number">Requested/Requisition Number</label>
                        <input type="text" value="${activity.requested_number}" name="requested_number"/>
                    </div>
                    <div class="longer-form">
                        <label for="Received/Delivery Number">Received/Delivery Number</label>
                        <input type="text" value="${activity.delivery_number}" name="delivery_number"/>
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Date Received">Date Received</label>
                        <input type="date" value="${activity.date_recieved}" name="date_recieved"/>
                    </div>
                    <div class="longer-form">
                        <label for="Utilized">Utilized</label>
                        <input type="text" value="${activity.utilized}" name="utilized"/>
                    </div>
                     <div class="longer-form">
                        <label for="Date Outstanding">Date Outstanding</label>
                        <input type="date" value="${activity.date_outstanding}" name="date_outstanding"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${activity.remarks}" name="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select name="period">
                            <option value="${activity.period}"></option>
                            <option ${activity.period == 'Daily Work Schedule' ? 'selected' : ''} value="Daily Work Schedule">Daily Work Schedule</option>
                            <option ${activity.period == 'Weekly Work Schedule' ? 'selected' : ''} value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Quality">Quality</label>
                        <input type="text" value="${activity.quality}" name="quality"/>
                    </div>
                    <div class="longer-form">
                        <label for="Accept/Reject">Accept/Reject</label>
                          <select name="accept_reject">
                            <option value="${activity.accept_reject}"></option>
                            <option ${activity.accept_reject == 'Accept' ? 'selected' : ''} value="Accept">Accept</option>
                            <option ${activity.accept_reject == 'Reject' ? 'selected' : ''} value="Reject">Reject</option>
                        </select>
                        
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge_for_escalation">
                            <option value="${activity.challenge_for_escalation}"></option>
                            <option value="${activity.challenge_for_escalation == 'Yes' ? 'selected' : ''}" value="Yes">Yes</option>
                            <option value="${activity.challenge_for_escalation == 'No' ? 'selected' : ''}">No</option>
                        </select>
                    </div>
                    <button type='button' class="edit-button" onclick="updateActivityPhase_3(${activity.id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function deletePhase3(act_id){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('id', act_id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                swal('Success', "Item deleted!", 'success');
                getActivities();
            }
            xhttp.onerror = function(){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-phase-three', true);
            xhttp.send(formData);
        }
      });
}
function updateActivityPhase_3(act_id){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        var formData = new FormData(form);
        formData.append('id', act_id);
        btn.innerHTML = "Please wait...";
        btn.disabled = true;

        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            btn.innerHTML = "Update";
            btn.disabled = false;
            if(modal){
                modal.style.display = 'none';
            }
            
            form.reset();
            getActivities();
            swal('Success', "Activity phase 3 updated successfully", 'success');
        }
        xhttp.onerror = function(){
            btn.innerHTML = "Update";
            btn.disabled = false;
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=update-activity-phase3', true);
        xhttp.send(formData);
    }else{
        alert('Please fill out the form to proceed');
    }
}
function loopActPh4(data){
    var container = document.getElementById('act-phase-4');
    var tr = "";
    if(data.length > 0){
        var sn = 0;
        for(var phase of data){
            sn++;
            tr += `
                <tr>
                        <td>${'1000'+sn}</td>
                        <td>${phase.Material_requested_number}</td>
                        <td>${phase.types_of_materials_requested}</td>
                        <td>${phase.material_received_number}</td>
                        <td>${phase.delivered_by}</td>
                        <td>${phase.received_by}</td>
                        <td>${phase.challenge_for_escalation}</td>
                        <td>
                            <div>
                                <button id="phase4-option-btn${phase.id}" onclick="showPhase4Options(${phase.id})" class="three" style="cursor: pointer;">
                                    <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                    <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                    </svg>
                                </button>
            
                                <div id="phase4-option${phase.id}" class="options-dropdown" style="right: 5px;">
                                    <button onclick="editActivity4(${phase.id})" class="openModalBtnEdit option-button" >
                                        <img src="../assetsPeter/leadedit.png"/> Edit
                                    </button>
                                    <button onclick="viewActivity4(${phase.id})" class="openModalBtnView option-button">
                                        <img src="../assetsPeter/leadview.png" />
                                        View
                                    </button>
                                    <button onclick="deleteActivity4(${phase.id})" class="option-button">
                                        <img src="../assetsPeter/leaddelete.png" />
                                        Delete
                                    </button>
                                    
                                </div>
                            </div>
                        
                        </td>
                    </tr>
            `;
        }
        if(container){
            container.innerHTML = tr;
        }
    }else{
        if(container){
            container.innerHTML = "No data found!";
        }
    }
}
var option4btn = "";
var option4 = "";
function showPhase4Options(act_id){
    option4btn = document.getElementById('phase4-option-btn'+act_id);
    option4 = document.getElementById('phase4-option' + act_id);
    option4.style.display = "block";
}
document.addEventListener('click', function(event) {
    // Check if the clicked target is inside the option container
    if(option4 && option4btn){
       if(!option4.contains(event.target) && !option4btn.contains(event.target)){
            option4.style.display = 'none';
        } 
    }
});
function editActivity4(act_id){
    var activity = phase_four.find((phase)=>{
        return phase.id == act_id;
    });
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>

    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit activity</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Mat. Requested/REQN NO">Mat. Requested/REQN NO</label>
                        <input type="text" value="${activity.Material_requested_number}" name="Material_requested_number"/>
                    </div>
                    <div class="longer-form">
                        <label for="Types of Materials Requested">Types of Materials Requested</label>
                        <input type="text" value="${activity.types_of_materials_requested}" name="types_of_materials_requested"/>
                    </div>
                    <div class="longer-form">
                        <label for="Mat Received/Del NO">Mat Received/Del NO</label>
                        <input type="text" value="${activity.material_received_number}" name="material_received_number"/>
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Delivered By">Delivered By</label>
                        <input type="text" value="${activity.delivered_by}" name="delivered_by"/>
                    </div>
                    <div class="longer-form">
                        <label for="Received By">Received By</label>
                        <input type="text" value="${activity.received_by}" name="received_by"/>
                    </div>
                     <div class="longer-form">
                        <label for="Mat Inspection Remark">Mat Inspection Remark</label>
                        <input type="text" value="${activity.material_inspection_remark}" name="material_inspection_remark"/>
                    </div>
                     <div class="longer-form">
                        <label for="Qty. Mat Rejected at Site Remark">Qty. Mat Rejected at Site Remark</label>
                        <input type="text" name="qty_material_rejected_at_site_remark" value="${activity.qty_material_rejected_at_site_remark}" />
                    </div>
                     <div class="longer-form">
                        <label for="Mat Utilized">Mat Utilized</label>
                        <input type="text" value="${activity.material_utilized}" name="material_utilized"/>
                    </div>
                     <div class="longer-form">
                        <label for="Outstanding Materials">Outstanding Materials</label>
                        <input type="text" value="${activity.outstanding_materials}" name="outstanding_materials"/>
                    </div>
                     <div class="longer-form">
                        <label for="Date Outstanding">Date Outstanding</label>
                        <input type="date" value="${activity.date_outstanding}" name="date_outstanding" />
                    </div>
                     <div class="longer-form">
                        <label for="Bi- Weekly Remarks">Bi- Weekly Remarks</label>
                        <input type="text" value="${activity.bi_weekly_remarks}" name="bi_weekly_remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${activity.remarks}" name="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select name="period">
                            <option value="${activity.period}"></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge_for_escalation">
                            <option value="${activity.challenge_for_escalation}"></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="updateActivityPhase_4(${activity.id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewActivity4(act_id){
    var activity = phase_four.find((phase)=>{
        return phase.id == act_id;
    });
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>

    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit activity</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Mat. Requested/REQN NO">Mat. Requested/REQN NO</label>
                        <input type="text" value="${activity.Material_requested_number}" name="Material_requested_number" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Types of Materials Requested">Types of Materials Requested</label>
                        <input type="text" value="${activity.types_of_materials_requested}" name="types_of_materials_requested" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Mat Received/Del NO">Mat Received/Del NO</label>
                        <input type="text" value="${activity.material_received_number}" name="material_received_number" readonly />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="Delivered By">Delivered By</label>
                        <input type="text" value="${activity.delivered_by}" name="delivered_by" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Received By">Received By</label>
                        <input type="text" value="${activity.received_by}" name="received_by" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Mat Inspection Remark">Mat Inspection Remark</label>
                        <input type="text" value="${activity.material_inspection_remark}" name="material_inspection_remark" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Qty. Mat Rejected at Site Remark">Qty. Mat Rejected at Site Remark</label>
                        <input type="text" name="qty_material_rejected_at_site_remark" value="${activity.qty_material_rejected_at_site_remark}"  readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Mat Utilized">Mat Utilized</label>
                        <input type="text" value="${activity.material_utilized}" name="material_utilized" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Outstanding Materials">Outstanding Materials</label>
                        <input type="text" value="${activity.outstanding_materials}" name="outstanding_materials" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Date Outstanding">Date Outstanding</label>
                        <input type="text" value="${activity.date_outstanding}" name="date_outstanding" readonly />
                    </div>
                     <div class="longer-form">
                        <label for="Bi- Weekly Remarks">Bi- Weekly Remarks</label>
                        <input type="text" value="${activity.bi_weekly_remarks}" name="bi_weekly_remarks" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" value="${activity.remarks}" readonly name="remarks"/>
                    </div>
                    <div class="longer-form">
                        <label for="Period">Period</label>
                          <select name="period">
                            <option value="${activity.period}">${activity.period}</option>
                        </select>
                    </div>
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge_for_escalation">
                            <option value="${activity.challenge_for_escalation}">${activity.challenge_for_escalation}</option>
                        </select>
                        
                    </div> 
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function deleteActivity4(act_id){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('id', act_id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                swal('Success', "Item deleted!", 'success');
                getActivities();
            }
            xhttp.onerror = function(){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-phase-four', true);
            xhttp.send(formData);
        }
      });
}
function loopActPh5(){
    var container = document.getElementById('act-phase-5');
    var contents = `            <tr>
                                <td>001</td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td>Yes</td>
                                <td>
                                    <div>
                                        <button onclick="showThings()" class="three" style="cursor: pointer;">
                                            <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                            <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                            </svg>
                                        </button>
                    
                                        <div id='1' class="options-dropdown" style="right: 5px;">
                                            <button onclick="editActivity5()" class="openModalBtnEdit option-button" >
                                                <img src="../assetsPeter/leadedit.png"/> Edit
                                            </button>
                                            <button onclick="viewActivity5()" class="openModalBtnView option-button">
                                                <img src="../assetsPeter/leadview.png" />
                                                View
                                            </button>
                                            <button onclick="deleteLead()" class="option-button">
                                                <img src="../assetsPeter/leaddelete.png" />
                                                Delete
                                            </button>
                                            
                                        </div>
                                    </div>
                               
                                </td>
                            </tr>`
}
var worksites = [];
function getWorkSite(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        worksites = response.worksites;
        loopWorksites(worksites);
    }
    xhttp.open('GET', serverUrl+'?function=get-worksite-two', true);
    xhttp.send();
}
getWorkSite();
function saveWorkSite2(){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        btn.innerHTML = "Saving...";
        btn.disabled = true;
        var formData = new FormData(form)
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            btn.innerHTML = "Save";
            btn.disabled = false;
            if(modal){
                modal.style.display = 'none';
            }
            
            form.reset();
            getWorkSite()
        }
        xhttp.onerror = function(){
            btn.innerHTML = "Save";
            btn.disabled = false;
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=save-worksite-two', true);
        xhttp.send(formData);
    }else{
        alert('Please fill out the form to proceed');
    }
    
}
function loopWorksites(worksites){
    var container = document.getElementById('worksites-container');
    if(worksites && worksites.length > 0){
        var tr = "";
        var sn = 0;
        for(var worksite of worksites){
            sn++;
            tr += `
               <tr>
                    <td>${'1000'+sn}</td>
                    <td>${worksite.description ? limitString(worksite.description, 30) : ''}</td>
                    <td>${worksite.delivery_date ? limitString(worksite.delivery_date, 30) : ''}</td>
                    <td>${worksite.done_percentage ? limitString(worksite.done_percentage, 30) : ''}</td>
                    <td>${worksite.work_in_progress ? limitString(worksite.work_in_progress, 30) : ''}</td>
                    <td>${worksite.remark ? limitString(worksite.remark, 30) : ''}</td>
                    <td>${worksite.challenge ? limitString(worksite.challenge, 30) : ''}</td>
                    <td>${worksite.address ? limitString(worksite.address, 30) : ''}</td>
                    <td>
                        <div>
                            <button id="option-btn${worksite.id}" onclick="showWorkOptions(${worksite.id})" class="three" style="cursor: pointer;">
                                <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                            </button>
        
                            <div id='option-${worksite.id}' class="options-dropdown" style="right: 5px;">
                                <button onclick="editWorksite2(${worksite.id})" class="openModalBtnEdit option-button" >
                                    <img src="../assetsPeter/leadedit.png"/> Edit
                                </button>
                                <button onclick="viewWorksite2(${worksite.id})" class="openModalBtnView option-button">
                                    <img src="../assetsPeter/leadview.png" />
                                    View
                                </button>
                                <button onclick="deleteWorksite2(${worksite.id})" class="option-button">
                                    <img src="../assetsPeter/leaddelete.png" />
                                    Delete
                                </button>
                                
                            </div>
                        </div>
                   
                    </td>
                </tr> 
            `;
        }
        if(container){
            container.innerHTML = tr;
        }
    }else{
        if(container){
            container.innerHTML = "No record found!";
        }
    }
}
var option = "";
var option_btn = "";
function showWorkOptions(worksite_id){
    option = document.getElementById('option-' + worksite_id);
    option.style.display = 'block';
    option_btn = document.getElementById('option-btn' + worksite_id);
}
document.addEventListener('click', function(event) {
    // Check if the clicked target is inside the option container
    if(option && option_btn){
        if(!option.contains(event.target) && !option_btn.contains(event.target)){
            option.style.display = 'none';
        }
    }
    
});
function editWorksite2(worksite_id){
    var worksite = worksites.find((worksite)=>{
        return worksite.id == worksite_id;
    });
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit Worksite</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Activity Description From Work Program">Activity Description From Work Program</label>
                        <input type="text" name="description" value="${worksite.description}" />
                    </div>
                    <div class="longer-form">
                        <label for="Expected Delivery Date">Expected Delivery Date</label>
                        <input type="date" value="${worksite.delivery_date}" name="delivery_date" />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" name="done_percentage" value="${worksite.done_percentage}" />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Work In Progress">% of Work In Progress</label>
                        <input type="text" name="work_in_progress" value="${worksite.work_in_progress}" />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" name="remark" value="${worksite.remark}" />
                    </div>
                    <div class="longer-form">
                        <label for="Issues to Address">Issues to Address</label>
                        <input type="text" name="address" value="${worksite.address}" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" name="action_party" value="${worksite.action_party}" />
                    </div>
                    <div class="longer-form">
                        <label for="Action close out Date">Action close out Date</label>
                        <input type="date" name="action_close_date" value="${worksite.action_close_date}" />
                    </div>
                    <div class="longer-form">
                        <label for="Next Step to Close Out">Next Step to Close Out</label>
                        <input type="text" name="next_step" value="${worksite.next_step}" />
                    </div>

                     <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select name="period" value="${worksite.period}">
                            <option value=""></option>
                            <option value="Daily Work Schedule">Daily Work Schedule</option>
                            <option value="Weekly Work Schedule">Weekly Work Schedule</option>
                        </select>
                    </div>
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge" value="${worksite.challenge}">
                            <option value=""></option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                        
                    </div>
                    <button type='button' class="edit-button" onclick="updateWorksite2(${worksite.id})" id="save-btn">Update</button>  
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    } 
}
function updateWorksite2(worksite_id){
    var btn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    var modal = document.getElementById('myModal');
    if(form.checkValidity()){
        btn.innerHTML = "Updating...";
        btn.disabled = true;
        var formData = new FormData(form);
        formData.append('id', worksite_id);
        var xhttp = new XMLHttpRequest();
        xhttp.onload = function(){
            var response = JSON.parse(xhttp.response);
            btn.innerHTML = "Update";
            btn.disabled = false;
            if(modal){
                modal.style.display = 'none';
            }
            
            form.reset();
            getWorkSite();
        }
        xhttp.onerror = function(){
            btn.innerHTML = "Update";
            btn.disabled = false;
            swal('Sorry', "An error occured, try again!", 'error');
        }
        xhttp.open('POST', serverUrl+'?function=update-worksite-two', true);
        xhttp.send(formData);
    }else{
        alert('Please fill out the form to proceed');
    }
}
function viewWorksite2(worksite_id){
    var worksite = worksites.find((worksite)=>{
        return worksite.id == worksite_id;
    });
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View Worksite</h3>
            </div>
            <form id="form">
                    <div class="longer-form">
                        <label for="Activity Description From Work Program">Activity Description From Work Program</label>
                        <input type="text" name="description" value="${worksite.description}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Expected Delivery Date">Expected Delivery Date</label>
                        <input type="text" value="${worksite.delivery_date}" name="delivery_date" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="% of Work Done">% of Work Done</label>
                        <input type="text" name="done_percentage" value="${worksite.done_percentage}" readonly />
                    </div>
                    <hr/>
                     <div class="longer-form">
                        <label for="% of Work In Progress">% of Work In Progress</label>
                        <input type="text" name="work_in_progress" value="${worksite.work_in_progress}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Remarks">Remarks</label>
                        <input type="text" name="remark" readonly value="${worksite.remark}" />
                    </div>
                    <div class="longer-form">
                        <label for="Issues to Address">Issues to Address</label>
                        <input type="text" name="address" readonly value="${worksite.address}" />
                    </div>
                    <div class="longer-form">
                        <label for="Action Party">Action Party</label>
                        <input type="text" name="action_party" value="${worksite.action_party}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Action close out Date">Action close out Date</label>
                        <input type="text" name="action_close_date" value="${worksite.action_close_date}" readonly />
                    </div>
                    <div class="longer-form">
                        <label for="Next Step to Close Out">Next Step to Close Out</label>
                        <input type="text" name="next_step" readonly value="${worksite.next_step}" />
                    </div>

                     <div class="longer-form">
                        <label for="Role/Schedular">Period</label>
                        <select name="period">
                            <option value="${worksite.period}">${worksite.period}</option>
                        </select>
                    </div>
                    
                    <div class="longer-form">
                        <label for="Challenge for Escalation">Challenge for Escalation</label>
                          <select name="challenge">
                            <option value="${worksite.challenge}">${worksite.challenge}</option>
                        </select>
                    </div>
                </form> 
        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    } 
}
function deleteWorksite2(worksite_id){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('worksite_id', worksite_id);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getWorkSite();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-worksite-2', true);
            xhttp.send(formData);
        }
      });
}



////stake _holder and communication (sirlaw)
var  stakeholderData =[];
function addStakeholderCom(){
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
           <form id="form" class="addStakeholder">
    <div class="sub-form">
        <div class="single-form">
            <label for="project_title">Project</label>
            <input type="text" id="project_title" name="project_title" required/>
        </div>
        <div class="single-form">
            <label for="description">Description</label>
            <input type="text" id="description" name="description" required/>
        </div>
    </div>

    <div class="sub-form">
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date" name="date" required/>
        </div>
        <div class="single-form">
            <label for="file_no">File No</label>
            <input type="text" id="file_no" name="file_no" required/>
        </div>
    </div>

    <div class="sub-form">
        <div class="single-form">
            <label for="Bid_Opp_No">Bid Opp No</label>
            <input type="text" id="Bid_Opp_No" name="Bid_Opp_No" required/>
        </div>

        <div class="single-form">
            <label for="stakeholder">Stakeholder</label>
            <input type="text" id="stakeholder" name="stakeholder" required/>
        </div>
    </div>

    <div class="longer-form">
        <label for="i&e">Interest & Expectations</label>
        <textarea rows="10" id="i&e" name="i_e" cols="50" required></textarea>
    </div>

    <div class="longer-form">
        <label for="imIn">Importance & Influence</label>
        <textarea rows="10" cols="50" id="imIn" name="importance_influence" required></textarea>
    </div>

    <div class="longer-form">
        <label for="assOfImp">Assessment of Impact</label>
        <textarea rows="10" cols="50" id="assOfImp" name="assessment_of_impact" required></textarea>
    </div>

    <div class="longer-form">
        <label for="strategySupport">Strategies for Gaining Support or Reducing Impact</label>
        <textarea rows="10" cols="50" id="strategySupport" name="strategy_support" required></textarea>
    </div>

    <button type='button' class="edit-button" onclick="saveStakeholderCom()" id="save-btn">Save</button>  
</form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function saveStakeholderCom(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var project_title = document.getElementById('project_title').value;
    var description = document.getElementById('description').value;
    var date = document.getElementById('date').value;
    var file_no = document.getElementById('file_no').value;
    var Bid_Opp_No = document.getElementById('Bid_Opp_No').value;
    var stakeholder = document.getElementById('stakeholder').value;
    var intExp = document.getElementById('i&e').value;
    var impInf = document.getElementById('imIn').value;
    var assOfImp = document.getElementById('assOfImp').value;
    var strategySupport = document.getElementById('strategySupport').value;

    var formData = new FormData();
    formData.append('projectTitle', project_title);
    formData.append('description', description);
    formData.append('date', date);
    formData.append('fileNo', file_no);
    formData.append('BidOppNo', Bid_Opp_No);
    formData.append('stakeholder', stakeholder);
    formData.append('interestExpectations', intExp);
    formData.append('importanceInfluence', impInf);
    formData.append('assessmentOfImpact', assOfImp);
    formData.append('strategySupport', strategySupport);

    console.log("formdata", formData)
    var xhttp = new XMLHttpRequest();
   

    xhttp.onload = function() {
        if (xhttp.status === 200) {
            var response = JSON.parse(xhttp.response);
            for(var modal of modals){
                modal.style.display = 'none';
            }
            for(var form of forms){
                form.reset();
            }
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Success', "Record saved!", 'success');
            getStakeholderData()
        }
    };

    xhttp.onerror = function() {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    };

    xhttp.open('POST', serverUrl+'?function=save-stakeholder', true);
    xhttp.send(formData);
}

function getStakeholderData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
         stakeholderData = response.stakeholderData;
        loopStakeholderData(stakeholderData);
    }
    xhttp.open('GET', serverUrl+'?function=get-stakeholder', true);
    xhttp.send();
}
function loopStakeholderData(data){
    var container = document.getElementById('stakeTbody');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                                <td>${counter}</td>
                                <td>${data[i].project}</td>
                                <td>${data[i].description}</td>
                                <td>${data[i].date}</td>
                                <td>${data[i].fileNo}</td>
                                <td>${data[i].BidOppNo}</td>
                                <td>${data[i].stakeholder}</td>
                                <td>${data[i].intrestAndExpect}</td>
                               
                                <td >
                                    <div>
                                        <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
                                             <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                            </button>
                    
                                        <div id='${i}' class="options-dropdown" style="right: 5px;">
                                            <button onclick="editStakeholderCom(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                                            <button onclick="viewStakeholderCom(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>

                                            <button onclick="deleteStakeholder(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                                            
                                        </div>
                                    </div>
                               
                                </td>
                            </tr> 
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
getStakeholderData();

function viewStakeholderCom(stakeholderId) {
        var data = stakeholderData.find((stakeholder)=>{
            return stakeholder.id == stakeholderId
        });


         // Populate the modal with the data received from the backend
         var modals = document.getElementById('modals');
         var modalContent = `
         <style>
             .select-input{
                 display: flex;
                 width: 88%;
                 height: 24px;
                 padding: 7px 17px;
                 align-items: flex-start;
                 gap: 10px;
                 flex-shrink: 0;
                 border-radius: 8px;
                 border: 1px solid var(--Foundation-Primary-P400, #0047B3);
                 background: var(--Foundation-White-W300, #F6F6F6);
             }
         </style>
         <div id="myModal" class="modal-container">
             <div class="modal-content">
                 <span onclick="closeModal()" class="close">&times;</span>
                 <div class="add-text">
                     <h3>View </h3>
                 </div>
                 <form id="form">
                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Project">Project</label>
                             <input type="text" id="project_title" value="${data.project}" required readonly/>
                         </div>
                         <div class="single-form">
                             <label for="Description">Description</label>
                             <input type="text" id="description" name="description" value="${data.description }" required readonly/>
                         </div>
                     </div>

                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Date">Date</label>
                             <input type="text" id="date" value="${data.date}" required readonly />
                         </div>
                         <div class="single-form">
                             <label for="File No">File No</label>
                             <input type="text" id="file_no" value="${data.fileNo}" required  readonly/>
                         </div>
                     </div>

                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Bid Opp No">Bid Opp No</label>
                             <input type="text" id="Bid_Opp_No" value="${data.BidOppNo}" required readonly/>
                         </div>

                         <div class="single-form">
                             <label for="Stakeholder">Stakeholder</label>
                             <input type="text" id="stakeholder" value="${data.stakeholder}" required readonly/>
                         </div>
                     </div>

                     <div class="longer-form">
                         <label for="Interest & Expectations">Interest & Expectations</label>
                         <textarea rows="10" id="i&e" cols="50" required readonly>${data.intrestAndExpect }</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Importance & Influence">Importance & Influence</label>
                         <textarea rows="10" cols="50" id="imIn" required readonly>${data.impAndInfluence}</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Assessment of Impact">Assessment of Impact</label>
                         <textarea rows="10" cols="50" id="assOfImp" required readonly>${data.assOfImp}</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Strategies for Gaining Support or Reducing Impact">Strategies for Gaining Support or Reducing Impact</label>
                         <textarea rows=10" cols="50" id="strategySupport" required readonly>${data.strategyForSupport}</textarea>
                     </div>

                     <button type='button' class="edit-button" onclick="updateStockholder(${stakeholderId})" id="save-btn">Update</button>  
                 </form> 
             </div>
         </div>
         `;
         if (modals) {
             modals.innerHTML = modalContent;
             openModal();
         }

    
}
function editStakeholderCom(stakeholderId) {
        var data = stakeholderData.find((stakeholder)=>{
            return stakeholder.id == stakeholderId
        });


         // Populate the modal with the data received from the backend
         var modals = document.getElementById('modals');
         var modalContent = `
         <style>
             .select-input{
                 display: flex;
                 width: 88%;
                 height: 24px;
                 padding: 7px 17px;
                 align-items: flex-start;
                 gap: 10px;
                 flex-shrink: 0;
                 border-radius: 8px;
                 border: 1px solid var(--Foundation-Primary-P400, #0047B3);
                 background: var(--Foundation-White-W300, #F6F6F6);
             }
         </style>
         <div id="myModal" class="modal-container">
             <div class="modal-content">
                 <span onclick="closeModal()" class="close">&times;</span>
                 <div class="add-text">
                     <h3>Edit </h3>
                 </div>
                 <form id="form">
                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Project">Project</label>
                             <input type="text" id="project_title" value="${data.project}" required/>
                         </div>
                         <div class="single-form">
                             <label for="Description">Description</label>
                             <input type="text" id="description" name="description" value="${data.description }" required />
                         </div>
                     </div>

                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Date">Date</label>
                             <input type="text" id="date" value="${data.date}" required />
                         </div>
                         <div class="single-form">
                             <label for="File No">File No</label>
                             <input type="text" id="file_no" value="${data.fileNo}" required />
                         </div>
                     </div>

                     <div class="sub-form">
                         <div class="single-form">
                             <label for="Bid Opp No">Bid Opp No</label>
                             <input type="text" id="Bid_Opp_No" value="${data.BidOppNo}" required/>
                         </div>

                         <div class="single-form">
                             <label for="Stakeholder">Stakeholder</label>
                             <input type="text" id="stakeholder" value="${data.stakeholder}" required />
                         </div>
                     </div>

                     <div class="longer-form">
                         <label for="Interest & Expectations">Interest & Expectations</label>
                         <textarea rows="10" id="i&e" cols="50" required>${data.intrestAndExpect }</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Importance & Influence">Importance & Influence</label>
                         <textarea rows="10" cols="50" id="imIn" required>${data.impAndInfluence}</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Assessment of Impact">Assessment of Impact</label>
                         <textarea rows="10" cols="50" id="assOfImp" required>${data.assOfImp}</textarea>
                     </div>

                     <div class="longer-form">
                         <label for="Strategies for Gaining Support or Reducing Impact">Strategies for Gaining Support or Reducing Impact</label>
                         <textarea rows="10" cols="50" id="strategySupport" required>${data.strategyForSupport}</textarea>
                     </div>

                     <button type='button' class="edit-button" onclick="updateStockholder(${stakeholderId})" id="save-btn">Update</button>  
                 </form> 
             </div>
         </div>
         `;
         if (modals) {
             modals.innerHTML = modalContent;
             openModal();
         }

    
}
function updateStakeholderCom(stakeholderId){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'updating...';
    savebtn.disabled = true;

    var project_title = document.getElementById('project_title').value;
    var description = document.getElementById('description').value;
    var date = document.getElementById('date').value;
    var file_no = document.getElementById('file_no').value;

    var Bid_Opp_No = document.getElementById('Bid_Opp_No').value;
    var stakeholder = document.getElementById('stakeholder').value;

    var intExp = document.getElementById('i&e').value;

    var impInf = document.getElementById('imIn').value;

    var assOfImp = document.getElementById('assOfImp').value;

    var strategySupport = document.getElementById('strategySupport').value;
    
    var formData = new FormData();
    formData.append('project_title', project_title);
    formData.append('description', description);
    formData.append('date', date);
    formData.append('file_no', file_no);
    formData.append('Bid_Opp_No', Bid_Opp_No);
    formData.append('stakeholder', stakeholder);
    formData.append('intExp', intExp);
    formData.append('impInf', impInf);
    formData.append('assOfImp', assOfImp);
    formData.append('strategySupport', strategySupport);
    formData.append('stakeholderId', stakeholderId);
console.log("formData", formData);
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Success', "Record saved!", 'success');
        getProjects();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Update";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=update-stakeholder', true);
    xhttp.send(formData);
}
function deleteStakeholder(stakeholderId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();

            formData.append('stakeholderId', stakeholderId);

            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getStakeholderData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-stakeholderData', true);
            xhttp.send(formData);
        }
      });
}


////Stakeholder and Comunication (communication Plan)
var  StakeholderComPlanData =[];

function addStakeholderComPlan(){
    var modals = document.getElementById('modals');
    var modalContent = `

    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
           <form id="form" class="addStakeholder">
    <div class="sub-form">
        <div class="single-form">
            <label for="project_title">Project</label>
            <input type="text" id="project_title" name="project_title" required/>
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date" name="Date" required/>
        </div>
    </div>

    <div class="sub-form">
     <div class="single-form">
            <label for="file_no">File No</label>
            <input type="text" id="file_no" name="file_no" required/>
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date2" name="date" required/>
        </div>
       
    </div>

    <div class="sub-form">
        <div class="single-form">
            <label for="Bid_Opp_No">Bid Opp No</label>
            <input type="text" id="Bid_Opp_No" name="Bid_Opp_No" required/>
        </div>

        <div class="single-form">
            <label for="stakeholder">Stakeholder</label>
            <input type="text" id="stakeholder" name="stakeholder" required/>
        </div>
    </div>

    <div class="longer-form">
        <label for="Objective">Objective(Need/ why)</label>
        <textarea rows="10" id="Objective" name="Objective" cols="50" required></textarea>
    </div>
    
    <div class="longer-form">
        <label for="Messages">Messages(What)</label>
        <textarea rows="10" cols="50" id="Messages" name="Messages" required></textarea>
    </div>

    <div class="longer-form">
            <label for="Timing">Timing/Frequency(When)</label>
            <textarea rows="10" cols="50" id="Timing" name="Timing" required></textarea>
    </div>
    <div class="longer-form">
        <label for="DeliveryMethod">Delivery Method/Media Type(How)</label>
        <textarea rows="10" cols="50" id="deliveryMethod" name="DeliveryMethod" required></textarea>
    </div>
    <div class="longer-form">
        <label for="ByWho">By Who</label>
        <textarea rows="10" cols="50" id="byWho" name="ByWho" required></textarea>
    </div>
    <div class="longer-form">
        <label for="FeedBackMechanism">FeedBack Mechanism</label>
        <textarea rows="10" cols="50" id="FeedBackMechanism" name="FeedBackMechanism" required></textarea>
    </div>
    <div class="longer-form">
        <label for="description">Description</label>
        <textarea rows="10" cols="50" id="description" name="description" required></textarea>
    </div>

    <button type='button' class="edit-button" onclick="saveStakeholderComPlan()" id="save-btn">Save</button>  
</form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveStakeholderComPlan(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var project_title = document.getElementById('project_title').value;

    var datte = document.getElementById('date').value;

    var file_no = document.getElementById('file_no').value;

    var datte2 = document.getElementById('date2').value;

    var Bid_Opp_No = document.getElementById('Bid_Opp_No').value;

    var stakeholder = document.getElementById('stakeholder').value;

    var Objective = document.getElementById('Objective').value;

    var Messages = document.getElementById('Messages').value;

    var Timing = document.getElementById('Timing').value;

    var deliveryMethod = document.getElementById('deliveryMethod').value;
    var byWho = document.getElementById('byWho').value;
    var FeedBackMechanism = document.getElementById('FeedBackMechanism').value;

    var description = document.getElementById('description').value;

    var formData = new FormData();

    formData.append('projectTitle', project_title);
    formData.append('datte', datte);
    formData.append('fileNo', file_no);
    formData.append('datte2', datte2);
    formData.append('BidOppNo', Bid_Opp_No);
    formData.append('stakeholder', stakeholder);
    formData.append('Objective', Objective);
    formData.append('Messages', Messages);
    formData.append('Timing', Timing);
    formData.append('deliveryMethod', deliveryMethod);
    formData.append('byWho', byWho);
    formData.append('FeedBackMechanism', FeedBackMechanism);
    formData.append('description', description);

    console.log("formdata", formData)
    var xhttp = new XMLHttpRequest();
   

    xhttp.onload = function() {
        if (xhttp.status === 200) {
            var response = JSON.parse(xhttp.response);
            for(var modal of modals){
                modal.style.display = 'none';
            }
            for(var form of forms){
                form.reset();
            }
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Success', "Record saved!", 'success');
            getStakeholderComPlan();
        }
    };

    xhttp.onerror = function() {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    };

    xhttp.open('POST', serverUrl+'?function=save-stakeholderplan', true);
    console.log("formData", formData)
    xhttp.send(formData);
}

function getStakeholderComPlan(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        StakeholderComPlanData = response.StakeholderComPlanData;
         loopStakeholderComPlan(StakeholderComPlanData);
    }
    xhttp.open('GET', serverUrl+'?function=get-stakeholderplan', true);
    xhttp.send();
}
function loopStakeholderComPlan(data){
    var container = document.getElementById('stakeplanTbody');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                                <td>${counter}</td>
                                <td>${data[i].projectTitle}</td>
                                <td>${data[i].datte}</td>
                                <td>${data[i].fileNo}</td>
                                <td>${data[i].BidOppNo}</td>
                                <td>${data[i].stakeholder}</td>
                               
                                <td >
                                    <div>
                                        <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
                                             <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                            </button>
                    
                                        <div id='${i}' class="options-dropdown" style="right: 5px;">
                                            <button onclick="editStakeholderComPlan(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                                            <button onclick="viewStakeholderComPlan(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>

                                            <button onclick="deleteStakeholderComPlan(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                                            
                                        </div>
                                    </div>
                               
                                </td>
                            </tr> 
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
getStakeholderComPlan();

function editStakeholderComPlan(StakeholderComPlanId) {
        var data = StakeholderComPlanData.find((StakeholderComPlan)=>{
            return StakeholderComPlan.id == StakeholderComPlanId
        });


         // Populate the modal with the data received from the backend
         var modals = document.getElementById('modals');
          var modalContent = `
    
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Edit </h3>
            </div>
           <form id="form" class="addStakeholder">
    <div class="sub-form">
        <div class="single-form">
            <label for="project_title">Project</label>
            <input type="text" id="project_title" name="project_title" required  value="${data.projectTitle}"   />
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date" name="Date"   value="${data.datte}"   required/>
        </div>
    </div>

    <div class="sub-form">
     <div class="single-form">
            <label for="file_no">File No</label>
            <input type="text" id="file_no" name="file_no" required  value="${data.fileNo}" />
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date2" name="date" required  value="${data.datte2}"/>
        </div>
       
    </div>

    <div class="sub-form">
        <div class="single-form">
            <label for="Bid_Opp_No">Bid Opp No</label>
            <input type="text" id="Bid_Opp_No" name="Bid_Opp_No" required  value="${data.BidOppNo}"/>
        </div>

        <div class="single-form">
            <label for="stakeholder">Stakeholder</label>
            <input type="text" id="stakeholder" name="stakeholder" required   value="${data.stakeholder}"/>
        </div>
    </div>

    <div class="longer-form">
        <label for="Objective">Objective(Need/ why)</label>
        <textarea rows="10" id="Objective" name="Objective" cols="50" required>${data.Objective}</textarea>
    </div>
    
    <div class="longer-form">
        <label for="Messages">Messages(What)</label>
        <textarea rows="10" cols="50" id="Messages" name="Messages" required>${data.Messages}</textarea>
    </div>

    <div class="longer-form">
            <label for="Timing">Timing/Frequency(When)</label>
            <textarea rows="10" cols="50" id="Timing" name="Timing" required>${data.Timing}</textarea>
    </div>
    <div class="longer-form">
        <label for="DeliveryMethod">Delivery Method/Media Type(How)</label>
        <textarea rows="10" cols="50" id="deliveryMethod" name="DeliveryMethod" required>${data.deliveryMethod}</textarea>
    </div>
    <div class="longer-form">
        <label for="ByWho">By Who</label>
        <textarea rows="10" cols="50" id="byWho" name="ByWho" required>${data.byWho}</textarea>
    </div>
    <div class="longer-form">
        <label for="FeedBackMechanism">FeedBack Mechanism</label>
        <textarea rows="10" cols="50" id="FeedBackMechanism" name="FeedBackMechanism" required>${data.FeedBackMechanism}</textarea>
    </div>
    <div class="longer-form">
        <label for="description">Description</label>
        <textarea rows="10" cols="50" id="description" name="description" required>${data.description}</textarea>
    </div>

    <button type='button' class="edit-button" onclick="saveStakeholderComPlan()" id="save-btn">Save</button>  
</form>

        </div>
    </div>
    `;
         if (modals) {
             modals.innerHTML = modalContent;
             openModal();
         }

    
}
function viewStakeholderComPlan(StakeholderComPlanId) {
        var data = StakeholderComPlanData.find((StakeholderComPlan)=>{
            return StakeholderComPlan.id == StakeholderComPlanId
        });


         // Populate the modal with the data received from the backend
         var modals = document.getElementById('modals');
          var modalContent = `
    
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>View </h3>
            </div>
           <form id="form" class="addStakeholder">
    <div class="sub-form">
        <div class="single-form">
            <label for="project_title">Project</label>
            <input type="text" id="project_title" name="project_title" required  value="${data.projectTitle}" readonly  />
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date" name="Date"   value="${data.datte}"   required readonly/>
        </div>
    </div>

    <div class="sub-form">
     <div class="single-form">
            <label for="file_no">File No</label>
            <input type="text" id="file_no" name="file_no" required  value="${data.fileNo}"  readonly/>
        </div>
        <div class="single-form">
            <label for="date">Date</label>
            <input type="text" id="date2" name="date" required  value="${data.datte2}" readonly/>
        </div>
       
    </div>

    <div class="sub-form">
        <div class="single-form">
            <label for="Bid_Opp_No">Bid Opp No</label>
            <input type="text" id="Bid_Opp_No" name="Bid_Opp_No" required  value="${data.BidOppNo}" readonly/>
        </div>

        <div class="single-form">
            <label for="stakeholder">Stakeholder</label>
            <input type="text" id="stakeholder" name="stakeholder" required   value="${data.stakeholder}" readonly/>
        </div>
    </div>

    <div class="longer-form">
        <label for="Objective">Objective(Need/ why)</label>
        <textarea rows="10" id="Objective" name="Objective" cols="50" required readonly>${data.Objective}</textarea>
    </div>
    
    <div class="longer-form">
        <label for="Messages">Messages(What)</label>
        <textarea rows="10" cols="50" id="Messages" name="Messages" required readonly>${data.Messages}</textarea>
    </div>

    <div class="longer-form">
            <label for="Timing">Timing/Frequency(When)</label>
            <textarea rows="10" cols="50" id="Timing" name="Timing" required readonly>${data.Timing}</textarea>
    </div>
    <div class="longer-form">
        <label for="DeliveryMethod">Delivery Method/Media Type(How)</label>
        <textarea rows="10" cols="50" id="deliveryMethod" name="DeliveryMethod" required readonly>${data.deliveryMethod}</textarea>
    </div>
    <div class="longer-form">
        <label for="ByWho">By Who</label>
        <textarea rows="10" cols="50" id="byWho" name="ByWho" required readonly>${data.byWho}</textarea>
    </div>
    <div class="longer-form">
        <label for="FeedBackMechanism">FeedBack Mechanism</label>
        <textarea rows="10" cols="50" id="FeedBackMechanism" name="FeedBackMechanism" required readonly> ${data.FeedBackMechanism}</textarea>
    </div>
    <div class="longer-form">
        <label for="description">Description</label>
        <textarea rows="10" cols="50" id="description" name="description" required  readonly>${data.FeedBackMechanism}</textarea>
    </div>
 
</form>

        </div>
    </div>
    `;
         if (modals) {
             modals.innerHTML = modalContent;
             openModal();
         }

    
}

function deleteStakeholderComPlan(StakeholderComPlanId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('StakeholderComPlanId', StakeholderComPlanId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getStakeholderComPlan();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-stakeholderplan', true);
            xhttp.send(formData);
        }
      });
}



//Stakeholder and Comunication (communication Plan)

var  ScQualityData =[];
function addScQualityData() {
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add</h3>
            </div>

            <form id="form" class="addStakeholder">
    
                <div class="longer-form">
                    <label for="docRevisionNo">Document Revision No</label>
                    <input type="text" id="docRevisionNo" name="docRevisionNo" required />
                </div>
    
                <div class="longer-form">
                    <label for="changeInContent">Change in content</label>
                    <input type="text" id="changeInContent" name="changeInContent" required />
                </div>

                <div class="longer-form">
                    <label for="dateReleased">Date Released</label>
                    <input type="text" id="dateReleased" name="dateReleased" required />
                </div>
    
                <div class="longer-form">
                    <label for="releasedBy">Released By</label>
                    <input type="text" id="releasedBy" name="releasedBy" required />
                </div>

                <hr style="margin:50px 0" />

                <div class="longer-form" style="text-align:center">
                    <label for="templateQualityInfo">Template Quality Information</label><br>
                    <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
                </div>

                <div class="longer-form">
                    <label for="documentRevisionNo">Document Revision No</label>
                    <input type="text" id="documentRevisionNo" name="documentRevisionNo" required />
                </div>

                <div class="longer-form">
                    <label for="revisions">Revisions</label>
                    <input type="text" id="revisions" name="revisions" required />
                </div>

                <div class="longer-form">
                    <label for="releasedDate">Date Released</label>
                    <input type="text" id="releasedDate" name="releasedDate" required />
                </div>
    
                <div class="longer-form">
                    <label for="releasedByFinal">Released By</label>
                    <input type="text" id="releasedByFinal" name="releasedByFinal" required />
                </div>

                <button type='button' class="edit-button" onclick="saveScQualityData()" id="save-btn">Save</button>  
            </form>
        </div>
    </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveScQualityData(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

        const docRevisionNo = document.getElementById('docRevisionNo').value;
        const changeInContent = document.getElementById('changeInContent').value;
        const dateReleased = document.getElementById('dateReleased').value;
        const releasedBy = document.getElementById('releasedBy').value;
        const documentRevisionNo = document.getElementById('documentRevisionNo').value;
        const revisions = document.getElementById('revisions').value;
        const releasedDate = document.getElementById('releasedDate').value;
        const releasedByFinal = document.getElementById('releasedByFinal').value;

    

    var formData = new FormData();

    formData.append('docRevisionNo', docRevisionNo);
    formData.append('changeInContent', changeInContent);
    formData.append('dateReleased', dateReleased);
    formData.append('releasedBy', releasedBy);
    formData.append('documentRevisionNo', documentRevisionNo);
    formData.append('revisions', revisions);
    formData.append('releasedDate', releasedDate);
    formData.append('releasedByFinal', releasedByFinal);

    console.log("formdata", formData)
    var xhttp = new XMLHttpRequest();
   

    xhttp.onload = function() {
        if (xhttp.status === 200) {
            var response = JSON.parse(xhttp.response);
            for(var modal of modals){
                modal.style.display = 'none';
            }
            for(var form of forms){
                form.reset();
            }
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Success', "Record saved!", 'success');
            getScQualityData();
        }
    };

    xhttp.onerror = function() {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    };

    xhttp.open('POST', serverUrl+'?function=save-ScQualityData', true);
    console.log("formData", formData)
    xhttp.send(formData);
}

function getScQualityData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        ScQualityData = response.ScQualityData;
         loopScQualityData(ScQualityData);
    }
    xhttp.open('GET', serverUrl+'?function=get-ScQualityData', true);
    xhttp.send();
}

function loopScQualityData(data){
    var container = document.getElementById('scQualityTbody');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
            <tr>
                                <td>${counter}</td>
                                <td>${data[i].docRevisionNo}</td>
                                <td>${data[i].changeInContent}</td>
                                <td>${data[i].dateReleased}</td>
                                <td>${data[i].releasedBy}</td>

                                <td >
                                    <div>
                                        <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
                                             <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                            </button>
                    
                                        <div id='${i}' class="options-dropdown" style="right: 5px;">
                                            <button onclick="editScQualityData(${data[i].id})" class="openModalBtnEdit option-button" >
                                <img src="../assetsPeter/leadedit.png"/> Edit
                            </button>
                                            <button onclick="viewScQualityData(${data[i].id})" class="openModalBtnView option-button">
                                <img src="../assetsPeter/leadview.png" />
                                View
                            </button>
                                            <button onclick="deleteScQualityData(${data[i].id})" class="option-button">
                                <img src="../assetsPeter/leaddelete.png" />
                                Delete
                            </button>
                                            
                                        </div>
                                    </div>
                               
                                </td>
                            </tr> 
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
getScQualityData();

function editScQualityData(ScQualityDataId) {
    var data = StakeholderComPlanData.find((StakeholderComPlan)=>{
        return StakeholderComPlan.id == ScQualityDataId
    });


     // Populate the modal with the data received from the backend
     var modals = document.getElementById('modals');
     var modalContent = `
     <style>
         .select-input{
             display: flex;
             width: 88%;
             height: 24px;
             padding: 7px 17px;
             align-items: flex-start;
             gap: 10px;
             flex-shrink: 0;
             border-radius: 8px;
             border: 1px solid var(--Foundation-Primary-P400, #0047B3);
             background: var(--Foundation-White-W300, #F6F6F6);
         }
     </style>
     <div id="myModal" class="modal-container">
         <div class="modal-content">
             <span onclick="closeModal()" class="close">&times;</span>
             <div class="add-text">
                 <h3>Add</h3>
             </div>
 
             <form id="form" class="addStakeholder">
     
                 <div class="longer-form">
                     <label for="docRevisionNo">Document Revision No</label>
                     <input type="text" id="docRevisionNo" name="docRevisionNo" required value="${data.datte}"  />
                 </div>
     
                 <div class="longer-form">
                     <label for="changeInContent">Change in content</label>
                     <input type="text" id="changeInContent" name="changeInContent" required value="${data.datte}" />
                 </div>
 
                 <div class="longer-form">
                     <label for="dateReleased">Date Released</label>
                     <input type="text" id="dateReleased" name="dateReleased" required value="${data.datte}"  />
                 </div>
     
                 <div class="longer-form">
                     <label for="releasedBy">Released By</label>
                     <input type="text" id="releasedBy" name="releasedBy" required value="${data.datte}"  />
                 </div>
 
                 <hr style="margin:50px 0" />
 
                 <div class="longer-form" style="text-align:center">
                     <label for="templateQualityInfo">Template Quality Information</label><br>
                     <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
                 </div>
 
                 <div class="longer-form">
                     <label for="documentRevisionNo">Document Revision No</label>
                     <input type="text" id="documentRevisionNo" name="documentRevisionNo" required value="${data.datte}"  />
                 </div>
 
                 <div class="longer-form">
                     <label for="revisions">Revisions</label>
                     <input type="text" id="revisions" name="revisions" required  value="${data.datte}" />
                 </div>
 
                 <div class="longer-form">
                     <label for="releasedDate">Date Released</label>
                     <input type="text" id="releasedDate" name="releasedDate" required  value="${data.datte}" />
                 </div>
     
                 <div class="longer-form">
                     <label for="releasedByFinal">Released By</label>
                     <input type="text" id="releasedByFinal" name="releasedByFinal" required value="${data.datte}"  />
                 </div>
 
                 <button type='button' class="edit-button" onclick="saveScQualityData()" id="save-btn">Save</button>  
             </form>
         </div>
     </div>
     `;
     if (modals) {
         modals.innerHTML = modalContent;
         openModal();
     }
}

function viewScQualityData(ScQualityDataId) {
    var data = StakeholderComPlanData.find((StakeholderComPlan)=>{
        return StakeholderComPlan.id == ScQualityDataId
    });


     // Populate the modal with the data received from the backend
     var modals = document.getElementById('modals');
     var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add</h3>
            </div>

            <form id="form" class="addStakeholder">
    
                <div class="longer-form">
                    <label for="docRevisionNo">Document Revision No</label>
                    <input type="text" id="docRevisionNo" name="docRevisionNo" required value="${data.datte}" readonly />
                </div>
    
                <div class="longer-form">
                    <label for="changeInContent">Change in content</label>
                    <input type="text" id="changeInContent" name="changeInContent" required value="${data.datte}" readonly />
                </div>

                <div class="longer-form">
                    <label for="dateReleased">Date Released</label>
                    <input type="text" id="dateReleased" name="dateReleased" required value="${data.datte}" readonly />
                </div>
    
                <div class="longer-form">
                    <label for="releasedBy">Released By</label>
                    <input type="text" id="releasedBy" name="releasedBy" required value="${data.datte}" readonly />
                </div>

                <hr style="margin:50px 0" />

                <div class="longer-form" style="text-align:center">
                    <label for="templateQualityInfo">Template Quality Information</label><br>
                    <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
                </div>

                <div class="longer-form">
                    <label for="documentRevisionNo">Document Revision No</label>
                    <input type="text" id="documentRevisionNo" name="documentRevisionNo" required value="${data.datte}" readonly />
                </div>

                <div class="longer-form">
                    <label for="revisions">Revisions</label>
                    <input type="text" id="revisions" name="revisions" required  value="${data.datte}" readonly />
                </div>

                <div class="longer-form">
                    <label for="releasedDate">Date Released</label>
                    <input type="text" id="releasedDate" name="releasedDate" required  value="${data.datte}" readonly />
                </div>
    
                <div class="longer-form">
                    <label for="releasedByFinal">Released By</label>
                    <input type="text" id="releasedByFinal" name="releasedByFinal" required value="${data.datte}" readonly />
                </div>

                <button type='button' class="edit-button" onclick="saveScQualityData()" id="save-btn">Save</button>  
            </form>
        </div>
    </div>
`;

     if (modals) {
         modals.innerHTML = modalContent;
         openModal();
     }


}

function deleteScQualityData(ScQualityDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('ScQualityDataId', ScQualityDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getScQualityData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-ScQualityData', true);
            xhttp.send(formData);
        }
      });
}



//Rmtp Template(sirlaw)
var  RmpTemplateData =[];

function addRmpTemplate(){
    var modals = document.getElementById('modals');
    var modalContent = `
    
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
        <form id="form">
                        <div class="sub-form">
                            <div class="single-form">
                                <label for="project_title">Project</label>
                                <input type="text" id="project_title" name="project" required />
                            </div>
                            <div class="single-form">
                                <label for="description">Description</label>
                                <input type="text" id="description" name="description" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="date">Date</label>
                                <input type="date" id="date" required />
                            </div>
                            <div class="single-form">
                                <label for="biz_no">Business Case ID</label>
                                <input type="text" id="biz_no" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="Bid_Opp_No">Bid Opp No</label>
                                <input type="text" id="Bid_Opp_No" required />
                            </div>

                            <div class="single-form">
                                <label for="RiskEvent">Risk Event</label>
                                <input type="text" id="RiskEvent" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="threatOpp">Threat or Opportunity</label>
                                <select id="threatOpp" required>
                                    <option value=""></option>
                                    <option value="Threat">Threat</option>
                                    <option value="Opportunity">Opportunity</option>
                                </select>
                            </div>
                            <div class="single-form">
                                <label for="riskCause">Risk Cause</label>
                                <input type="text" id="riskCause" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="UncertainEvent">Uncertain Event</label>
                                <input type="text" id="UncertainEvent" required />
                            </div>
                            <div class="single-form">
                                <label for="EfftObjectives">Effect on Objectives</label>
                                <input type="text" id="EfftObjectives" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="RiskSeverity">Risk Severity</label>
                                <select id="RiskSeverity" required>
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="RiskResponse">Risk Response</label>
                                <select id="RiskResponse" required>
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                            </div>
                        </div>

                        <div class="longer-form">
                            <label for="actionToTake">Actions to be taken</label>
                            <textarea rows="10" id="actionToTake" cols="50" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="contgPlan">Contingency Plan</label>
                            <textarea rows="10" cols="50" id="contgPlan" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="manageCost">Cost to manage risk</label>
                            <textarea rows="10" cols="50" id="manageCost" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="riskOwner">Risk Owner</label>
                            <input type="text" id="riskOwner" required />
                        </div>

                        <button type="button" class="edit-button" onclick="saveRmpTemplate()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveRmpTemplate(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var project_title = document.getElementById('project_title').value;
    var description = document.getElementById('description').value;
    var date = document.getElementById('date').value;
    var biz_no = document.getElementById('biz_no').value;
    var Bid_Opp_No = document.getElementById('Bid_Opp_No').value;
    var riskEvent = document.getElementById('RiskEvent').value;
    var threat_Opp = document.getElementById('threatOpp').value;
    var riskCause = document.getElementById('riskCause').value;
    var UncertainEvent = document.getElementById('UncertainEvent').value;
    var EfftObjectives = document.getElementById('EfftObjectives').value;
    var riskSeverity = document.getElementById('RiskSeverity').value;
    var riskResponse = document.getElementById('RiskResponse').value;
    var actionToTake = document.getElementById('actionToTake').value;
    var contingengyPlan = document.getElementById('contgPlan').value;
    var manageCost = document.getElementById('manageCost').value;
    var riskOwner = document.getElementById('riskOwner').value;
    
    var formData = new FormData();
    formData.append('projectTitle', project_title);
    formData.append('description', description);
    formData.append('date', date);
    formData.append('bizNo', biz_no);
    formData.append('BidOppNo', Bid_Opp_No);
    formData.append('riskEvent', riskEvent);
    formData.append('threatOpp', threat_Opp);
    formData.append('riskCause', riskCause);
    formData.append('UncertainEvent', UncertainEvent);
    formData.append('riskSeverity', riskSeverity);
    formData.append('riskResponse', riskResponse);
    formData.append('actionToTake', actionToTake);
    formData.append('EfftObjectives', EfftObjectives);
    formData.append('contingengyPlan', contingengyPlan);
    formData.append('manageCost', manageCost);
    formData.append('riskOwner', riskOwner);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        // getRmpTemplateData();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-RmpTemplate', true);
    xhttp.send(formData);
}
function getRmpTemplateData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        RmpTemplateData = response.RmpTemplateData;
        loopRmpTemplateData(RmpTemplateData);
    }
    xhttp.open('GET', serverUrl+'?function=get-RmpTemplate', true);
    xhttp.send();
}

function loopRmpTemplateData(data){
        var container = document.getElementById('RmpTbody');
        var tr = "";
        var counter = 0;
        if(data && data.length > 0){
            for(var i=0; i < data.length; i++){
            counter++;
            tr += `
        <tr>
                        <td>${counter}</td>
                        <td>${data[i].project}</td>
                        <td>${data[i].description}</td>
                        <td>${data[i].date}</td>
                        <td>${data[i].bizNo}</td>
                        <td>${data[i].BidOppNo}</td>
                        <td>${data[i].riskEvent}</td>
                        <td>${data[i].threatOpp}</td>

                        <td class="threedots">
                                        <div>
                                            <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
                                                <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                                            </button>
                        
                                            <div id='${i}' class="options-dropdown" style="right: 5px;">
                                                <button onclick="editRmpTemplate(${data[i].id})" class="openModalBtnEdit option-button" >
                                    <img src="../assetsPeter/leadedit.png"/> Edit
                                </button>
                                                <button onclick="viewRmpTemplate(${data[i].id})" class="openModalBtnView option-button">
                                    <img src="../assetsPeter/leadview.png" />
                                    View
                                </button>

                                                <button onclick="deleteRmpTemplate(${data[i].id})" class="option-button">
                                    <img src="../assetsPeter/leaddelete.png" />
                                    Delete
                                </button>
                                                
                                            </div>
                                        </div>
                                
                            </td>
                        </tr> 
            `;
            if(container){
                container.innerHTML = tr;
            }
        }
        }else{
            if(container){
                container.innerHTML = "No data yet!";
            }
        }
        
    }
    getRmpTemplateData();

function viewRmpTemplate(RmpTemplateId) {

var data = RmpTemplateData.find((RmpTemplate)=>{
    return RmpTemplate.id = RmpTemplateId;
    })

    var modals = document.getElementById('modals');
    var modalContent = `

    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
            <form id="form">
                
                    
                    <div class="sub-form">
                        <div class="single-form">
                            <label for="project">Project</label>
                            <input type="text" id="project_title" name="project" value="${data.project_title}" required readonly/>
                        </div>
                        <div class="single-form">
                            <label for="description">Description</label>
                            <input type="text" id="description" name="description"  value="${data.description}" readonly required />
                        </div>
                    </div>

                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Date">Date</label>
                            <input type="date" id="date" value="${data.date}"  readonly required />
                        </div>
                        <div class="single-form">
                            <label for="Business Case ID">Business Case ID </label>
                            <input type="text" id="biz_no"   value="${data.biz_no}"  readonly required />
                            
                        </div>
                    </div>
                    

                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Bid Opp No">Bid Opp No</label>
                            <input type="text" id="Bid_Opp_No"  value="${data.Bid_Opp_No}" readonly required/>
                        </div>

                        <div class="single-form">
                            <label for="Risk Event">Risk Event</label>
                            <input type="text" id="RiskEvent" value="${data.riskEvent}" readonly required />
                        </div>
                    </div>

                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Threat or Opportunity">Threat or Opportunity</label>
                            <select id="threatOpp" required >
                                <option value="Threat" ${data.threatOpp === 'Threat' ? 'selected' : ''}>Threat</option>
                                <option value="Opportunity" ${data.threatOpp === 'Opportunity' ? 'selected' : ''}>Opportunity</option>
                            </select>
                        </div>
                        <div class="single-form">
                            <label for="Risk Cause">Risk Cause</label>
                            <input type="text" id="riskCause" name="Risk Cause" value="${data.riskCause}" readonly  required />
                        </div>
                    </div>

                    <div class="sub-form">
                        <div class="single-form">
                            <label for="UncertainEvent">Uncertain Event</label>
                            <input type="text" id="UncertainEvent"  value="${data.UncertainEvent}" readonly required />
                        </div>
                        <div class="single-form">
                            <label for="Effect on Objectives">Effect on Objectives</label>
                            <input type="text" id="EfftObjectives"  value="${data.EfftObjectives}" readonly required />
                            
                        </div>
                    </div>
                    

                    <div class="sub-form">
                        <div class="single-form">
                            <label for="Risk Severity">Risk Severity</label>

                                <select id="Risk Severity" value="${data.riskSeverity}"  required readonly>
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                        </div>

                        <div class="single-form">
                            <label for="RiskResponse">Risk Response</label>
                            <select id="RiskResponse" value="${data.riskSeverity}"  readonly required>
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                        </div>
                    </div>

                

                    <div class="longer-form">
                        <label for="Actions to be taken">Actions to be taken</label>
                        <textarea rows="10" id="actionToTake" cols="50" required  readonly value="${data.actionToTake}"></textarea>
                    </div>

                    <div class="longer-form">
                        <label for="Contingency Plan">Contingency Plan</label>
                    <textarea rows="10" cols="50" id="contgPlan" required  readonly value="${data.contingengyPlan}"></textarea>
                    </div>

                    <div class="longer-form">
                        <label for=Cost to manage risk">Cost to manage risk</label>
                    <textarea rows="10" cols="50" id="manageCost" required  readonly value="${data.manageCost}"></textarea>
                    </div>
                    
                    <div class="longer-form">
                        <label for="Risk Owner">Risk Owner</label>
                    <input id="riskOwner" required readonly value="${data.manageCost}">
                    </div>
                    

                </form> 
        </div>
    </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }

}

function editRmpTemplate(RmpTemplateId) {
   var data = RmpTemplateData.find((RmpTemplate)=>{
    return RmpTemplate.id = RmpTemplateId;
   })
   var modals = document.getElementById('modals');
   var modalContent = `

   <style>
       .select-input{
           display: flex;
           width: 88%;
           height: 24px;
           padding: 7px 17px;
           align-items: flex-start;
           gap: 10px;
           flex-shrink: 0;
           border-radius: 8px;
           border: 1px solid var(--Foundation-Primary-P400, #0047B3);
           background: var(--Foundation-White-W300, #F6F6F6);
       }
   </style>
   <div id="myModal" class="modal-container">
       <div class="modal-content">
           <span onclick="closeModal()" class="close">&times;</span>
           <div class="add-text">
               <h3>Edit </h3>
           </div>
        <form id="form">
                        <div class="sub-form">
                            <div class="single-form">
                                <label for="project_title">Project</label>
                                <input type="text" id="project_title" name="project" value="${data.project}" required />
                            </div>
                            <div class="single-form">
                                <label for="description">Description</label>
                                <input type="text" id="description" name="description" required  value="${data.description}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="date">Date</label>
                                <input type="date" id="date" required  value="${data.date}"/>
                            </div>
                            <div class="single-form">
                                <label for="biz_no">Business Case ID</label>
                                <input type="text" id="biz_no" required  value="${data.bizNo}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="Bid_Opp_No">Bid Opp No</label>
                                <input type="text" id="Bid_Opp_No" required value="${data.BidOppNo}"/>
                            </div>

                            <div class="single-form">
                                <label for="RiskEvent">Risk Event</label>
                                <input type="text" id="RiskEvent" required  value="${data.riskEvent}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="threatOpp">Threat or Opportunity</label>
                                <select id="threatOpp" required value="${data.threatOpp}">
                                    <option value=""></option>
                                    <option value="Threat">Threat</option>
                                    <option value="Opportunity">Opportunity</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="riskCause">Risk Cause</label>
                                
                                <input type="text" id="riskCause" required value="${data.riskCause}"  />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="UncertainEvent">Uncertain Event</label>
                                <input type="text" id="UncertainEvent" required value="${data.UncertainEvent}"/>
                            </div>
                            <div class="single-form">
                                <label for="EfftObjectives">Effect on Objectives</label>
                                <input type="text" id="EfftObjectives" required  value="${data.EfftObjectives}" />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="RiskSeverity">Risk Severity</label>
                                <select id="RiskSeverity" required  value="${data.riskSeverity}" >
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="RiskResponse">Risk Response</label>
                                <select id="RiskResponse" required value="${data.riskResponse}">
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                            </div>
                        </div>

                        <div class="longer-form">
                            <label for="actionToTake">Actions to be taken</label>
                            <textarea rows="10" id="actionToTake" cols="50" required  value="">${data.actionToTake}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="contgPlan">Contingency Plan</label>
                            <textarea rows="10" cols="50" id="contgPlan" required value="">${data.contingengyPlan}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="manageCost">Cost to manage risk</label>
                            <textarea rows="10" cols="50" id="manageCost" required value="">${data.manageCost}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="riskOwner">Risk Owner</label>
                            <input type="text" id="riskOwner" required  value="${data.manageCost}"/>
                        </div>

                        <button type="button" class="edit-button" onclick="saveRmpTemplate()" id="save-btn">Save</button>  
    </form>


           
       </div>
   </div>
   `;
   if (modals) {
       modals.innerHTML = modalContent;
       openModal();
   }

}
function deleteRmpTemplate(RmpTemplateId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('RmpTemplateId', RmpTemplateId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getRmpTemplateData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-RmpTemplate', true);
            xhttp.send(formData);
        }
      });
}


// not connected
////Rmtp Template(Ex)


var  RmpTemplateDataEx =[];

function addRmpTemplateEx(){

    var modals = document.getElementById('modals');
    var modalContent = `
    
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
        <form id="form">
                        <div class="sub-form">
                            <div class="single-form">
                                <label for="project_title">Project</label>
                                <input type="text" id="project_title" name="project" required />
                            </div>
                            <div class="single-form">
                                <label for="description">Description</label>
                                <input type="text" id="description" name="description" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="date">Date</label>
                                <input type="date" id="date" required />
                            </div>
                            <div class="single-form">
                                <label for="biz_no">Business Case ID</label>
                                <input type="text" id="biz_no" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="Bid_Opp_No">Bid Opp No</label>
                                <input type="text" id="Bid_Opp_No" required />
                            </div>

                            <div class="single-form">
                                <label for="RiskEvent">Risk Event</label>
                                <input type="text" id="RiskEvent" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="threatOpp">Threat or Opportunity</label>
                                <select id="threatOpp" required>
                                    <option value=""></option>
                                    <option value="Threat">Threat</option>
                                    <option value="Opportunity">Opportunity</option>
                                </select>
                            </div>
                            <div class="single-form">
                                <label for="riskCause">Risk Cause</label>
                                <input type="text" id="riskCause" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="UncertainEvent">Uncertain Event</label>
                                <input type="text" id="UncertainEvent" required />
                            </div>
                            <div class="single-form">
                                <label for="EfftObjectives">Effect on Objectives</label>
                                <input type="text" id="EfftObjectives" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="RiskSeverity">Risk Severity</label>
                                <select id="RiskSeverity" required>
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="RiskResponse">Risk Response</label>
                                <select id="RiskResponse" required>
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                            </div>
                        </div>

                        <div class="longer-form">
                            <label for="actionToTake">Actions to be taken</label>
                            <textarea rows="10" id="actionToTake" cols="50" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="contgPlan">Contingency Plan</label>
                            <textarea rows="10" cols="50" id="contgPlan" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="manageCost">Cost to manage risk</label>
                            <textarea rows="10" cols="50" id="manageCost" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="riskOwner">Risk Owner</label>
                            <input type="text" id="riskOwner" required />
                        </div>

                        <button type="button" class="edit-button" onclick="saveRmpTemplateEx()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveRmpTemplateEx(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    var project_title = document.getElementById('project_title').value;
    var description = document.getElementById('description').value;
    var date = document.getElementById('date').value;
    var biz_no = document.getElementById('biz_no').value;
    var Bid_Opp_No = document.getElementById('Bid_Opp_No').value;
    var riskEvent = document.getElementById('RiskEvent').value;
    var threat_Opp = document.getElementById('threatOpp').value;
    var riskCause = document.getElementById('riskCause').value;
    var UncertainEvent = document.getElementById('UncertainEvent').value;
    var EfftObjectives = document.getElementById('EfftObjectives').value;
    var riskSeverity = document.getElementById('RiskSeverity').value;
    var riskResponse = document.getElementById('RiskResponse').value;
    var actionToTake = document.getElementById('actionToTake').value;
    var contingengyPlan = document.getElementById('contgPlan').value;
    var manageCost = document.getElementById('manageCost').value;
    var riskOwner = document.getElementById('riskOwner').value;
    
    var formData = new FormData();
    formData.append('projectTitle', project_title);
    formData.append('description', description);
    formData.append('date', date);
    formData.append('bizNo', biz_no);
    formData.append('BidOppNo', Bid_Opp_No);
    formData.append('riskEvent', riskEvent);
    formData.append('threatOpp', threat_Opp);
    formData.append('riskCause', riskCause);
    formData.append('UncertainEvent', UncertainEvent);
    formData.append('riskSeverity', riskSeverity);
    formData.append('riskResponse', riskResponse);
    formData.append('actionToTake', actionToTake);
    formData.append('EfftObjectives', EfftObjectives);
    formData.append('contingengyPlan', contingengyPlan);
    formData.append('manageCost', manageCost);
    formData.append('riskOwner', riskOwner);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        for(var modal of modals){
            modal.style.display = 'none';
        }
        for(var form of forms){
            form.reset();
        }
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        getRmpTemplateDataEx();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }
    xhttp.open('POST', serverUrl+'?function=save-RmpTemplateEx', true);
    xhttp.send(formData);
}
function getRmpTemplateDataEx(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        RmpTemplateExData = response.RmpTemplateExData;
        loopRmpTemplateDataEx(RmpTemplateExData);
    }
    xhttp.open('GET', serverUrl+'?function=get-RmpTemplateEx', true);
    xhttp.send();
}
function loopRmpTemplateDataEx(data){
        var container = document.getElementById('RmpxTbody');
        var tr = "";
        var counter = 0;
        if(data && data.length > 0){
            for(var i=0; i < data.length; i++){
            counter++;
            tr += `
        <tr>
                        <td>${counter}</td>
                        <td>${data[i].project}</td>
                        <td>${data[i].description}</td>
                        <td>${data[i].date}</td>
                        <td>${data[i].bizNo}</td>
                        <td>${data[i].BidOppNo}</td>
                        <td>${data[i].riskEvent}</td>
                        <td>${data[i].threatOpp}</td>

                        <td class="threedots">
                                        <div>
                                            <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
                                                <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
                                <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
                                </svg>
                                            </button>
                        
                                            <div id='${i}' class="options-dropdown" style="right: 5px;">
                                                <button onclick="editRmpTemplateEx(${data[i].id})" class="openModalBtnEdit option-button" >
                                    <img src="../assetsPeter/leadedit.png"/> Edit
                                </button>

                                
                                                <button onclick="viewRmpTemplateEx(${data[i].id})" class="openModalBtnView option-button">
                                    <img src="../assetsPeter/leadview.png" />
                                    View
                                </button>

                                                <button onclick="deleteRmpTemplateEx(${data[i].id})" class="option-button">
                                    <img src="../assetsPeter/leaddelete.png" />
                                    Delete
                                </button>
                                                
                                            </div>
                                        </div>
                                
                            </td>
                        </tr> 
            `;
            if(container){
                container.innerHTML = tr;
            }
        }
        }else{
            if(container){
                container.innerHTML = "No data yet!";
            }
        }
        
}
    getRmpTemplateDataEx();

function viewRmpTemplateEx(RmpTemplateId) {

var data = RmpTemplateDataEx.find((RmpTemplate)=>{
    return RmpTemplate.id = RmpTemplateId;
    })

    var modals = document.getElementById('modals');
    var modalContent = `
    
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add </h3>
            </div>
        <form id="form">
                        <div class="sub-form">
                            <div class="single-form">
                                <label for="project_title">Project</label>
                                <input type="text" id="project_title" name="project" required />
                            </div>
                            <div class="single-form">
                                <label for="description">Description</label>
                                <input type="text" id="description" name="description" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="date">Date</label>
                                <input type="date" id="date" required />
                            </div>
                            <div class="single-form">
                                <label for="biz_no">Business Case ID</label>
                                <input type="text" id="biz_no" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="Bid_Opp_No">Bid Opp No</label>
                                <input type="text" id="Bid_Opp_No" required />
                            </div>

                            <div class="single-form">
                                <label for="RiskEvent">Risk Event</label>
                                <input type="text" id="RiskEvent" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="threatOpp">Threat or Opportunity</label>
                                <select id="threatOpp" required>
                                    <option value=""></option>
                                    <option value="Threat">Threat</option>
                                    <option value="Opportunity">Opportunity</option>
                                </select>
                            </div>
                            <div class="single-form">
                                <label for="riskCause">Risk Cause</label>
                                <input type="text" id="riskCause" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="UncertainEvent">Uncertain Event</label>
                                <input type="text" id="UncertainEvent" required />
                            </div>
                            <div class="single-form">
                                <label for="EfftObjectives">Effect on Objectives</label>
                                <input type="text" id="EfftObjectives" required />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="RiskSeverity">Risk Severity</label>
                                <select id="RiskSeverity" required>
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="RiskResponse">Risk Response</label>
                                <select id="RiskResponse" required>
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                            </div>
                        </div>

                        <div class="longer-form">
                            <label for="actionToTake">Actions to be taken</label>
                            <textarea rows="10" id="actionToTake" cols="50" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="contgPlan">Contingency Plan</label>
                            <textarea rows="10" cols="50" id="contgPlan" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="manageCost">Cost to manage risk</label>
                            <textarea rows="10" cols="50" id="manageCost" required></textarea>
                        </div>

                        <div class="longer-form">
                            <label for="riskOwner">Risk Owner</label>
                            <input type="text" id="riskOwner" required />
                        </div>

                        <button type="button" class="edit-button" onclick="saveRmpTemplateEx()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }

}
function editRmpTemplateEx(RmpTemplateId) {
   var data = RmpTemplateDataEx.find((RmpTemplate)=>{
    return RmpTemplate.id = RmpTemplateId;
   })
   var modals = document.getElementById('modals');
   var modalContent = `

   <style>
       .select-input{
           display: flex;
           width: 88%;
           height: 24px;
           padding: 7px 17px;
           align-items: flex-start;
           gap: 10px;
           flex-shrink: 0;
           border-radius: 8px;
           border: 1px solid var(--Foundation-Primary-P400, #0047B3);
           background: var(--Foundation-White-W300, #F6F6F6);
       }
   </style>
   <div id="myModal" class="modal-container">
       <div class="modal-content">
           <span onclick="closeModal()" class="close">&times;</span>
           <div class="add-text">
               <h3>Edit </h3>
           </div>
        <form id="form">
                        <div class="sub-form">
                            <div class="single-form">
                                <label for="project_title">Project</label>
                                <input type="text" id="project_title" name="project" value="${data.project}" required />
                            </div>
                            <div class="single-form">
                                <label for="description">Description</label>
                                <input type="text" id="description" name="description" required  value="${data.description}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="date">Date</label>
                                <input type="date" id="date" required  value="${data.date}"/>
                            </div>
                            <div class="single-form">
                                <label for="biz_no">Business Case ID</label>
                                <input type="text" id="biz_no" required  value="${data.bizNo}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="Bid_Opp_No">Bid Opp No</label>
                                <input type="text" id="Bid_Opp_No" required value="${data.BidOppNo}"/>
                            </div>

                            <div class="single-form">
                                <label for="RiskEvent">Risk Event</label>
                                <input type="text" id="RiskEvent" required  value="${data.riskEvent}"/>
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="threatOpp">Threat or Opportunity</label>
                                <select id="threatOpp" required value="${data.threatOpp}">
                                    <option value=""></option>
                                    <option value="Threat">Threat</option>
                                    <option value="Opportunity">Opportunity</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="riskCause">Risk Cause</label>
                                
                                <input type="text" id="riskCause" required value="${data.riskCause}"  />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="UncertainEvent">Uncertain Event</label>
                                <input type="text" id="UncertainEvent" required value="${data.UncertainEvent}"/>
                            </div>
                            <div class="single-form">
                                <label for="EfftObjectives">Effect on Objectives</label>
                                <input type="text" id="EfftObjectives" required  value="${data.EfftObjectives}" />
                            </div>
                        </div>

                        <div class="sub-form">
                            <div class="single-form">
                                <label for="RiskSeverity">Risk Severity</label>
                                <select id="RiskSeverity" required  value="${data.riskSeverity}" >
                                    <option value=""></option>
                                    <option value="Critical">Critical</option>
                                    <option value="Serious">Serious</option>
                                    <option value="Important">Important</option>
                                    <option value="Acceptance">Acceptance</option>
                                </select>
                            </div>

                            <div class="single-form">
                                <label for="RiskResponse">Risk Response</label>
                                <select id="RiskResponse" required value="${data.riskResponse}">
                                    <option value=""></option>
                                    <option value="Avoid">Avoid</option>
                                    <option value="Transfer">Transfer</option>
                                    <option value="Reduce">Reduce</option>
                                    <option value="Accept">Accept</option>
                                </select>
                            </div>
                        </div>

                        <div class="longer-form">
                            <label for="actionToTake">Actions to be taken</label>
                            <textarea rows="10" id="actionToTake" cols="50" required  value="">${data.actionToTake}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="contgPlan">Contingency Plan</label>
                            <textarea rows="10" cols="50" id="contgPlan" required value="">${data.contingengyPlan}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="manageCost">Cost to manage risk</label>
                            <textarea rows="10" cols="50" id="manageCost" required value="">${data.manageCost}</textarea>
                        </div>

                        <div class="longer-form">
                            <label for="riskOwner">Risk Owner</label>
                            <input type="text" id="riskOwner" required  value="${data.manageCost}"/>
                        </div>

                        <button type="button" class="edit-button" onclick="saveRmpTemplate()" id="save-btn">Save</button>  
    </form>


           
       </div>
   </div>
   `;
   if (modals) {
       modals.innerHTML = modalContent;
       openModal();
   }

}

function deleteRmpTemplateEx(RmpTemplateId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('RmpTemplateExId', RmpTemplateExId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getRmpTemplateDataEx();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                    
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
            xhttp.open('POST', serverUrl+'?function=delete-RmpTemplateEx', true);
            xhttp.send(formData);
        }
      });
}


// Rmtp Template(QUALITY)
// done but not connected

var  RmpQTemplateData =[];

function addRmpQTemplateData() {
    var modals = document.getElementById('modals');
    var modalContent = `
    <style>
        .select-input{
            display: flex;
            width: 88%;
            height: 24px;
            padding: 7px 17px;
            align-items: flex-start;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #0047B3);
            background: var(--Foundation-White-W300, #F6F6F6);
        }
    </style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            <span onclick="closeModal()" class="close">&times;</span>
            <div class="add-text">
                <h3>Add</h3>
            </div>

            <form id="form" class="addStakeholder">
    
                <div class="longer-form">
                    <label for="docRevisionNo">Document Revision No</label>
                    <input type="text" id="docRevisionNo" name="docRevisionNo" required />
                </div>
    
                <div class="longer-form">
                    <label for="changeInContent">Change in content</label>
                    <input type="text" id="changeInContent" name="changeInContent" required />
                </div>

                <div class="longer-form">
                    <label for="dateReleased">Date Released</label>
                    <input type="text" id="dateReleased" name="dateReleased" required />
                </div>
    
                <div class="longer-form">
                    <label for="releasedBy">Released By</label>
                    <input type="text" id="releasedBy" name="releasedBy" required />
                </div>

                <hr style="margin:50px 0" />

                <div class="longer-form" style="text-align:center">
                    <label for="templateQualityInfo">Template Quality Information</label><br>
                    <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
                </div>

                <div class="longer-form">
                    <label for="documentRevisionNo">Document Revision No</label>
                    <input type="text" id="documentRevisionNo" name="documentRevisionNo" required />
                </div>

                <div class="longer-form">
                    <label for="revisions">Revisions</label>
                    <input type="text" id="revisions" name="revisions" required />
                </div>

                <div class="longer-form">
                    <label for="releasedDate">Date Released</label>
                    <input type="text" id="releasedDate" name="releasedDate" required />
                </div>
    
                <div class="longer-form">
                    <label for="releasedByFinal">Released By</label>
                    <input type="text" id="releasedByFinal" name="releasedByFinal" required />
                </div>

                <button type='button' class="edit-button" onclick="saveRmpQTemplateData()" id="save-btn">Save</button>  
            </form>
        </div>
    </div>
    `;
    if (modals) {
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveRmpQTemplateData(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

        const docRevisionNo = document.getElementById('docRevisionNo');
        const changeInContent = document.getElementById('changeInContent');
        const dateReleased = document.getElementById('dateReleased');
        const releasedBy = document.getElementById('releasedBy');
        const documentRevisionNo = document.getElementById('documentRevisionNo');
        const revisions = document.getElementById('revisions');
        const releasedDate = document.getElementById('releasedDate');
        const releasedByFinal = document.getElementById('releasedByFinal');

    

    var formData = new FormData();

    formData.append('docRevisionNo', docRevisionNo);
    formData.append('changeInContent', changeInContent);
    formData.append('dateReleased', dateReleased);
    formData.append('releasedBy', releasedBy);
    formData.append('documentRevisionNo', documentRevisionNo);
    formData.append('revisions', revisions);
    formData.append('releasedDate', releasedDate);
    formData.append('releasedByFinal', releasedByFinal);

    console.log("formdata", formData)
    var xhttp = new XMLHttpRequest();
   

    xhttp.onload = function() {
        if (xhttp.status === 200) {
            var response = JSON.parse(xhttp.response);
            for(var modal of modals){
                modal.style.display = 'none';
            }
            for(var form of forms){
                form.reset();
            }
            savebtn.disabled = false;
            savebtn.innerHTML = "Save";
            swal('Success', "Record saved!", 'success');
            getStakeholderComPlan();
        }
    };

    xhttp.onerror = function() {
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occurred, try again!", 'error');
    };

    xhttp.open('POST', serverUrl+'?function=save-RmpQTemplateData', true);
    console.log("formData", formData)
    xhttp.send(formData);
}

// function getRmpQTemplateData(){
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function(){
//         var response = JSON.parse(xhttp.response);
//         RmpQTemplateData = response.RmpQTemplateData;
//          loopRmpQTemplateData(RmpQTemplateData);
//     }
//     xhttp.open('GET', serverUrl+'?function=get-RmpQTemplateData', true);
//     xhttp.send();
// }

// function loopRmpQTemplateData(data){
//     var container = document.getElementById('RmpQTbody');
//     var tr = "";
//     var counter = 0;
//     if(data && data.length > 0){
//         for(var i=0; i < data.length; i++){
//         counter++;
//         tr += `
//             <tr>
//                                 <td>${counter}</td>
//                                 <td>${data[i].projectTitle}</td>
//                                 <td>${data[i].datte}</td>
//                                 <td>${data[i].fileNo}</td>
//                                 <td>${data[i].BidOppNo}</td>
//                                 <td>${data[i].stakeholder}</td>
                               
//                                 <td >
//                                     <div>
//                                         <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
//                                              <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
//                                 <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
//                                 </svg>
//                             </button>
                    
//                                         <div id='${i}' class="options-dropdown" style="right: 5px;">
//                                             <button onclick="editRmpQTemplateData(${data[i].id})" class="openModalBtnEdit option-button" >
//                                 <img src="../assetsPeter/leadedit.png"/> Edit
//                             </button>
//                                             <button onclick="viewRmpQTemplateData(${data[i].id})" class="openModalBtnView option-button">
//                                 <img src="../assetsPeter/leadview.png" />
//                                 View
//                             </button>
//                                             <button onclick="deleteRmpQTemplateData(${data[i].id})" class="option-button">
//                                 <img src="../assetsPeter/leaddelete.png" />
//                                 Delete
//                             </button>
                                            
//                                         </div>
//                                     </div>
                               
//                                 </td>
//                             </tr> 
//         `;
//         if(container){
//             container.innerHTML = tr;
//         }
//     }
//     }else{
//         if(container){
//             container.innerHTML = "No data yet!";
//         }
//     }
    
// }
// getRmpQTemplateData();

// function editRmpQTemplateData(RmpQTemplateDataId) {
//     var data = RmpQTemplateData.find((RmpQTemplate)=>{
//         return RmpQTemplate.id == RmpQTemplateDataId
//     });


//      // Populate the modal with the data received from the backend
//      var modals = document.getElementById('modals');
//      var modalContent = `
//      <style>
//          .select-input{
//              display: flex;
//              width: 88%;
//              height: 24px;
//              padding: 7px 17px;
//              align-items: flex-start;
//              gap: 10px;
//              flex-shrink: 0;
//              border-radius: 8px;
//              border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//              background: var(--Foundation-White-W300, #F6F6F6);
//          }
//      </style>
//      <div id="myModal" class="modal-container">
//          <div class="modal-content">
//              <span onclick="closeModal()" class="close">&times;</span>
//              <div class="add-text">
//                  <h3>Add</h3>
//              </div>
 
//              <form id="form" class="addStakeholder">
     
//                  <div class="longer-form">
//                      <label for="docRevisionNo">Document Revision No</label>
//                      <input type="text" id="docRevisionNo" name="docRevisionNo" required value="${data.datte}"  />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="changeInContent">Change in content</label>
//                      <input type="text" id="changeInContent" name="changeInContent" required value="${data.datte}" />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="dateReleased">Date Released</label>
//                      <input type="text" id="dateReleased" name="dateReleased" required value="${data.datte}"  />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="releasedBy">Released By</label>
//                      <input type="text" id="releasedBy" name="releasedBy" required value="${data.datte}"  />
//                  </div>
 
//                  <hr style="margin:50px 0" />
 
//                  <div class="longer-form" style="text-align:center">
//                      <label for="templateQualityInfo">Template Quality Information</label><br>
//                      <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="documentRevisionNo">Document Revision No</label>
//                      <input type="text" id="documentRevisionNo" name="documentRevisionNo" required value="${data.datte}"  />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="revisions">Revisions</label>
//                      <input type="text" id="revisions" name="revisions" required  value="${data.datte}" />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="releasedDate">Date Released</label>
//                      <input type="text" id="releasedDate" name="releasedDate" required  value="${data.datte}" />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="releasedByFinal">Released By</label>
//                      <input type="text" id="releasedByFinal" name="releasedByFinal" required value="${data.datte}"  />
//                  </div>
 
//                  <button type='button' class="edit-button" onclick="saveScQualityData()" id="save-btn">Save</button>  
//              </form>
//          </div>
//      </div>
//      `;
//      if (modals) {
//          modals.innerHTML = modalContent;
//          openModal();
//      }


// }
// function viewRmpQTemplateData(RmpQTemplateDataId) {
//     var data = RmpQTemplateData.find((RmpQTemplate)=>{
//         return RmpQTemplate.id == RmpQTemplateDataId
//     });


//      // Populate the modal with the data received from the backend
//      var modals = document.getElementById('modals');
//      var modalContent = `
//     <style>
//         .select-input{
//             display: flex;
//             width: 88%;
//             height: 24px;
//             padding: 7px 17px;
//             align-items: flex-start;
//             gap: 10px;
//             flex-shrink: 0;
//             border-radius: 8px;
//             border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//             background: var(--Foundation-White-W300, #F6F6F6);
//         }
//     </style>
//     <div id="myModal" class="modal-container">
//         <div class="modal-content">
//             <span onclick="closeModal()" class="close">&times;</span>
//             <div class="add-text">
//                 <h3>Add</h3>
//             </div>

//             <form id="form" class="addStakeholder">
    
//                 <div class="longer-form">
//                     <label for="docRevisionNo">Document Revision No</label>
//                     <input type="text" id="docRevisionNo" name="docRevisionNo" required value="${data.datte}" readonly />
//                 </div>
    
//                 <div class="longer-form">
//                     <label for="changeInContent">Change in content</label>
//                     <input type="text" id="changeInContent" name="changeInContent" required value="${data.datte}" readonly />
//                 </div>

//                 <div class="longer-form">
//                     <label for="dateReleased">Date Released</label>
//                     <input type="text" id="dateReleased" name="dateReleased" required value="${data.datte}" readonly />
//                 </div>
    
//                 <div class="longer-form">
//                     <label for="releasedBy">Released By</label>
//                     <input type="text" id="releasedBy" name="releasedBy" required value="${data.datte}" readonly />
//                 </div>

//                 <hr style="margin:50px 0" />

//                 <div class="longer-form" style="text-align:center">
//                     <label for="templateQualityInfo">Template Quality Information</label><br>
//                     <label for="templateQualityInfo">(This section is used to track changes to the template design)</label>
//                 </div>

//                 <div class="longer-form">
//                     <label for="documentRevisionNo">Document Revision No</label>
//                     <input type="text" id="documentRevisionNo" name="documentRevisionNo" required value="${data.datte}" readonly />
//                 </div>

//                 <div class="longer-form">
//                     <label for="revisions">Revisions</label>
//                     <input type="text" id="revisions" name="revisions" required  value="${data.datte}" readonly />
//                 </div>

//                 <div class="longer-form">
//                     <label for="releasedDate">Date Released</label>
//                     <input type="text" id="releasedDate" name="releasedDate" required  value="${data.datte}" readonly />
//                 </div>
    
//                 <div class="longer-form">
//                     <label for="releasedByFinal">Released By</label>
//                     <input type="text" id="releasedByFinal" name="releasedByFinal" required value="${data.datte}" readonly />
//                 </div>

//                 <button type='button' class="edit-button" onclick="saveScQualityData()" id="save-btn">Save</button>  
//             </form>
//         </div>
//     </div>
// `;

//      if (modals) {
//          modals.innerHTML = modalContent;
//          openModal();
//      }


// }

// function deleteRmpQTemplateData(RmpQTemplateDataId){
//     swal({
//         title: "Are you sure?",
//         text: "This will be deleted permanently.",
//         type: "warning",
//         showCancelButton: true,
//         showConfirmButton: true,
//         confirmButtonColor: "#DD6B55",
//         confirmButtonText: "Delete",
//         cancelButtonText: "Cancel",
//         closeOnConfirm: true,
//         closeOnCancel: true
//       },
//       function(isConfirm){
//         if (isConfirm) {
//             var formData = new FormData();
//             formData.append('RmpQTemplateDataId', RmpQTemplateDataId);
//             var xhttp = new XMLHttpRequest();
//             xhttp.onload = function(){
//                 var response = JSON.parse(xhttp.response);
//                 if(response.success){
//                     getRmpQTemplateData();
//                     swal('Hurray', response.success, 'success');
//                 }
//                 else{
//                     swal('Sorry', response.error, 'error');
                    
//                 }
//             }
//             xhttp.onerror = function(error){
//                 swal('Sorry', "An error occured, try again!", 'error');
//             }
//             xhttp.open('POST', serverUrl+'?function=delete-RmpQTemplateData', true);
//             xhttp.send(formData);
//         }
//       });
// }



////Engineering corresponding(sirlaw)
var  EngnrData =[];

// function addEngnrData(){
//     var modals = document.getElementById('modals');
//     var modalContent = `

//     <style>
            
        
//                 .select-input{
//                     display: flex;
//                     width: 88%;
//                     height: 24px;
//                     padding: 7px 17px;
//                     align-items: flex-start;
//                     gap: 10px;
//                     flex-shrink: 0;
//                     border-radius: 8px;
//                     border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//                     background: var(--Foundation-White-W300, #F6F6F6);
//                 }

//                 .dashboard-rightbar, body{
//             background-color: #fff;
//             /* font-family: Archivo; */
//         }
//         .sign_btn{
//                 padding: 10px;
//                 gap: 10px;
//                 flex-shrink: 0;
//                 border-radius: 10px;
//                 background: #6F6DEB;
//                 color: #FFF;
//                 text-align: center;
//                 font-family: Archivo;
//                 font-size: 18px;
//                 font-style: normal;
//                 font-weight: 600;
//                 line-height: 120%;
//                 border: 0;
//             }

//             .address_row{
//                 display: flex;
//                 justify-content: space-between;
//                 align-items: center;
//             }

//             .addres > a{
//                 text-decoration: none;
//                 color:black;
//             }
//             *,::after,::after{
//                 margin: 0;
//                 padding: 0;
//                 box-sizing: border-box;
//             }
//     </style>

//         <div id="myModal" class="modal-container">
//             <div class="modal-content">
//                 <span onclick="closeModal()" class="close">&times;</span>
//                 <div class="add-text">
//                     <h3>Add New </h3>
//                 </div>

                
//                     <img src="http://test.osheacrm.com/assetsPeter/engr_form_head.png" alt=""  width="100%" height="100%">
                
               
//                     <div style="padding: 30px 0;" class="addres">
//                         <div class="address_row">
//                             <span><h4>Acme Corporation</h4></span>
//                             <span><h4>P.O.BOX 3380</h4></span>
//                         </div>
//                         <div class="address_row">
//                             <span><h4>Mende - Maryland,</h4></span>
//                             <span><h4>Yaba, Lagos</h4></span>
//                         </div>
                    
//                         <div>

//                         <h4>Lagos, Nigeria.</h4>
//                             <h4>456 Corporate Blvd, Suite 100</h4>
//                             <h4>San Francisco, CA 94105</h4>
//                            <a href="tel:+234-1-7742609" style="color:black">Tel: 234-1-7742609, 08096004705, 08023134810</a><br>
//                            <a href="mailto:info@osheaprojects.com" style="color:black">Email: info@osheaprojects.com; osheaprojects@yahoo.com</a><br>
//                            <a href="www.osheaprojects.com" style="color:black">Website: www.osheaprojects.com</a>

//                         </div>
                         
                    
//                     </div>


//                 <form id="form">
                       
//                         <h3 style="text-align:center; margin:20px 0">ENGINEERING'S CORRESPONDENCE</h3>
                    
//                         <div class="longer-form">
//                             <label for="From">From</label>
//                             <input type="text" id="From" required/>
//                         </div>
//                         <div class="longer-form">
//                             <label for="To">To</label>
//                             <input type="text" id="To" required/>
//                         </div>
    
//                         <div class="longer-form">
//                             <label for="Subject">Subject</label>
//                             <input type="text" id="Subject" required/>
//                         </div>
    
                       
//                         <div class="longer-form">
//                             <label for="Job_NO">Job NO</label>
//                             <input type="text" id="Job_NO" required/>
//                         </div>
    
//                         <div class="longer-form">
//                             <label for="Memo_NO">Memo NO</label>
//                             <input type="text" id="Memo_NO" required/>
//                         </div>
    
                       
//                         <div class="longer-form">
//                             <label for="Date">Date</label>
//                             <input type="text" id="Date" required/>
//                         </div>
    
                       
    
//                         <div class="longer-form">
//                             <label for="Cost to manage risk">Notes</label>
//                            <textarea rows="10" cols="50" id="Notes" required style="height: 177px! important;"></textarea>
//                         </div>
                    
//                         <div class="" style="display: flex; justify-content: space-between;align-items: center;margin: 40px 0;">
//                             <label for="">Signature.................</label>
    
//                             <button type='button' class="sign_btn" id="">+ Add Signature</button> 
    
//                         </div>
                    
                    
//                        <button type='button' class="edit-button" onclick="saveEngnrData()" id="save-btn">Save</button>
//                     </form> 
//             </div>
//         </div>
      
    
    
//     `;
//     if(modals){
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }

// function saveEngnrData(){
//     var savebtn = document.getElementById('save-btn');
//     savebtn.innerHTML = 'Saving...';
//     savebtn.disabled = true;

//     var From = document.getElementById('From').value;
//     var To = document.getElementById('To').value;
//     var Subject = document.getElementById('Subject').value;

//     var Job_NO = document.getElementById('Job_NO').value;
//     var Memo_NO = document.getElementById('Memo_NO').value;
//     var Date = document.getElementById('Date').value;
//     var Notes = document.getElementById('Notes').value;


    
//     var formData = new FormData();
//     formData.append('From', From);
//     formData.append('To', To);
//     formData.append('Subject', Subject);
//     formData.append('Job_NO', Job_NO);
//     formData.append('Memo_NO', Memo_NO);
//     formData.append('Date', Date);
//     formData.append('Notes', Notes);
   
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function(){
//         var response = JSON.parse(xhttp.response);
//         for(var modal of modals){
//             modal.style.display = 'none';
//         }
//         for(var form of forms){
//             form.reset();
//         }
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         swal('Success', "Record saved!", 'success');
//         getEngnrData();
//     }
//     xhttp.onerror = function(){
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         swal('Sorry', "An error occured, try again!", 'error');
//     }
//     xhttp.open('POST', serverUrl+'?function=save-EngrData', true);
//     xhttp.send(formData);
// }

// function getEngnrData(){
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function(){
//         var response = JSON.parse(xhttp.response);
//         EngnrData = response.EngnrData;
//         loopEngnrData(EngnrData);
//     }
//     xhttp.open('GET', serverUrl+'?function=get-EngnrData', true);
//     xhttp.send();
// }

// function loopEngnrData(data){
//     var container = document.getElementById('EngnrTbody');
//     var tr = "";
//     var counter = 0;
//     if(data && data.length > 0){
//         for(var i=0; i < data.length; i++){
//         counter++;
//         tr += `
//     <tr>
//                     <td>${counter}</td>
//                     <td>${data[i].Fromm}</td>
//                     <td>${data[i].Too}</td>
//                     <td>${data[i].Subjectt}</td>
//                     <td>${data[i].Job_NO}</td>
//                     <td>${data[i].Memo_NO}</td>
//                     <td>${data[i].Datee}</td>

//                     <td class="threedots">
//                                     <div>
//                                         <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
//                                             <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
//                             <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
//                             </svg>
//                                         </button>
                    
//                                         <div id='${i}' class="options-dropdown" style="right: 5px;">
//                                             <button onclick="editEngnrData(${data[i].id})" class="openModalBtnEdit option-button" >
//                                 <img src="../assetsPeter/leadedit.png"/> Edit
//                             </button>
//                                             <button onclick="viewEngnrData(${data[i].id})" class="openModalBtnView option-button">
//                                 <img src="../assetsPeter/leadview.png" />
//                                 View
//                             </button>

//                                             <button onclick="deleteEngnrDataId(${data[i].id})" class="option-button">
//                                 <img src="../assetsPeter/leaddelete.png" />
//                                 Delete
//                             </button>
                                            
//                                         </div>
//                                     </div>
                            
//                         </td>
//                     </tr> 
//         `;
//         if(container){
//             container.innerHTML = tr;
//         }
//     }
//     }else{
//         if(container){
//             container.innerHTML = "No data yet!";
//         }
//     }
    
// }
// getEngnrData();

// function editEngnrData(EngnrDataId) {
//     var data = EngnrData.find((EngnrDatum)=>{
//      return EngnrDatum.id = EngnrDataId;
//     })
//     var modals = document.getElementById('modals');
//     var modalContent = `
 
//      <style>
            
        
//                 .select-input{
//                     display: flex;
//                     width: 88%;
//                     height: 24px;
//                     padding: 7px 17px;
//                     align-items: flex-start;
//                     gap: 10px;
//                     flex-shrink: 0;
//                     border-radius: 8px;
//                     border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//                     background: var(--Foundation-White-W300, #F6F6F6);
//                 }

//                 .dashboard-rightbar, body{
//             background-color: #fff;
//             /* font-family: Archivo; */
//         }
//         .sign_btn{
//                 padding: 10px;
//                 gap: 10px;
//                 flex-shrink: 0;
//                 border-radius: 10px;
//                 background: #6F6DEB;
//                 color: #FFF;
//                 text-align: center;
//                 font-family: Archivo;
//                 font-size: 18px;
//                 font-style: normal;
//                 font-weight: 600;
//                 line-height: 120%;
//                 border: 0;
//             }

//             .address_row{
//                 display: flex;
//                 justify-content: space-between;
//                 align-items: center;
//             }

//             .addres > a{
//                 text-decoration: none;
//                 color:black;
//             }
//             *,::after,::after{
//                 margin: 0;
//                 padding: 0;
//                 box-sizing: border-box;
//             }
//     </style>

//         <div id="myModal" class="modal-container">
//             <div class="modal-content">
//                 <span onclick="closeModal()" class="close">&times;</span>
//                 <div class="add-text">
//                     <h3>Edit </h3>
//                 </div>

                
//                     <img src="http://test.osheacrm.com/assetsPeter/engr_form_head.png" alt=""  width="100%" height="100%">
                
               
//                     <div style="padding: 30px 0;" class="addres">
//                         <div class="address_row">
//                             <span><h4>Acme Corporation</h4></span>
//                             <span><h4>P.O.BOX 3380</h4></span>
//                         </div>
//                         <div class="address_row">
//                             <span><h4>Mende - Maryland,</h4></span>
//                             <span><h4>Yaba, Lagos</h4></span>
//                         </div>
                    
//                         <div>

//                         <h4>Lagos, Nigeria.</h4>
//                             <h4>456 Corporate Blvd, Suite 100</h4>
//                             <h4>San Francisco, CA 94105</h4>
//                            <a href="tel:+234-1-7742609" style="color:black">Tel: 234-1-7742609, 08096004705, 08023134810</a><br>
//                            <a href="mailto:info@osheaprojects.com" style="color:black">Email: info@osheaprojects.com; osheaprojects@yahoo.com</a><br>
//                            <a href="www.osheaprojects.com" style="color:black">Website: www.osheaprojects.com</a>

//                         </div>
                         
                    
//                     </div>


//                 <form id="form">
                       
//                         <h3 style="text-align:center; margin:20px 0">ENGINEERING'S CORRESPONDENCE</h3>
                    
//                         <div class="longer-form">
//                             <label for="From">From</label>
//                             <input type="text" id="From" required value="${data.Fromm}"/>
//                         </div>
//                         <div class="longer-form">
//                             <label for="To">To</label>
//                             <input type="text" id="To" required value="${data.Too}"/>
//                         </div>
    
//                         <div class="longer-form">
//                             <label for="Subject">Subject</label>
//                             <input type="text" id="Subject" required value="${data.Subjectt}"/>
//                         </div>
    
                       
//                         <div class="longer-form">
//                             <label for="Job_NO">Job NO</label>
//                             <input type="text" id="Job_NO" required value="${data.Job_NO}" />
//                         </div>
    
//                         <div class="longer-form">
//                             <label for="Memo_NO">Memo NO</label>
//                             <input type="text" id="Memo_NO" required  value="${data.Memo_NO}"/>
//                         </div>
    
                       
//                         <div class="longer-form">
//                             <label for="Date">Date</label>
//                             <input type="text" id="Date" required value="${data.Datee}" />
//                         </div>
    
                       
    
//                         <div class="longer-form">
//                             <label for="">Notes</label>
//                            <textarea rows="10" cols="50" id="Notes" required style="height: 177px! important;"></textarea>
//                         </div>
                    
//                         <div class="" style="display: flex; justify-content: space-between;align-items: center;margin: 40px 0;">
//                             <label for="">Signature.................</label>
    
//                             <button type='button' class="sign_btn" id="">+ Add Signature</button> 
    
//                             <button type='button' class="sign_btn" onclick="" id="" style="background: #6F6DEB;color:white">Change Signature</button> 
//                         </div>
                    
                    
//                        <button type='button' class="edit-button" onclick="saveEngnrData()" id="save-btn">Update</button>
//                     </form> 
//             </div>
//         </div>
      
    
//     `;
//     if (modals) {
//         modals.innerHTML = modalContent;
//         openModal();
//     }
 
//  }

// function viewEngnrData(EngnrDataId) {
//     var data = EngnrData.find((EngnrDatum)=>{
//      return EngnrDatum.id = EngnrDataId;
//     })
//     var modals = document.getElementById('modals');
//     var modalContent = `
 
//      <style>
            
        
//                 .select-input{
//                     display: flex;
//                     width: 88%;
//                     height: 24px;
//                     padding: 7px 17px;
//                     align-items: flex-start;
//                     gap: 10px;
//                     flex-shrink: 0;
//                     border-radius: 8px;
//                     border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//                     background: var(--Foundation-White-W300, #F6F6F6);
//                 }

//                 .dashboard-rightbar, body{
//             background-color: #fff;
//             /* font-family: Archivo; */
//         }
//         .sign_btn{
//                 padding: 10px;
//                 gap: 10px;
//                 flex-shrink: 0;
//                 border-radius: 10px;
//                 background: #6F6DEB;
//                 color: #FFF;
//                 text-align: center;
//                 font-family: Archivo;
//                 font-size: 18px;
//                 font-style: normal;
//                 font-weight: 600;
//                 line-height: 120%;
//                 border: 0;
//             }

//             .address_row{
//                 display: flex;
//                 justify-content: space-between;
//                 align-items: center;
//             }

//             .addres > a{
//                 text-decoration: none;
//                 color:black;
//             }
//             *,::after,::after{
//                 margin: 0;
//                 padding: 0;
//                 box-sizing: border-box;
//             }
//     </style>

//         <div id="myModal" class="modal-container">
//             <div class="modal-content">
//                 <span onclick="closeModal()" class="close">&times;</span>
//                 <div class="add-text">
//                     <h3>View </h3>
//                 </div>

                
//                     <img src="http://test.osheacrm.com/assetsPeter/engr_form_head.png" alt=""  width="100%" height="100%">
                
               
//                     <div style="padding: 30px 0;" class="addres">
//                         <div class="address_row">
//                             <span><h4>Acme Corporation</h4></span>
//                             <span><h4>P.O.BOX 3380</h4></span>
//                         </div>
//                         <div class="address_row">
//                             <span><h4>Mende - Maryland,</h4></span>
//                             <span><h4>Yaba, Lagos</h4></span>
//                         </div>
                    
//                         <div>

//                         <h4>Lagos, Nigeria.</h4>
//                             <h4>456 Corporate Blvd, Suite 100</h4>
//                             <h4>San Francisco, CA 94105</h4>
//                            <a href="tel:+234-1-7742609" style="color:black">Tel: 234-1-7742609, 08096004705, 08023134810</a><br>
//                            <a href="mailto:info@osheaprojects.com" style="color:black">Email: info@osheaprojects.com; osheaprojects@yahoo.com</a><br>
//                            <a href="www.osheaprojects.com" style="color:black">Website: www.osheaprojects.com</a>

//                         </div>
                         
                    
//                     </div>

//     <form id="form">

//         <h3 style="text-align:center; margin:20px 0">ENGINEERING'S CORRESPONDENCE</h3>

//         <div class="longer-form">
//             <label for="From">From</label>
//             <input type="text" id="From" value="${data.Fromm}" readonly />
//         </div>
        
//         <div class="longer-form">
//             <label for="To">To</label>
//             <input type="text" id="To" value="${data.Too}" readonly />
//         </div>

//         <div class="longer-form">
//             <label for="Subject">Subject</label>
//             <input type="text" id="Subject" value="${data.Subjectt}" readonly />
//         </div>

//         <div class="longer-form">
//             <label for="Job_NO">Job NO</label>
//             <input type="text" id="Job_NO" value="${data.Job_NO}" readonly />
//         </div>

//         <div class="longer-form">
//             <label for="Memo_NO">Memo NO</label>
//             <input type="text" id="Memo_NO" value="${data.Memo_NO}" readonly />
//         </div>

//         <div class="longer-form">
//             <label for="Date">Date</label>
//             <input type="text" id="Date" value="${data.Datee}" readonly />
//         </div>

//         <div class="longer-form">
//             <label for="Notes">Notes</label>
//             <textarea rows="10" cols="50" id="Notes" style="height: 177px!important;" readonly>${data.Notes}</textarea>
//         </div>

//         <div style="display: flex; justify-content: space-between; align-items: center; margin: 40px 0;">
//             <label for="">Signature.................</label>

//             <button type="button" class="sign_btn" id="">+ Add Signature</button>
//             <button type="button" class="sign_btn" id="" style="background: #6F6DEB; color:white">Change Signature</button>
//         </div>

//         <button type="button" class="edit-button" onclick="saveEngnrData()" id="save-btn">Update</button>
//     </form>

               
//             </div>
//         </div>
      
    
//     `;
//     if (modals) {
//         modals.innerHTML = modalContent;
//         openModal();
//     }
 
//  }

//  function deleteEngnrDataId(EngnrDataId){
//     swal({
//         title: "Are you sure?",
//         text: "This will be deleted permanently.",
//         type: "warning",
//         showCancelButton: true,
//         showConfirmButton: true,
//         confirmButtonColor: "#DD6B55",
//         confirmButtonText: "Delete",
//         cancelButtonText: "Cancel",
//         closeOnConfirm: true,
//         closeOnCancel: true
//       },
//       function(isConfirm){
//         if (isConfirm) {
//             var formData = new FormData();
//             formData.append('EngnrDataId', EngnrDataId);
//             var xhttp = new XMLHttpRequest();
//             xhttp.onload = function(){
//                 var response = JSON.parse(xhttp.response);
//                 if(response.success){
//                     getEngnrData();
//                     swal('Hurray', response.success, 'success');
//                 }
//                 else{
//                     swal('Sorry', response.error, 'error');
                    
//                 }
//             }
//             xhttp.onerror = function(error){
//                 swal('Sorry', "An error occured, try again!", 'error');
//             }
//             xhttp.open('POST', serverUrl+'?function=delete-EngnrData', true);
//             xhttp.send(formData);
//         }
//       });
// }



// not connected
////field info


var FieldInfoData =[];

// function addFieldInfoData() {
//     var modals = document.getElementById('modals');
//     var modalContent = `
//     <style>
//         .select-input{
//             display: flex;
//             width: 88%;
//             height: 24px;
//             padding: 7px 17px;
//             align-items: flex-start;
//             gap: 10px;
//             flex-shrink: 0;
//             border-radius: 8px;
//             border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//             background: var(--Foundation-White-W300, #F6F6F6);
//         }
//     </style>
//     <div id="myModal" class="modal-container">
//         <div class="modal-content">
//             <span onclick="closeModal()" class="close">&times;</span>
//             <div class="add-text">
//                 <h3>Add</h3>
//             </div>

//             <form id="addStakeholderForm" class="addStakeholder">
//                 <h4>TO</h4>    
                
//                 <div class="longer-form">
//                     <label for="documentDate">Date</label>
//                     <input type="text" id="documentDate" name="documentDate" required />
//                 </div>
    
//                 <div class="longer-form">
//                     <label for="fileNo">File No</label>
//                     <input type="text" id="fileNo" name="fileNo" required />
//                 </div>

//                 <div class="longer-form">
//                     <label for="bidOppNo">Bid Opp No.</label>
//                     <input type="text" id="bidOppNo" name="bidOppNo" required />
//                 </div>
    
//                 <div class="longer-form">
//                     <label for="priNo">PRI No</label>
//                     <input type="text" id="priNo" name="priNo" required />
//                 </div>

//                 <hr style="margin:50px 0" />
//                 <h4>PROJECT</h4>

//                 <div class="longer-form">
//                     <label for="distribution">Distribution</label>
//                     <select name="distribution" id="distribution" class="select-input">
//                         <option value="Owner">Owner</option>
//                         <option value="Contractor">Contractor</option>
//                         <option value="CA">CA</option>
//                         <option value="Other">Other</option>
//                     </select>
//                 </div>

//                 <div class="longer-form">
//                     <label for="issuedBy">Issued By</label>
//                     <input type="text" id="issuedBy" name="issuedBy" required />
//                 </div>

//                 <div class="longer-form">
//                     <label for="reason">Reason</label>
//                     <input type="text" id="reason" name="reason" required />
//                 </div>

//                 <button type="button" class="edit-button" onclick="saveRmpQTemplateData()" id="save-btn">Save</button>  
//             </form>
//         </div>
//     </div>
// `;

//     if (modals) {
//         modals.innerHTML = modalContent;
//         openModal();
//     }
// }

// function saveFieldInfoData(){
//     var savebtn = document.getElementById('save-btn');
//     savebtn.innerHTML = 'Saving...';
//     savebtn.disabled = true;

//     const documentDate = document.getElementById('documentDate').value;
//     const fileNo = document.getElementById('fileNo').value;
//     const bidOppNo = document.getElementById('bidOppNo').value;
//     const priNo = document.getElementById('priNo').value;
//     const distribution = document.getElementById('distribution').value;
//     const issuedBy = document.getElementById('issuedBy').value;
//     const reason = document.getElementById('reason').value;

    

//     var formData = new FormData();

//     formData.append('documentDate', documentDate);
//     formData.append('fileNo', fileNo);
//     formData.append('bidOppNo', bidOppNo);
//     formData.append('priNo', priNo);
//     formData.append('distribution', distribution);
//     formData.append('issuedBy', issuedBy);
//     formData.append('reason', reason);

//     console.log("formdata", formData)
//     var xhttp = new XMLHttpRequest();
   

//     xhttp.onload = function() {
//         if (xhttp.status === 200) {
//             var response = JSON.parse(xhttp.response);
//             for(var modal of modals){
//                 modal.style.display = 'none';
//             }
//             for(var form of forms){
//                 form.reset();
//             }
//             savebtn.disabled = false;
//             savebtn.innerHTML = "Save";
//             swal('Success', "Record saved!", 'success');
//             getStakeholderComPlan();
//         }
//     };

//     xhttp.onerror = function() {
//         savebtn.disabled = false;
//         savebtn.innerHTML = "Save";
//         swal('Sorry', "An error occurred, try again!", 'error');
//     };

//     xhttp.open('POST', serverUrl+'?function=save-FieldInfoData', true);
//     console.log("formData", formData)
//     xhttp.send(formData);
// }

// function getFieldInfoData(){
//     var xhttp = new XMLHttpRequest();
//     xhttp.onload = function(){
//         var response = JSON.parse(xhttp.response);
//         FieldInfoData = response.FieldInfoData;
//          loopFieldInfoData(FieldInfoData);
//     }
//     xhttp.open('GET', serverUrl+'?function=get-FieldInfoData', true);
//     xhttp.send();
// }

// function loopFieldInfoData(data){
//     var container = document.getElementById('RmpQTbody');
//     var tr = "";
//     var counter = 0;
//     if(data && data.length > 0){
//         for(var i=0; i < data.length; i++){
//         counter++;
//         tr += `
//             <tr>
//                                 <td>${counter}</td>
//                                 <td>${data[i].projectTitle}</td>
//                                 <td>${data[i].datte}</td>
//                                 <td>${data[i].fileNo}</td>
//                                 <td>${data[i].BidOppNo}</td>
//                                 <td>${data[i].stakeholder}</td>
                               
//                                 <td >
//                                     <div>
//                                         <button onclick="showOptions(${i})"  class="three" style="cursor: pointer;">
//                                              <svg  xmlns="http://www.w3.org/2000/svg" width="25" height="24" viewBox="0 0 25 24" fill="none">
//                                 <path d="M11.2983 4.69185C10.9514 5.03879 10.7564 5.50935 10.7564 6C10.7564 6.49065 10.9514 6.96121 11.2983 7.30815C11.6452 7.65509 12.1158 7.85 12.6064 7.85C13.0971 7.85 13.5677 7.65509 13.9146 7.30815C14.2615 6.96121 14.4564 6.49065 14.4564 6C14.4564 5.50935 14.2615 5.03879 13.9146 4.69185C13.5677 4.34491 13.0971 4.15 12.6064 4.15C12.1158 4.15 11.6452 4.34491 11.2983 4.69185ZM11.2983 10.6919C10.9514 11.0388 10.7564 11.5093 10.7564 12C10.7564 12.4907 10.9514 12.9612 11.2983 13.3081C11.6452 13.6551 12.1158 13.85 12.6064 13.85C13.0971 13.85 13.5677 13.6551 13.9146 13.3081C14.2615 12.9612 14.4564 12.4907 14.4564 12C14.4564 11.5093 14.2615 11.0388 13.9146 10.6919C13.5677 10.3449 13.0971 10.15 12.6064 10.15C12.1158 10.15 11.6452 10.3449 11.2983 10.6919ZM11.2983 16.6919C10.9514 17.0388 10.7564 17.5093 10.7564 18C10.7564 18.4907 10.9514 18.9612 11.2983 19.3081C11.6452 19.6551 12.1158 19.85 12.6064 19.85C13.0971 19.85 13.5677 19.6551 13.9146 19.3081C14.2615 18.9612 14.4564 18.4907 14.4564 18C14.4564 17.5093 14.2615 17.0388 13.9146 16.6919C13.5677 16.3449 13.0971 16.15 12.6064 16.15C12.1158 16.15 11.6452 16.3449 11.2983 16.6919Z" fill="#091E42" stroke="#091E42" stroke-width="0.7"/>
//                                 </svg>
//                             </button>
                    
//                                         <div id='${i}' class="options-dropdown" style="right: 5px;">
//                                             <button onclick="editFieldInfoData(${data[i].id})" class="openModalBtnEdit option-button" >
//                                 <img src="../assetsPeter/leadedit.png"/> Edit
//                             </button>
//                                             <button onclick="viewFieldInfoData(${data[i].id})" class="openModalBtnView option-button">
//                                 <img src="../assetsPeter/leadview.png" />
//                                 View
//                             </button>
//                                             <button onclick="deleteFieldInfoData(${data[i].id})" class="option-button">
//                                 <img src="../assetsPeter/leaddelete.png" />
//                                 Delete
//                             </button>
                                            
//                                         </div>
//                                     </div>
                               
//                                 </td>
//                             </tr> 
//         `;
//         if(container){
//             container.innerHTML = tr;
//         }
//     }
//     }else{
//         if(container){
//             container.innerHTML = "No data yet!";
//         }
//     }
    
// }
// getFieldInfoData();

// function editFieldInfoData(FieldInfoDataId) {
//     var data = FieldInfoData.find((FieldInfo)=>{
//         return FieldInfo.id == FieldInfoDataId
//     });
//      // Populate the modal with the data received from the backend
//      var modals = document.getElementById('modals');
//      var modalContent = `
//      <style>
//          .select-input{
//              display: flex;
//              width: 88%;
//              height: 24px;
//              padding: 7px 17px;
//              align-items: flex-start;
//              gap: 10px;
//              flex-shrink: 0;
//              border-radius: 8px;
//              border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//              background: var(--Foundation-White-W300, #F6F6F6);
//          }
//      </style>
//      <div id="myModal" class="modal-container">
//          <div class="modal-content">
//              <span onclick="closeModal()" class="close">&times;</span>
//              <div class="add-text">
//                  <h3>Add</h3>
//              </div>
 
//              <form id="addStakeholderForm" class="addStakeholder">
//                  <h4>TO</h4>    
                 
//                  <div class="longer-form">
//                      <label for="documentDate">Date</label>
//                      <input type="text" id="documentDate" name="documentDate" required value="${data.description}"/>
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="fileNo">File No</label>
//                      <input type="text" id="fileNo" name="fileNo" required value="${data.description}" />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="bidOppNo">Bid Opp No.</label>
//                      <input type="text" id="bidOppNo" name="bidOppNo" required value="${data.description}" />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="priNo">PRI No</label>
//                      <input type="text" id="priNo" name="priNo" required value="${data.description}" />
//                  </div>
 
//                  <hr style="margin:50px 0" />
//                  <h4>PROJECT</h4>

                 


//                  <div class="longer-form">
//                      <label for="distribution">Distribution</label>
//                      <select name="distribution" id="distribution" class="select-input">
//                          <option value="Owner" ${data.distribution === 'Owner' ? 'selected' : ''}>Owner</option>
//                          <option value="Contractor" ${data.distribution === 'Contractor' ? 'selected' : ''}>Contractor</option>
//                          <option value="CA" ${data.distribution === 'CA' ? 'selected' : ''}>CA</option>
//                          <option value="Other" ${data.distribution === 'Other' ? 'selected' : ''}>Other</option>
//                      </select>
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="issuedBy">Issued By</label>
//                      <input type="text" id="issuedBy" name="issuedBy" required value="${data.description}"/>
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="reason">Reason</label>
//                      <input type="text" id="reason" name="reason" required value="${data.description}" />
//                  </div>
 
//                  <button type="button" class="edit-button" onclick="saveRmpQTemplateData()" id="save-btn">Update</button>  
//              </form>
//          </div>
//      </div>
//  `;
//      if (modals) {
//          modals.innerHTML = modalContent;
//          openModal();
//      }


// }
// function viewFieldInfoData(FieldInfoDataId) {
//     var data = FieldInfoData.find((FieldInfo)=>{
//         return FieldInfo.id == FieldInfoDataId
//     });


//      // Populate the modal with the data received from the backend
//      var modals = document.getElementById('modals');
//      var modalContent = `
//      <style>
//          .select-input {
//              display: flex;
//              width: 88%;
//              height: 24px;
//              padding: 7px 17px;
//              align-items: flex-start;
//              gap: 10px;
//              flex-shrink: 0;
//              border-radius: 8px;
//              border: 1px solid var(--Foundation-Primary-P400, #0047B3);
//              background: var(--Foundation-White-W300, #F6F6F6);
//          }
//      </style>
//      <div id="myModal" class="modal-container">
//          <div class="modal-content">
//              <span onclick="closeModal()" class="close">&times;</span>
//              <div class="add-text">
//                  <h3>Add</h3>
//              </div>
 
//              <form id="addStakeholderForm" class="addStakeholder">
//                  <h4>TO</h4>    
                 
//                  <div class="longer-form">
//                      <label for="documentDate">Date</label>
//                      <input type="text" id="documentDate" name="documentDate" required value="${data.description}" readonly />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="fileNo">File No</label>
//                      <input type="text" id="fileNo" name="fileNo" required value="${data.description}" readonly />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="bidOppNo">Bid Opp No.</label>
//                      <input type="text" id="bidOppNo" name="bidOppNo" required value="${data.description}" readonly />
//                  </div>
     
//                  <div class="longer-form">
//                      <label for="priNo">PRI No</label>
//                      <input type="text" id="priNo" name="priNo" required value="${data.description}" readonly />
//                  </div>
 
//                  <hr style="margin:50px 0" />
//                  <h4>PROJECT</h4>
 
//                  <div class="longer-form">
//                      <label for="distribution">Distribution</label>
//                      <select name="distribution" id="distribution" class="select-input" readonly>
//                          <option value="Owner" ${data.distribution === 'Owner' ? 'selected' : ''}>Owner</option>
//                          <option value="Contractor" ${data.distribution === 'Contractor' ? 'selected' : ''}>Contractor</option>
//                          <option value="CA" ${data.distribution === 'CA' ? 'selected' : ''}>CA</option>
//                          <option value="Other" ${data.distribution === 'Other' ? 'selected' : ''}>Other</option>
//                      </select>
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="issuedBy">Issued By</label>
//                      <input type="text" id="issuedBy" name="issuedBy" required value="${data.description}" readonly />
//                  </div>
 
//                  <div class="longer-form">
//                      <label for="reason">Reason</label>
//                      <input type="text" id="reason" name="reason" required value="${data.description}" readonly />
//                  </div>
 
//                  <button type="button" class="edit-button" onclick="saveRmpQTemplateData()" id="save-btn">Update</button>  
//              </form>
//          </div>
//      </div>
//  `;
 
//      if (modals) {
//          modals.innerHTML = modalContent;
//          openModal();
//      }


// }

// function deleteFieldInfoData(FieldInfoDataId){
//     swal({
//         title: "Are you sure?",
//         text: "This will be deleted permanently.",
//         type: "warning",
//         showCancelButton: true,
//         showConfirmButton: true,
//         confirmButtonColor: "#DD6B55",
//         confirmButtonText: "Delete",
//         cancelButtonText: "Cancel",
//         closeOnConfirm: true,
//         closeOnCancel: true
//       },
//       function(isConfirm){
//         if (isConfirm) {
//             var formData = new FormData();
//             formData.append('FieldInfoDataId', FieldInfoDataId);
//             var xhttp = new XMLHttpRequest();
//             xhttp.onload = function(){
//                 var response = JSON.parse(xhttp.response);
//                 if(response.success){
//                     getFieldInfoData();
//                     swal('Hurray', response.success, 'success');
//                 }
//                 else{
//                     swal('Sorry', response.error, 'error');
                    
//                 }
//             }
//             xhttp.onerror = function(error){
//                 swal('Sorry', "An error occured, try again!", 'error');
//             }
//             xhttp.open('POST', serverUrl+'?function=delete-FieldInfoData', true);
//             xhttp.send(formData);
//         }
//       });
// }

