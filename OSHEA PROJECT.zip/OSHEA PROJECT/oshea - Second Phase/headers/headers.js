//new


var sidebar = document.getElementById('leftbar');

const newLocal = `
                    <style>
                        .dropdown-container{
                            background: white;
                            padding: 10px;
                            display: none;
                            margin-top: -10px;
                        }
                        .dropdown-item{
                            padding-top: 15px;
                            padding-bottom: 15px;
                        }
                        .dropdown-text{
                            padding-top: 10px;
                            color: black;
                            font-size: 15px;
                        }
                        .arrow-icon{
                            width: 20px;
                            height: 20px;
                            // transform: rotate(45deg);
                        }
                    </style>
                    <div class="leftbar">
                        <a href="../dashboard/dashboard.html" class="leftbar-details" >
                            <p>Dashboard</p>
                        </a>
                        <a href="javascript:void(0)">
                            <div>
                                <div  class="leftbar-details">

                                    <p id="contact-dropdown" onclick="viewDropdownItems(this)">Contact Management </p>
                                    <div onclick="toggleContactCollapse()" >
                                        <img id="contact-dropdown-img" src="../assets/icons/down-arrow.png" class="arrow-icon">
                                    </div>
                                </div>
                                <div id="contact" class="dropdown-container">
                                    <div class="dropdown-item" onclick="viewDropdownItem('../contact/contactlist.html')"><span class="dropdown-text">Manage Client</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../contact/leadlist.html')"><span class="dropdown-text">Manage Lead</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../contact/archive.html')"><span class="dropdown-text">Archive</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick=""><span class="dropdown-text">Analytics</span></div>
                                </div>
                            <div>
                        </a>
                        <a href="javascript:void(0)">
                            <div>
                                <div  class="leftbar-details">
                                    <p id="contact-dropdown" onclick="viewDropdownItemsProjectManagement(this)">Project Management </p>
                                    <div onclick="toggleContactCollapseProjectManagement()" >
                                        <img id="project-dropdown-img" src="../assets/icons/down-arrow.png" class="arrow-icon">
                                    </div>
                                </div>
                                <div id="project" class="dropdown-container">
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/projectdisplay.html')"><span class="dropdown-text">Manage Projects</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/activitypart1.html')"><span class="dropdown-text">Weekly Work Schedule</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/worksite.html')"><span class="dropdown-text">Summary Report</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/plannedscope.html')"><span class="dropdown-text">Activity Program Phasing</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/issue.html')"><span class="dropdown-text">Issues Register</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/projectaudit.html')"><span class="dropdown-text">Project Audit</span></div>
                                    <hr>
                                    
                                    

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/hazardanalysis.html')"><span class="dropdown-text">Hazard Analysis</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/riskidentification.html')"><span class="dropdown-text">Risk Identification</span></div>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/hazardriskidentification.html')"><span class="dropdown-text">Hazard/Risk Identification</span></div>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/sitetoolbox.html')"><span class="dropdown-text">Site Toolbox</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/RmpTemplate(Qlty).html')"><span class="dropdown-text">Rmp Template(Quality)</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/RmpTemplate(ex).html')"><span class="dropdown-text">Rmp Template(Ex)</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/RmpTemplate.html')"><span class="dropdown-text">Rmp Template</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/RmpInstruction.html')"><span class="dropdown-text">Rmp Template Instruction</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/stakeholder_ComPlan.html')"><span class="dropdown-text">Stakeholder Communication Planning</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/scDocumQuality.html')"><span class="dropdown-text"> StakeHolder Document Quality</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/stakeholderAss.html')"><span class="dropdown-text">Stakeholder Assesment</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/SCInstruction.html')"><span class="dropdown-text">Stakeholder Instruction</span></div>
                                    <hr>


                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/Engin_Corresp.html')"><span class="dropdown-text"> Engineering Correspondenece</span></div>
                                    <hr>
                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/FieldInstruction.html')"><span class="dropdown-text"> Field Instruction</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/siteAudit.html')"><span class="dropdown-text"> Site Audit</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/siteAuditWithNoSidebar.html')"><span class="dropdown-text"> Site Audit(StandAlone)</span></div>
                                    <hr>

                                    <div class="dropdown-item" onclick="viewDropdownItem('../projectmanagement/RAM.HTML')"><span class="dropdown-text"> Risk Management Metrics</span></div>
                                    <hr>
                                    
                                 
                                </div>
                            <div>
                        </a>
                        <a href="../hr/hrdashboard.html" class="leftbar-details">
                            <p>HR Management</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Accounts Management</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details" >
                            <p>Business Intelligence</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details" >
                            <p>Supply Chain </p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Materials  Inventory</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Access Control </p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Office Administration</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Health & Safety</p>
                        </a>
                        <a href="javascript:void(0)" class="leftbar-details">
                            <p>Settings</p>
                        </a>  
                        <a href="javascript:void(0)" onclick="logout()" class="leftbar-details">
                        
                        <p>Logout</p>
                    </a>
                    </div>`;
var sidebarContent = newLocal;
if(sidebar){
    sidebar.innerHTML = sidebarContent;
}

var dropdownElement;
var dropdownContenct = "";
var dropdownBtn;

function viewDropdownItems(element){
    var path = window.location.pathname;
    if(path == '/contact/contactdashboard.html' || path == '/contact/contactlist.html' || path == '/contact/view.html' || path == '/contact/leadlist.html' || path == '/contact/archive.html' || path == '/contact/active-contact.html' || path == '/contact/active-lead.html' || path == '/contact/analytics.html' || path == '/contact/average-contact.html' || path == '/contact/inactive-contact.html' || path == '/contact/pending-contact.html'){
        dropdownBtn = element;
        var id = element.getAttribute('id');
        var split_id = id.split('-');
        var value = split_id[0];
        dropdownElement = document.getElementById(value);
        dropdownElement.style.display = 'block';
        window.location.href = '../contact/contactdashboard.html';
    }else{
        window.location.href = '../contact/contactdashboard.html';
    }
}

function viewDropdownItemsProjectManagement(element){
    var path = window.location.pathname;
    if(path == '/contact/contactdashboard.html' || path == '/contact/contactlist.html' || path == '/contact/view.html' || path == '/contact/leadlist.html' || path == '/contact/archive.html' || path == '/contact/active-contact.html' || path == '/contact/active-lead.html' || path == '/contact/analytics.html' || path == '/contact/average-contact.html' || path == '/contact/inactive-contact.html' || path == '/contact/pending-contact.html'){
        dropdownBtn = element;
        var id = element.getAttribute('id');
        var split_id = id.split('-');
        var value = split_id[0];
        dropdownElement = document.getElementById(value);
        dropdownElement.style.display = 'block';
        window.location.href = '../projectmanagement/projectmanagement.html';
    }else{
        window.location.href = '../projectmanagement/projectmanagement.html';
    }
}

var itemsdropped = false;
function toggleContactCollapse(){
    var contactElement = document.getElementById('contact');
    var contactDropdownImg = document.getElementById('contact-dropdown-img');
    itemsdropped = !itemsdropped;
    if(itemsdropped){
        contactElement.style.display = 'block';
        contactDropdownImg.style.transform = "rotate(180deg)";
    }else{
        contactElement.style.display = 'none';
        contactDropdownImg.style.transform = "rotate(0deg)";
    }
}
var itemsdropped = false;
function toggleContactCollapseProjectManagement(){
    var projectElement = document.getElementById('project');
    var projectDropdownImg = document.getElementById('project-dropdown-img');
    itemsdropped = !itemsdropped;
    if(itemsdropped){
        projectElement.style.display = 'block';
        projectDropdownImg.style.transform = "rotate(180deg)";
    }else{
        projectElement.style.display = 'none';
        projectDropdownImg.style.transform = "rotate(0deg)";
    }
}
document.addEventListener('DOMContentLoaded', function(event){
    var contactdropdown = document.getElementById('contact-leftbar');
    var path = window.location.pathname;
    if(path == '/contact/contactdashboard.html' || path == '/contact/contactlist.html' || path == '/contact/view.html' || path == '/contact/leadlist.html' || path == '/contact/archive.html' || path == '/contact/active-contact.html' || path == '/contact/active-lead.html' || path == '/contact/analytics.html' || path == '/contact/average-contact.html' || path == '/contact/inactive-contact.html' || path == '/contact/pending-contact.html'){
        var dropdownElement = document.getElementById('contact');
        dropdownElement.style.display = 'block';
        contactdropdown.style.color = '#82bf25';
    }else{

    }
    
});
document.addEventListener('click', function(event){
    if(dropdownBtn){
        if(!dropdownBtn.contains(event.target)){
            dropdownElement.style.display = 'none';
        }
    }
    
});

function viewDropdownItem(route){
    window.location.href = route;
}


const navbar = document.getElementById("navbar")

navbar.innerHTML = `
<link rel="stylesheet" href="../assets/font-awesome/css/font-awesome.min.css">
<nav style="position: fixed;top: 0;z-index: 9999;width: 100%;background: #091e42;padding-bottom: 4px;align-items: baseline;">
<a href="../dashboard/dashboard.html" style="color: white;text-decoration: none;">
    <div class="logo">
        <img src="../assetsPeter/logo.png"/>
        <p>Oshea Projects Ltd</p>
    </div>
</a>

<ul class='navlist-content'>
   
    <li class="nav-inline">
        <img src="../assets/icons/admin.png" class="admin-image">
        <div style="margin-top: 2px;">
            <span>Oshea Administrator</span>
        </div>
        <div style="margin-top: 2px;">
            <i id="admin-options-btn" class="fa fa-chevron-down" onclick="toggleAdminOptions()" style="color: white;font-size: 10px;"></i>
            <div id="admin-options">
                <ul class="admin-options-lists">
                    <li class="admin-option-item">
                        <a class="admin-option-link" href="javascript:void(0)">General Settings</a>
                    </li>
                    <hr>
                    <li class="admin-option-item">
                        <a class="admin-option-link" href="javascript:void(0)">Profile Settings</a>
                    </li>
                    <hr>
                    <li class="admin-option-item" onclick="logout()">
                        <a class="admin-option-link" href="javascript:void(0)">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </li>
    <li onclick="logout()" >
        <a href="javascript:void(0)" class="nav-inline" style="column-gap: 5px;">
            <div class="home-search-icon" style="margin-top: 2px;">
                <i class="fa fa-sign-out color-red"></i>
            </div>
            <div style="margin-top: 5px;">
                <span style="color: white;">Logout</span>
            </div>
        </a>
    </li>
</ul>
<div class='hamburger' id='hamburger'> &#9776;</div>
</nav>
</div>`



const hamburger = document.getElementById('hamburger')
let toggleHamburger = true;
const leftbar = document.querySelector('.leftbar')
const links = document.querySelectorAll('#leftbar a');

if(hamburger) {
    hamburger.addEventListener('click', () => {
        toggleHamburger = !toggleHamburger;
        if
        (toggleHamburger){
            hamburger.innerHTML = '&#9776;';
            leftbar.style.display = 'none';
        } else {
            hamburger.innerHTML = '&#10006;';
            leftbar.style.display = 'block';
        }
       
    })
}

if(sidebar){
   
    document.addEventListener('DOMContentLoaded', event => {
      
        if(window.matchMedia('(max-width:425px)').matches){
          
            links.forEach (link => {
                link.addEventListener('click', () => {
                    sidebar.style.display = 'none';
                })
            })
        }
    })
}

var optionsAdminToggled = false;
var adminOptions = document.getElementById('admin-options');
var adminOptionBtn = document.getElementById('admin-options-btn');
function toggleAdminOptions(){
    optionsAdminToggled = !optionsAdminToggled;
    if(optionsAdminToggled){
        adminOptionBtn.style.transform = 'rotate(180deg)';
        adminOptions.style.display = 'block';
    }else{
        adminOptionBtn.style.transform = 'rotate(0deg)';
        adminOptions.style.display = 'none';
    }
}
document.addEventListener('click', function(event){
    if(!adminOptionBtn.contains(event.target)){
        optionsAdminToggled = false;
        adminOptionBtn.style.transform = 'rotate(0deg)';
        adminOptions.style.display = 'none';
    }
});


var footer = document.getElementById('footer');


const smallFooter = `<footer class="footer">
<div class="second-footer">
<div class="second-links">
    <svg width="9" height="59" viewBox="0 0 9 59" fill="none" xmlns="http://www.w3.org/2000/svg">
        <line x1="3.99941" y1="0.931045" x2="4.99941" y2="58.931" stroke="#6F6DEB" stroke-width="8"/>
    </svg>
    <div class="grouped-links">
       
        <h3>FOLLOW US</h3>
        <div>
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="33" viewBox="0 0 40 33" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M27.45 32.4238V19.8677H32.65L33.428 14.9749H27.448V11.8509C27.448 10.434 27.934 9.46774 30.442 9.46774H33.638V5.09053C32.0902 4.95701 30.5345 4.89207 28.978 4.89599C24.37 4.89599 21.216 7.177 21.216 11.3645V14.9749H16V19.8677H21.214V32.4238H2.208C0.988 32.4238 0 31.6229 0 30.634V1.78979C0 0.800867 0.988 0 2.208 0H37.792C39.012 0 40 0.800867 40 1.78979V30.634C40 31.6229 39.012 32.4238 37.792 32.4238H27.45Z" fill="white"/>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="33" viewBox="0 0 40 33" fill="none">
                <path d="M22.056 0C24.3059 0.00486345 25.4479 0.0145904 26.4338 0.0372864L26.8218 0.0486345C27.2698 0.0616037 27.7117 0.0778151 28.2457 0.0972689C30.3736 0.178326 31.8255 0.45068 33.0995 0.851104C34.4194 1.26288 35.5313 1.82055 36.6433 2.72029C37.6602 3.5307 38.4471 4.51099 38.9492 5.59297C39.4431 6.62564 39.7791 7.80259 39.8791 9.52912C39.9031 9.96034 39.9231 10.3186 39.9391 10.6834L39.9511 10.9979C39.9811 11.7955 39.9931 12.7212 39.9971 14.545L39.9991 15.7543V17.878C40.004 19.0605 39.9887 20.243 39.9531 21.4251L39.9411 21.7396C39.9251 22.1044 39.9051 22.4627 39.8811 22.8939C39.7811 24.6204 39.4411 25.7957 38.9492 26.83C38.4485 27.9126 37.6615 28.8931 36.6433 29.7027C35.6433 30.5268 34.434 31.1646 33.0995 31.5719C31.8255 31.9723 30.3736 32.2447 28.2457 32.3257C27.7712 32.3438 27.2965 32.3601 26.8218 32.3744L26.4338 32.3841C25.4479 32.4068 24.3059 32.4181 22.056 32.4214L20.5641 32.423H17.9462C16.4868 32.4271 15.0274 32.4146 13.5685 32.3857L13.1805 32.376C12.7057 32.3614 12.2311 32.3447 11.7566 32.3257C9.62866 32.2447 8.17673 31.9723 6.9008 31.5719C5.56621 31.1656 4.35737 30.5276 3.35898 29.7027C2.34112 28.8926 1.55352 27.9122 1.0511 26.83C0.557126 25.7974 0.221143 24.6204 0.121148 22.8939C0.0988664 22.5092 0.0788673 22.1244 0.0611508 21.7396L0.0511516 21.4251C0.0142976 20.243 -0.00237005 19.0605 0.00115394 17.878V14.545C-0.0044277 13.3625 0.0102398 12.18 0.0451518 10.9979L0.0591511 10.6834C0.0751502 10.3186 0.0951492 9.96034 0.119148 9.52912C0.219143 7.80259 0.555125 6.62726 1.0491 5.59297C1.5513 4.50988 2.34047 3.52928 3.36098 2.72029C4.35911 1.89589 5.56716 1.25799 6.9008 0.851104C8.17673 0.45068 9.62666 0.178326 11.7566 0.0972689C12.2885 0.0778151 12.7325 0.0616037 13.1805 0.0486345L13.5685 0.0389075C15.0268 0.0101042 16.4855 -0.00232586 17.9442 0.00162103L22.056 0ZM20.0001 8.10575C17.3481 8.10575 14.8047 8.95975 12.9294 10.4799C11.0542 12 10.0006 14.0617 10.0006 16.2115C10.0006 18.3613 11.0542 20.423 12.9294 21.9431C14.8047 23.4633 17.3481 24.3172 20.0001 24.3172C22.6522 24.3172 25.1956 23.4633 27.0708 21.9431C28.9461 20.423 29.9996 18.3613 29.9996 16.2115C29.9996 14.0617 28.9461 12 27.0708 10.4799C25.1956 8.95975 22.6522 8.10575 20.0001 8.10575ZM20.0001 11.348C20.788 11.3479 21.5682 11.4736 22.2962 11.7179C23.0242 11.9623 23.6856 12.3204 24.2428 12.7719C24.8001 13.2235 25.2421 13.7596 25.5437 14.3496C25.8454 14.9396 26.0007 15.572 26.0008 16.2107C26.001 16.8494 25.8459 17.4818 25.5445 18.0719C25.2431 18.662 24.8013 19.1982 24.2443 19.6499C23.6872 20.1016 23.0259 20.4599 22.298 20.7044C21.5702 20.9489 20.79 21.0748 20.0021 21.0749C18.4109 21.0749 16.8849 20.5626 15.7597 19.6505C14.6345 18.7384 14.0024 17.5014 14.0024 16.2115C14.0024 14.9216 14.6345 13.6846 15.7597 12.7725C16.8849 11.8604 18.4109 11.348 20.0021 11.348M30.5016 5.67402C29.8386 5.67402 29.2027 5.88752 28.7339 6.26755C28.2651 6.64758 28.0017 7.16302 28.0017 7.70046C28.0017 8.23791 28.2651 8.75334 28.7339 9.13337C29.2027 9.5134 29.8386 9.7269 30.5016 9.7269C31.1646 9.7269 31.8005 9.5134 32.2693 9.13337C32.7381 8.75334 33.0015 8.23791 33.0015 7.70046C33.0015 7.16302 32.7381 6.64758 32.2693 6.26755C31.8005 5.88752 31.1646 5.67402 30.5016 5.67402Z" fill="white"/>
            </svg>
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="33" viewBox="0 0 40 33" fill="none">
                <path d="M23.8041 13.7291L38.6942 0H35.1651L22.2395 11.9204L11.9109 0H0L15.6165 18.0276L0 32.4238H3.52915L17.1811 19.8341L28.0891 32.4238H40L23.8041 13.7291ZM18.9721 18.1851L17.3899 16.3902L4.79965 2.10754H10.2198L20.3779 13.6342L21.9601 15.4291L35.168 30.4135H29.7478L18.9721 18.1851Z" fill="white"/>
            </svg>
        </div>
        
    </div>

</div>
<p>2024- OSHEA Projects. All Rights Reserved</p>
</div> </footer>`


const footerWidth = window.innerWidth;


if(footer){
        footer.innerHTML = smallFooter
}

function logout(){
    window.localStorage.removeItem('admin');
    window.location.href = '../index.html';
}
