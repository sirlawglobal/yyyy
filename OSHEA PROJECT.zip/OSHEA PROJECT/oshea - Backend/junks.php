<?php

$values = [
    isset($_POST['projectTitle']) ? $db->real_escape($_POST['projectTitle']) : null,
    isset($_POST['description']) ? $db->real_escape($_POST['description']) : null,
    isset($_POST['date']) ? $db->real_escape($_POST['date']) : null,
    isset($_POST['fileNo']) ? $db->real_escape($_POST['fileNo']) : null,
    isset($_POST['BidOppNo']) ? $db->real_escape($_POST['BidOppNo']) : null,
    isset($_POST['stakeholder']) ? $db->real_escape($_POST['stakeholder']) : null,
    isset($_POST['interestExpectations']) ? $db->real_escape($_POST['interestExpectations']) : null,  
    isset($_POST['importanceInfluence']) ? $db->real_escape($_POST['importanceInfluence']) : null,  
    isset($_POST['assessmentOfImpact']) ? $db->real_escape($_POST['assessmentOfImpact']) : null,  
    isset($_POST['strategySupport']) ? $db->real_escape($_POST['strategySupport']) : null  
];

$columns = [
    'project' => 'LONGTEXT',
    'description' => 'VARCHAR(255)',
    'date' => 'VARCHAR(255)',
    'fileNo' => 'VARCHAR(255)',
    'BidOppNo' => 'VARCHAR(255)',
    'stakeholder' => 'LONGTEXT',
    'intrestAndExpect' => 'VARCHAR(255)', 
    'impAndInfluence' => 'VARCHAR(255)', 
    'assOfImp' => 'VARCHAR(255)',
    'strategyForSupport' => 'VARCHAR(255)'
];