{
    "name": "My Server",
    "host": "ftp.osheacrm.com",
    "protocol": "ftp",
    "port": 21,
   
    "username": "oshea_backend_user@backend.osheacrm.com",
    "password": "i#BdF_x67?KD",
    "remotePath": "/backend.osheacrm.com",
    "uploadOnSave": false,
    "useTempFile": false,
    "openSsh": false
}


 