<?php

    class Database{
        protected $host = "localhost";
        protected $user = "osheacrm_osheacrm";
        protected $pass = "1j)j;A%eNday";
        protected $database = "osheacrm_db";
        
        public $connect;
        
        public function __construct(){
            $this->connect = new mysqli($this->host, $this->user, $this->pass, $this->database);
            if($this->connect->connect_error){
                echo "Sorry, couldn't connect to database ".$this->connect->connect_error;
            }else{
                //echo 'connected to database';
            }
            
            //$this->createAdminLogin();
        }
        public function query($sql){
            $query = $this->connect->query($sql);
            return $query;
        }
        public function get($table){
            $sql = "SELECT * FROM $table ORDER BY id DESC";
            $query = $this->connect->query($sql);
            $data = [];
            while($row = $query->fetch_assoc()){
                array_push($data, $row);
            }
            return $data;
        }
        public function delete($table, $id){
            $sql = "DELETE FROM $table WHERE id = '$id'";
            $this->connect->query($sql);
            return true;
        }
        public function update($table="", $data="", $id=""){
            // Assuming $data is your input array with keys as the column names
            $update_fields = $data;
            $update_query = "UPDATE $table SET ";
            $update_parts = [];
            foreach ($update_fields as $column => $value) {
                if (!empty($value)) { // Only include columns that have a value
                    $update_parts[] = "$column = '$value'";
                }
            }
            // Join the parts with commas
            $update_query .= implode(', ', $update_parts);
            $update_query .= " WHERE id = '$id'";
            // Execute the query
            if ($this->connect->query($update_query) === TRUE) {
                return true;
            } else {
                return false;
            }
        }
        public function insert($table = "", $data = "") {
            // Assuming $data is your input array with keys as the column names
            if (empty($data) || empty($table)) {
                return false; // Return false if table or data is empty
            }
        
            // Sanitize data and prepare columns and values
            $columns = [];
            $values = [];
            
            foreach ($data as $column => $value) {
                if (!empty($value)) { // Only include columns that have a value
                    $columns[] = $column;
                    $values[] = "'" . $this->connect->real_escape_string(trim($value)) . "'";
                }
            }
        
            // Join columns and values into a string for the SQL query
            $columns_string = implode(', ', $columns);
            $values_string = implode(', ', $values);
        
            // Build the SQL query
            $insert_query = "INSERT INTO $table ($columns_string) VALUES ($values_string)";
        
            // Execute the query
            if ($this->connect->query($insert_query) === TRUE) {
                return true; // Return true on success
            } else {
                return false; // Return false on failure
            }
        }
        public function getTable($table, $columnExualToValue = null) {
            // Base query to select all columns from the given table
            $query = "SELECT * FROM `$table`";
            
            // If $columnExualToValue is provided, add a WHERE clause
            if (!is_null($columnExualToValue) && is_array($columnExualToValue) && count($columnExualToValue) > 0) {
                // Initialize an array to hold conditions
                $conditions = [];
        
                // Loop through each column-value pair and build the condition
                foreach ($columnExualToValue as $column => $value) {
                    $conditions[] = "`$column` = '$value'";
                }
        
                // If there's at least one condition, add the WHERE clause
                if (count($conditions) > 0) {
                    $query .= " WHERE " . implode(" AND ", $conditions);
                }else{
                    foreach ($columnExualToValue as $column => $value) {
                        $query .= " WHERE `$column` = '$value'";
                    }
                }
            }
            
            // Execute the query
            $result = $this->connect->query($query);
        
            return $result;
        }
        public function real_escape($value){
            return $this->connect->real_escape_string(trim($value));
        }
        public function createAdminLogin(){
            $username = "admin@osheacrm.com";
            $password = "1224";
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO admins(username, password) VALUES('{$username}', '{$hashed_password}')";
            $query = $this->connect->query($sql);
            return $query;
            
        }
        
        public function checkTableExistence($tableName, $columns) {
            // Check if the table exists
            $query = "SHOW TABLES LIKE '$tableName'";
            $result = $this->connect->query($query);
        
            // If table does not exist, create it
            if ($result->num_rows == 0) {
                // Build the SQL statement to create the table
                $createTableQuery = "CREATE TABLE `$tableName` (";
                $columnDefinitions = [];
        
                foreach ($columns as $name => $definition) {
                    $columnDefinitions[] = "`$name` $definition";
                }
        
                // Join column definitions and complete the query
                $createTableQuery .= implode(", ", $columnDefinitions) . ") ENGINE=InnoDB;";
        
                // Execute the query to create the table
                $this->connect->query($createTableQuery);
            } else {
                //
            }
        }
        public function save($tableName, $columns, $data) {
            // Check if the table exists
            $query = "SHOW TABLES LIKE '$tableName'";
            $result = $this->connect->query($query);
            
            // Add 'id' column as a primary key
            $columns['id'] = "INT AUTO_INCREMENT PRIMARY KEY";
            
            // If table does not exist, create it
            if ($result->num_rows == 0) {
                // Build the SQL statement to create the table
                $createTableQuery = "CREATE TABLE `$tableName` (";
                $columnDefinitions = [];
            
                foreach ($columns as $name => $definition) {
                    $columnDefinitions[] = "`$name` $definition";
                }
            
                // Join column definitions and complete the query
                $createTableQuery .= implode(", ", $columnDefinitions) . ") ENGINE=InnoDB;";
                
                // Execute the query to create the table
                if (!$this->connect->query($createTableQuery)) {
                    // Handle query error
                    die("Error creating table: " . $this->connect->error);
                }
            } else {
                // The table exists, so check for any new columns and alter the table accordingly
                $existingColumnsQuery = "SHOW COLUMNS FROM `$tableName`";
                $existingColumnsResult = $this->connect->query($existingColumnsQuery);
                
                // Store existing columns in an array
                $existingColumns = [];
                while ($row = $existingColumnsResult->fetch_assoc()) {
                    $existingColumns[] = $row['Field'];
                }
            
                // Loop through provided columns and add new columns if not already in the table
                foreach ($columns as $name => $definition) {
                    if (!in_array($name, $existingColumns)) {
                        // Alter table to add new column
                        $alterTableQuery = "ALTER TABLE `$tableName` ADD `$name` $definition";
                        if (!$this->connect->query($alterTableQuery)) {
                            // Handle query error
                        }
                    }
                }
            }
            
            // Insert the new data
            // Ensure $data array is defined and matches column names
            if (!isset($data) || empty($data)) {
                //die("No data to insert.");
            }
            
            // Filter out the 'id' field since it's AUTO_INCREMENT and not part of the INSERT
            $columnsWithoutId = array_filter(array_keys($columns), function($col) {
                return $col !== 'id';
            });
            
            $columnNames = implode(", ", $columnsWithoutId);
            
            // Quote the values (assuming you're not using prepared statements)
            $quotedValues = array_map(function($value) {
                return "'" . $value. "'";
            }, $data);
            
            $valuesString = implode(", ", $quotedValues);
            
            //Build and execute the insert query
            $saveSql = "INSERT INTO $tableName ($columnNames) VALUES ($valuesString)";
            $this->connect->query($saveSql);
            
            return true;
        }
        
        public function adminLogin($username, $password){
            $sql = "SELECT * FROM admins WHERE username = '$username'";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $row = $query->fetch_assoc();
                $verify_password = password_verify($password, $row['password']);
                if($verify_password){
                    return $row;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        public function saveContact($data){
            $contactId = $this->connect->real_escape_string($data['contactId']);
            $contactName = $this->connect->real_escape_string($data['contactName']);
            $company_name = $this->connect->real_escape_string($data['company_name']);
            $position = $this->connect->real_escape_string($data['position']);
            $phone = $this->connect->real_escape_string($data['phone']);
            $source = $this->connect->real_escape_string($data['source']);
            $modifiedDate = $this->connect->real_escape_string($data['modifiedDate']);
            $status = $this->connect->real_escape_string($data['status']);

            $sql = "INSERT INTO contacts(contactId, contactName, address, email, phone, source, modifiedDate, status, company_name, position) VALUES('{$contactId}', '{$contactName}', '{$address}', '{$email}', '{$phone}', '{$source}', '{$modifiedDate}', '{$status}', '{$company_name}', '{$position}')";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function updateContact($data){
            $contactId = $this->connect->real_escape_string($data['contactId']);
            $contactName = $this->connect->real_escape_string($data['contactName']);
            $address = $this->connect->real_escape_string($data['address']);
            $email = $this->connect->real_escape_string($data['email']);
            $phone = $this->connect->real_escape_string($data['phone']);
            $source = $this->connect->real_escape_string($data['source']);
            $modifiedDate = $this->connect->real_escape_string($data['modifiedDate']);
            $status = $this->connect->real_escape_string($data['status']);
            $contact_id = $this->connect->real_escape_string($data['contact_id']);
            $company_name = $this->connect->real_escape_string($data['company_name']);
            $position = $this->connect->real_escape_string($data['position']);

            
            $sql = "UPDATE contacts SET contactName = '$contactName', address = '$address', email = '$email', phone = '$phone', source='$source', modifiedDate='$modifiedDate', status='$status', company_name = '$company_name', position = '$position' WHERE id = '$contact_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function getContacts(){
            $sql = "SELECT * FROM contacts";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }
        public function deleteContact($data){
            $contactID = $data['contact_id'];
            $sql = "DELETE FROM contacts WHERE id = '$contactID'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function saveLead($data){
            $companyName = $this->connect->real_escape_string($data['companyName']);
            $address = $this->connect->real_escape_string($data['address']);
            $amount = $this->connect->real_escape_string($data['amount']);
            $contact_name = $this->connect->real_escape_string($data['contact_name']);
            $cac_reg = $this->connect->real_escape_string($data['cac_reg']);
            $owner_type = $this->connect->real_escape_string($data['owner_type']);
            $tax_number = $this->connect->real_escape_string($data['tax_number']);
            $vat_number = $this->connect->real_escape_string($data['vat_number']);
            $bank_name = $this->connect->real_escape_string($data['bank_name']);
            $bank_country = $this->connect->real_escape_string($data['bank_country']);
            $account_name = $this->connect->real_escape_string($data['account_name']);
            $account_number = $this->connect->real_escape_string($data['account_number']);
            $bank_code = $this->connect->real_escape_string($data['bank_code']);
            $bank_branch = $this->connect->real_escape_string($data['bank_branch']);
            $bank_address = $this->connect->real_escape_string($data['bank_address']);
            $business_category = $this->connect->real_escape_string($data['business_category']);
            $web_link = $this->connect->real_escape_string($data['web_link']);
            $social_handle = $this->connect->real_escape_string($data['social_handle']);
            $status = $this->connect->real_escape_string($data['status']);
            $endDate = $this->connect->real_escape_string($data['endDate']);

            
            $sql = "INSERT INTO leads(companyName, address, amount, contact_name, cac_reg, owner_type, tax_number, vat_number, bank_name, bank_country, account_name,account_number,bank_code,bank_branch,bank_address,business_category,web_link,social_handle,status,endDate) VALUES('{$companyName}', '{$address}', '{$amount}', '{$contact_name}', '{$cac_reg}', '{$owner_type}', '{$tax_number}', '{$vat_number}', '{$bank_name}', '{$bank_country}','{$account_name}','{$account_number}','{$bank_code}','{$bank_branch}','{$bank_address}','{$business_category}', '{$web_link}','{$social_handle}','{$status}','{$endDate}')";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function updateLead($data){
            $companyName = $this->connect->real_escape_string($data['companyName']);
            $address = $this->connect->real_escape_string($data['address']);
            $amount = $this->connect->real_escape_string($data['amount']);
            $contact_name = $this->connect->real_escape_string($data['contact_name']);
            $cac_reg = $this->connect->real_escape_string($data['cac_reg']);
            $owner_type = $this->connect->real_escape_string($data['owner_type']);
            $tax_number = $this->connect->real_escape_string($data['tax_number']);
            $vat_number = $this->connect->real_escape_string($data['vat_number']);
            $bank_name = $this->connect->real_escape_string($data['bank_name']);
            $bank_country = $this->connect->real_escape_string($data['bank_country']);
            $account_name = $this->connect->real_escape_string($data['account_name']);
            $account_number = $this->connect->real_escape_string($data['account_number']);
            $bank_code = $this->connect->real_escape_string($data['bank_code']);
            $bank_branch = $this->connect->real_escape_string($data['bank_branch']);
            $bank_address = $this->connect->real_escape_string($data['bank_address']);
            $business_category = $this->connect->real_escape_string($data['business_category']);
            $web_link = $this->connect->real_escape_string($data['web_link']);
            $social_handle = $this->connect->real_escape_string($data['social_handle']);
            $status = $this->connect->real_escape_string($data['status']);
            $endDate = $this->connect->real_escape_string($data['endDate']);
            $lead_id = $this->connect->real_escape_string($data['lead_id']);
            
            $sql = "UPDATE leads SET companyName = '$companyName', address = '$address', amount = '$amount', contact_name = '$contact_name', cac_reg = '$cac_reg', owner_type = '$owner_type', tax_number = '$tax_number', vat_number = '$vat_number', bank_name = '$bank_name', bank_country = '$bank_country', account_name = '$account_name', account_number = '$account_number', bank_code = '$bank_code', bank_branch = '$bank_branch', bank_address = '$bank_address', business_category = '$business_category', web_link = '$web_link', social_handle = '$social_handle', status = '$status', endDate = '$endDate' WHERE id = '$lead_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        
        public function getLeads(){
            $sql = "SELECT * FROM leads ORDER BY id DESC";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }
        public function archiveLead($data){
            $lead_id = $data['lead_id'];
            
            $sql = "SELECT * FROM leads WHERE id = '$lead_id'";
            $query = $this->connect->query($sql);
            $row = $query->fetch_assoc();
                
            $companyName = $this->connect->real_escape_string($row['companyName']);
            $address = $this->connect->real_escape_string($row['address']);
            $amount = $this->connect->real_escape_string($row['amount']);
            $currency = $this->connect->real_escape_string($row['currency']);
            $phone = $this->connect->real_escape_string($row['phone']);
            $email = $this->connect->real_escape_string($row['email']);
            $startDate = $this->connect->real_escape_string($row['startDate']);
            $endDate = $this->connect->real_escape_string($row['endDate']);
            $description = $this->connect->real_escape_string($row['descripition']);
            $status = $this->connect->real_escape_string($row['status']);

            
            $sql2 = "INSERT INTO archive(lead_id,companyName, address, amount, currency, phone, email, startDate, endDate, descripition, status) VALUES('{$lead_id}', '{$companyName}', '{$address}', '{$amount}', '{$currency}', '{$phone}', '{$email}', '{$startDate}', '{$endDate}', '{$descripition}', '{$status}')";
            $query2 = $this->connect->query($sql2);
            if($query2){
                $sql3 = "DELETE FROM leads WHERE id = '$lead_id'";
                $query3 = $this->connect->query($sql3);
                if($query3){
                    return true;
                }
                
            }else{
                return false;
            }
            
        }
        public function unarchiveLead($data){
            $lead_id = $data['lead_id'];
            
            $sql = "SELECT * FROM archive WHERE lead_id = '$lead_id'";
            $query = $this->connect->query($sql);
            $row = $query->fetch_assoc();
            
            $companyName = isset($row['companyName']) ? $this->connect->real_escape_string($row['companyName']) : null;
            $address = isset($row['address']) ? $this->connect->real_escape_string($row['address']) : null;
            $amount = isset($row['amount']) ? $this->connect->real_escape_string($row['amount']) : null;
            $currency = isset($row['currency']) ? $this->connect->real_escape_string($row['currency']) : null;
            $phone = isset($row['phone']) ? $this->connect->real_escape_string($row['phone']) : null;
            $email = isset($row['email']) ? $this->connect->real_escape_string($row['email']) : null;
            $startDate = isset($row['startDate']) ? $this->connect->real_escape_string($row['startDate']) : null;
            $endDate = isset($row['endDate']) ? $this->connect->real_escape_string($row['endDate']) : null;
            $description = isset($row['descripition']) ? $this->connect->real_escape_string($row['descripition']) : null;
            $status = isset($row['status']) ? $this->connect->real_escape_string($row['status']) : null;

            
            $sql2 = "INSERT INTO leads(companyName, address, amount, currency, phone, email, startDate, endDate, descripition, status) VALUES('{$companyName}', '{$address}', '{$amount}', '{$currency}', '{$phone}', '{$email}', '{$startDate}', '{$endDate}', '{$descripition}', '{$status}')";
            $query2 = $this->connect->query($sql2);
            if($query2){
                $sql3 = "DELETE FROM archive WHERE lead_id = '$lead_id'";
                $query3 = $this->connect->query($sql3);
                if($query3){
                    return true;
                }
                
            }else{
                return false;
            }
        }
        public function getArchives(){
            $sql = "SELECT * FROM archive ORDER BY id DESC";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }
        public function deleteArchive($data){
            $archiveID = $data['archive_id'];
            $sql = "DELETE FROM archive WHERE id = '$archiveID'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function deleteLead($data){
            $lead_id = $data['lead_id'];
            $sql = "DELETE FROM leads WHERE id = '$lead_id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function saveActivityPhase1($data){
            $task_description = isset($data['task_description']) ? $this->connect->real_escape_string($data['task_description']) : null;
            $project_name = isset($data['project_name']) ? $this->connect->real_escape_string($data['project_name']) : null;
            $activity = isset($data['activity']) ? $this->connect->real_escape_string($data['activity']) : null;
            $expected_start_date = isset($data['expected_start_date']) ? $this->connect->real_escape_string($data['expected_start_date']) : null;
            $expected_finish_date = isset($data['expected_finish_date']) ? $this->connect->real_escape_string($data['expected_finish_date']) : null;
            $planned_activity_percentage = isset($data['planned_activity_percentage']) ? $this->connect->real_escape_string($data['planned_activity_percentage']) : null;
            $actual_activity_percentage = isset($data['actual_activity_percentage']) ? $this->connect->real_escape_string($data['actual_activity_percentage']) : null;
            $activity_in_progress = isset($data['activity_in_progress']) ? $this->connect->real_escape_string($data['activity_in_progress']) : null;
            $latest_finish_date = isset($data['latest_finish_date']) ? $this->connect->real_escape_string($data['latest_finish_date']) : null;
            $remark = isset($data['remark']) ? $this->connect->real_escape_string($data['remark']) : null;
            $role_scheduler = isset($data['role_scheduler']) ? $this->connect->real_escape_string($data['role_scheduler']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;

            
            $sql = "INSERT INTO activity_phase_1(task_description,project_name,activity,expected_start_date,expected_finish_date,planned_activity_percentage,actual_activity_percentage,activity_in_progress,latest_finish_date,remark,role_scheduler,period) VALUES('{$task_description}','{$project_name}','{$activity}','{$expected_start_date}','{$expected_finish_date}','{$planned_activity_percentage}','{$actual_activity_percentage}','{$activity_in_progress}','{$latest_finish_date}','{$remark}','{$role_scheduler}','{$period}')";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function saveActivityPhase2($data){
            $required_number = isset($data['required_number']) ? $this->connect->real_escape_string($data['required_number']) : null;
            $actual_number = isset($data['actual_number']) ? $this->connect->real_escape_string($data['actual_number']) : null;
            $name_of_project_engineer = isset($data['name_of_project_engineer']) ? $this->connect->real_escape_string($data['name_of_project_engineer']) : null;
            $required_number_false = isset($data['required_number_false']) ? $this->connect->real_escape_string($data['required_number_false']) : null;
            $actual_number_false = isset($data['actual_number_false']) ? $this->connect->real_escape_string($data['actual_number_false']) : null;
            $name_of_contractor_supervisor = isset($data['name_of_contractor_supervisor']) ? $this->connect->real_escape_string($data['name_of_contractor_supervisor']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;


            $sql = "INSERT INTO activity_phase_2(required_number,actual_number,name_of_project_engineer,required_number_false,actual_number_false,name_of_contractor_supervisor,remarks,period,challenge_for_escalation) VALUES('{$required_number}','{$actual_number}','{$name_of_project_engineer}','{$required_number_false}','{$actual_number_false}','{$name_of_contractor_supervisor}','{$remarks}','{$period}','{$challenge_for_escalation}')";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
            
        }
        public function saveActivityPhase3($data){
            $material_specification = isset($data['material_specification']) ? $this->connect->real_escape_string($data['material_specification']) : null;
            $requested_number = isset($data['requested_number']) ? $this->connect->real_escape_string($data['requested_number']) : null;
            $delivery_number = isset($data['delivery_number']) ? $this->connect->real_escape_string($data['delivery_number']) : null;
            $date_recieved = isset($data['date_recieved']) ? $this->connect->real_escape_string($data['date_recieved']) : null;
            $utilized = isset($data['utilized']) ? $this->connect->real_escape_string($data['utilized']) : null;
            $date_outstanding = isset($data['date_outstanding']) ? $this->connect->real_escape_string($data['date_outstanding']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $quality = isset($data['quality']) ? $this->connect->real_escape_string($data['quality']) : null;
            $accept_reject = isset($data['accept_reject']) ? $this->connect->real_escape_string($data['accept_reject']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;

            
            $sql = "INSERT INTO  activity_phase_3(material_specification,requested_number,delivery_number,date_recieved,utilized,date_outstanding,remarks,period,quality,accept_reject,challenge_for_escalation) VALUES('{$material_specification}','{$requested_number}','{$delivery_number}','{$date_recieved}','{$utilized}','{$date_outstanding}','{$remarks}','{$period}','{$quality}','{$accept_reject}','{$challenge_for_escalation}')";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function saveActivityPhase4($data){
            $Material_requested_number = isset($data['Material_requested_number']) ? $this->connect->real_escape_string($data['Material_requested_number']) : null;
            $types_of_materials_requested = isset($data['types_of_materials_requested']) ? $this->connect->real_escape_string($data['types_of_materials_requested']) : null;
            $material_received_number = isset($data['material_received_number']) ? $this->connect->real_escape_string($data['material_received_number']) : null;
            $delivered_by = isset($data['delivered_by']) ? $this->connect->real_escape_string($data['delivered_by']) : null;
            $received_by = isset($data['received_by']) ? $this->connect->real_escape_string($data['received_by']) : null;
            $material_inspection_remark = isset($data['material_inspection_remark']) ? $this->connect->real_escape_string($data['material_inspection_remark']) : null;
            $qty_material_rejected_at_site_remark = isset($data['qty_material_rejected_at_site_remark']) ? $this->connect->real_escape_string($data['qty_material_rejected_at_site_remark']) : null;
            $material_utilized = isset($data['material_utilized']) ? $this->connect->real_escape_string($data['material_utilized']) : null;
            $outstanding_materials = isset($data['outstanding_materials']) ? $this->connect->real_escape_string($data['outstanding_materials']) : null;
            $date_outstanding = isset($data['date_outstanding']) ? $this->connect->real_escape_string($data['date_outstanding']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;

            
            $sql = "INSERT INTO  activity_phase_4(Material_requested_number,types_of_materials_requested,material_received_number,delivered_by,received_by,material_inspection_remark,qty_material_rejected_at_site_remark,material_utilized,outstanding_materials,date_outstanding,remarks,period,challenge_for_escalation) VALUES('{$Material_requested_number}','{$types_of_materials_requested}','{$material_received_number}','{$delivered_by}','{$received_by}','{$material_inspection_remark}','{$qty_material_rejected_at_site_remark}','{$material_utilized}','{$outstanding_materials}','{$date_outstanding}','{$remarks}','{$period}','{$challenge_for_escalation}')";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function saveActivityPhase5($data){
            $requisition_raised_reqn_number = isset($data['requisition_raised_reqn_number']) ? $this->connect->real_escape_string($data['requisition_raised_reqn_number']) : null;
            $list_type_of_tools_requested = isset($data['list_type_of_tools_requested']) ? $this->connect->real_escape_string($data['list_type_of_tools_requested']) : null;
            $tool_codes_tag = isset($data['tool_codes_tag']) ? $this->connect->real_escape_string($data['tool_codes_tag']) : null;
            $received_del_no = isset($data['received_del_no']) ? $this->connect->real_escape_string($data['received_del_no']) : null;
            $date_received = isset($data['date_received']) ? $this->connect->real_escape_string($data['date_received']) : null;
            $delivered_by = isset($data['delivered_by']) ? $this->connect->real_escape_string($data['delivered_by']) : null;
            $received_by = isset($data['received_by']) ? $this->connect->real_escape_string($data['received_by']) : null;
            $Inspection_remark_at_delivery = isset($data['Inspection_remark_at_delivery']) ? $this->connect->real_escape_string($data['Inspection_remark_at_delivery']) : null;
            $use_status = isset($data['use_status']) ? $this->connect->real_escape_string($data['use_status']) : null;
            $date_returned = isset($data['date_returned']) ? $this->connect->real_escape_string($data['date_returned']) : null;
            $bi_weekly_remarks_on_tools = isset($data['bi_weekly_remarks_on_tools']) ? $this->connect->real_escape_string($data['bi_weekly_remarks_on_tools']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;

            
            $sql = "INSERT INTO activity_phase_5(requisition_raised_reqn_number,list_type_of_tools_requested,tool_codes_tag,received_del_no,date_received,delivered_by,received_by,Inspection_remark_at_delivery,use_status,date_returned,bi_weekly_remarks_on_tools,remarks,period,challenge_for_escalation) VALUES('{$requisition_raised_reqn_number}','{$list_type_of_tools_requested}', '{$tool_codes_tag}','{$received_del_no}','{$date_received}','{$delivered_by}','{$received_by}','{$Inspection_remark_at_delivery}','{$use_status}','{$date_returned}','{$bi_weekly_remarks_on_tools}','{$remarks}','{$period}','{$challenge_for_escalation}')";
            
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function savePlannedScope_1($data){
            $daily_task = isset($data['daily_task']) ? $this->connect->real_escape_string($data['daily_task']) : null;
            $start_date = isset($data['start_date']) ? $this->connect->real_escape_string($data['start_date']) : null;
            $week = isset($data['week']) ? $this->connect->real_escape_string($data['week']) : null;
            $phasing_percentage = isset($data['phasing_percentage']) ? $this->connect->real_escape_string($data['phasing_percentage']) : null;
            $contract_available = isset($data['contract_available']) ? $this->connect->real_escape_string($data['contract_available']) : null;
            $contract_number = isset($data['contract_number']) ? $this->connect->real_escape_string($data['contract_number']) : null;
            $contract_end_date = isset($data['contract_end_date']) ? $this->connect->real_escape_string($data['contract_end_date']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $duration = isset($data['duration']) ? $this->connect->real_escape_string($data['duration']) : null;
            $end_date = isset($data['end_date']) ? $this->connect->real_escape_string($data['end_date']) : null;
            $pono = isset($data['pono']) ? $this->connect->real_escape_string($data['pono']) : null;
            $day = isset($data['day']) ? $this->connect->real_escape_string($data['day']) : null;

            
            $sql = "INSERT INTO plannedscopes_1(daily_task,start_date,week,phasing_percentage,contract_available,contract_number,contract_end_date,remarks,duration,end_date,pono,day) VALUES('{$daily_task}','{$start_date}','{$week}','{$phasing_percentage}','{$contract_available}','{$contract_number}','{$contract_end_date}','{$remarks}','{$duration}','{$end_date}','{$pono}','{$day}')";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function savePlannedScope_2($data){
            $daily_task = isset($data['daily_task']) ? $this->connect->real_escape_string($data['daily_task']) : null;
            $weekly_schedule = isset($data['weekly_schedule']) ? $this->connect->real_escape_string($data['weekly_schedule']) : null;
            $start_date = isset($data['start_date']) ? $this->connect->real_escape_string($data['start_date']) : null;
            $week = isset($data['week']) ? $this->connect->real_escape_string($data['week']) : null;
            $phasing_percentage = isset($data['phasing_percentage']) ? $this->connect->real_escape_string($data['phasing_percentage']) : null;
            $contract_available = isset($data['contract_available']) ? $this->connect->real_escape_string($data['contract_available']) : null;
            $contract_number = isset($data['contract_number']) ? $this->connect->real_escape_string($data['contract_number']) : null;
            $contract_end_date = isset($data['contract_end_date']) ? $this->connect->real_escape_string($data['contract_end_date']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $duration = isset($data['duration']) ? $this->connect->real_escape_string($data['duration']) : null;
            $end_date = isset($data['end_date']) ? $this->connect->real_escape_string($data['end_date']) : null;
            $pono = isset($data['pono']) ? $this->connect->real_escape_string($data['pono']) : null;
            $day = isset($data['day']) ? $this->connect->real_escape_string($data['day']) : null;

            
            $sql = "INSERT INTO plannedscope_2(daily_task,weekly_schedule,start_date,week,phasing_percentage,contract_available,contract_number,contract_end_date,remarks,duration,end_date,pono,day) VALUES('{$daily_task}','{$weekly_schedule}','{$start_date}','{$week}','{$phasing_percentage}','{$contract_available}','{$contract_number}','{$contract_end_date}','{$remarks}','{$duration}','{$end_date}','{$pono}','{$day}')";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function updateActivityPhase1($data){
            $task_description = isset($data['task_description']) ? $this->connect->real_escape_string($data['task_description']) : null;
            $project_name = isset($data['project_name']) ? $this->connect->real_escape_string($data['project_name']) : null;
            $activity = isset($data['activity']) ? $this->connect->real_escape_string($data['activity']) : null;
            $expected_start_date = isset($data['expected_start_date']) ? $this->connect->real_escape_string($data['expected_start_date']) : null;
            $expected_finish_date = isset($data['expected_finish_date']) ? $this->connect->real_escape_string($data['expected_finish_date']) : null;
            $planned_activity_percentage = isset($data['planned_activity_percentage']) ? $this->connect->real_escape_string($data['planned_activity_percentage']) : null;
            $actual_activity_percentage = isset($data['actual_activity_percentage']) ? $this->connect->real_escape_string($data['actual_activity_percentage']) : null;
            $activity_in_progress = isset($data['activity_in_progress']) ? $this->connect->real_escape_string($data['activity_in_progress']) : null;
            $latest_finish_date = isset($data['latest_finish_date']) ? $this->connect->real_escape_string($data['latest_finish_date']) : null;
            $remark = isset($data['remark']) ? $this->connect->real_escape_string($data['remark']) : null;
            $role_scheduler = isset($data['role_scheduler']) ? $this->connect->real_escape_string($data['role_scheduler']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;

            
            $sql = "UPDATE activity_phase_1 SET task_description='$task_description', project_name='$project_name',activity='$activity',expected_start_date='$expected_start_date',expected_finish_date='$expected_finish_date',planned_activity_percentage='$planned_activity_percentage',actual_activity_percentage='$actual_activity_percentage',activity_in_progress='$activity_in_progress',latest_finish_date='$latest_finish_date',remark='$remark',role_scheduler='$role_scheduler',period='$period' WHERE id = '$id'";
            
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function updateActivityPhase2($data){
            $required_number = isset($data['required_number']) ? $this->connect->real_escape_string($data['required_number']) : null;
            $actual_number = isset($data['actual_number']) ? $this->connect->real_escape_string($data['actual_number']) : null;
            $name_of_project_engineer = isset($data['name_of_project_engineer']) ? $this->connect->real_escape_string($data['name_of_project_engineer']) : null;
            $required_number_false = isset($data['required_number_false']) ? $this->connect->real_escape_string($data['required_number_false']) : null;
            $actual_number_false = isset($data['actual_number_false']) ? $this->connect->real_escape_string($data['actual_number_false']) : null;
            $name_of_contractor_supervisor = isset($data['name_of_contractor_supervisor']) ? $this->connect->real_escape_string($data['name_of_contractor_supervisor']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;

            
            $sql = "UPDATE activity_phase_2 SET required_number='$required_number',actual_number='$actual_number',name_of_project_engineer='$name_of_project_engineer',required_number_false='$required_number_false',actual_number_false='$actual_number_false',name_of_contractor_supervisor='$name_of_contractor_supervisor',remarks='$remarks',period='$period',challenge_for_escalation='$challenge_for_escalation' WHERE id='$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function updateActivityPhase3($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $material_specification = isset($data['material_specification']) ? $this->connect->real_escape_string($data['material_specification']) : null;
            $requested_number = isset($data['requested_number']) ? $this->connect->real_escape_string($data['requested_number']) : null;
            $delivery_number = isset($data['delivery_number']) ? $this->connect->real_escape_string($data['delivery_number']) : null;
            $date_recieved = isset($data['date_recieved']) ? $this->connect->real_escape_string($data['date_recieved']) : null;
            $utilized = isset($data['utilized']) ? $this->connect->real_escape_string($data['utilized']) : null;
            $date_outstanding = isset($data['date_outstanding']) ? $this->connect->real_escape_string($data['date_outstanding']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $quality = isset($data['quality']) ? $this->connect->real_escape_string($data['quality']) : null;
            $accept_reject = isset($data['accept_reject']) ? $this->connect->real_escape_string($data['accept_reject']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;

            
            $sql = "UPDATE activity_phase_3 SET material_specification='$material_specification',requested_number='$requested_number',delivery_number='$delivery_number',date_recieved='$date_recieved',utilized='$utilized',date_outstanding='$date_outstanding',remarks='$remarks',period='$period',quality='$quality',accept_reject='$accept_reject',challenge_for_escalation='$challenge_for_escalation' WHERE id ='$id'";
            $query = $this->connect->query($sql);
            if($query){ 
                return true;
            }else{
                return false;
            }
        }
        public function updateActivityPhase4($data){
            $Material_requested_number = isset($data['Material_requested_number']) ? $this->connect->real_escape_string($data['Material_requested_number']) : null;
            $types_of_materials_requested = isset($data['types_of_materials_requested']) ? $this->connect->real_escape_string($data['types_of_materials_requested']) : null;
            $material_received_number = isset($data['material_received_number']) ? $this->connect->real_escape_string($data['material_received_number']) : null;
            $delivered_by = isset($data['delivered_by']) ? $this->connect->real_escape_string($data['delivered_by']) : null;
            $received_by = isset($data['received_by']) ? $this->connect->real_escape_string($data['received_by']) : null;
            $material_inspection_remark = isset($data['material_inspection_remark']) ? $this->connect->real_escape_string($data['material_inspection_remark']) : null;
            $qty_material_rejected_at_site_remark = isset($data['qty_material_rejected_at_site_remark']) ? $this->connect->real_escape_string($data['qty_material_rejected_at_site_remark']) : null;
            $material_utilized = isset($data['material_utilized']) ? $this->connect->real_escape_string($data['material_utilized']) : null;
            $outstanding_materials = isset($data['outstanding_materials']) ? $this->connect->real_escape_string($data['outstanding_materials']) : null;
            $date_outstanding = isset($data['date_outstanding']) ? $this->connect->real_escape_string($data['date_outstanding']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;

            
            $sql = "UPDATE activity_phase_4 SET Material_requested_number='$Material_requested_number',types_of_materials_requested='$types_of_materials_requested',material_received_number='$material_received_number',delivered_by='$delivered_by',received_by='$received_by',material_inspection_remark='$material_inspection_remark',qty_material_rejected_at_site_remark='$qty_material_rejected_at_site_remark',material_utilized='$material_utilized',outstanding_materials='$outstanding_materials',date_outstanding='$date_outstanding',remarks='$remarks',period='$period',challenge_for_escalation='$challenge_for_escalation' WHERE id = '$id'";
            
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function updateActivityPhase5($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $requisition_raised_reqn_number = isset($data['requisition_raised_reqn_number']) ? $this->connect->real_escape_string($data['requisition_raised_reqn_number']) : null;
            $list_type_of_tools_requested = isset($data['list_type_of_tools_requested']) ? $this->connect->real_escape_string($data['list_type_of_tools_requested']) : null;
            $tool_codes_tag = isset($data['tool_codes_tag']) ? $this->connect->real_escape_string($data['tool_codes_tag']) : null;
            $received_del_no = isset($data['received_del_no']) ? $this->connect->real_escape_string($data['received_del_no']) : null;
            $date_received = isset($data['date_received']) ? $this->connect->real_escape_string($data['date_received']) : null;
            $delivered_by = isset($data['delivered_by']) ? $this->connect->real_escape_string($data['delivered_by']) : null;
            $received_by = isset($data['received_by']) ? $this->connect->real_escape_string($data['received_by']) : null;
            $Inspection_remark_at_delivery = isset($data['Inspection_remark_at_delivery']) ? $this->connect->real_escape_string($data['Inspection_remark_at_delivery']) : null;
            $use_status = isset($data['use_status']) ? $this->connect->real_escape_string($data['use_status']) : null;
            $date_returned = isset($data['date_returned']) ? $this->connect->real_escape_string($data['date_returned']) : null;
            $bi_weekly_remarks_on_tools = isset($data['bi_weekly_remarks_on_tools']) ? $this->connect->real_escape_string($data['bi_weekly_remarks_on_tools']) : null;
            $remarks = isset($data['remarks']) ? $this->connect->real_escape_string($data['remarks']) : null;
            $period = isset($data['period']) ? $this->connect->real_escape_string($data['period']) : null;
            $challenge_for_escalation = isset($data['challenge_for_escalation']) ? $this->connect->real_escape_string($data['challenge_for_escalation']) : null;

            
            $sql = "UPDATE activity_phase_5 SET requisition_raised_reqn_number='$requisition_raised_reqn_number',list_type_of_tools_requested='$list_type_of_tools_requested',tool_codes_tag='$tool_codes_tag',received_del_no='$received_del_no',date_received='$date_received',delivered_by='$delivered_by',received_by='$received_by',Inspection_remark_at_delivery='$Inspection_remark_at_delivery',use_status='$use_status',date_returned='$date_returned',bi_weekly_remarks_on_tools='$bi_weekly_remarks_on_tools',remarks='$remarks',period='$period',challenge_for_escalation='$challenge_for_escalation' WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        public function getActivities(){
            $sql1 = "SELECT * FROM activity_phase_1";
            $query1 = $this->connect->query($sql1);
            $data1 = [];
            while($row = $query1->fetch_assoc()){
                array_push($data1, $row);
            }
            
            $sql2 = "SELECT * FROM activity_phase_2";
            $query2 = $this->connect->query($sql2);
            $data2 = [];
            while($row = $query2->fetch_assoc()){
                array_push($data2, $row);
            }
            
            $sql3 = "SELECT * FROM activity_phase_3";
            $query3 = $this->connect->query($sql3);
            $data3 = [];
            while($row = $query3->fetch_assoc()){
                array_push($data3, $row);
            }
            
            $sql4 = "SELECT * FROM activity_phase_4";
            $query4 = $this->connect->query($sql4);
            $data4 = [];
            while($row = $query4->fetch_assoc()){
                array_push($data4, $row);
            }
            
            $sql5 = "SELECT * FROM activity_phase_5";
            $query5 = $this->connect->query($sql5);
            $data5 = [];
            while($row = $query5->fetch_assoc()){
                array_push($data5, $row);
            }
            
            $arrays = array(
                array('phase_one'=>$data1),
                array('phase_two'=>$data2),
                array('phase_three'=>$data3),
                array('phase_four'=>$data4),
                array('phase_five'=>$data5)
            );
            return $arrays;
        }
        
        public function saveProject($data){
            $project_title = isset($data['project_title']) ? $this->connect->real_escape_string($data['project_title']) : null;
            $start_date = isset($data['start_date']) ? $this->connect->real_escape_string($data['start_date']) : null;
            $due_date = isset($data['due_date']) ? $this->connect->real_escape_string($data['due_date']) : null;
            $lead = isset($data['lead']) ? $this->connect->real_escape_string($data['lead']) : null;
            $status = isset($data['status']) ? $this->connect->real_escape_string($data['status']) : null;
            $priority = isset($data['priority']) ? $this->connect->real_escape_string($data['priority']) : null;
            $completion = isset($data['completion']) ? $this->connect->real_escape_string($data['completion']) : null;
            $cost = isset($data['cost']) ? $this->connect->real_escape_string($data['cost']) : null;
            $supervision_level = isset($data['supervision_level']) ? $this->connect->real_escape_string($data['supervision_level']) : null;
            $description = isset($data['description']) ? $this->connect->real_escape_string($data['description']) : null;
            $remark = isset($data['remark']) ? $this->connect->real_escape_string($data['remark']) : null;
            $email = isset($data['email']) ? $this->connect->real_escape_string($data['email']) : null;

            
            $sql = "INSERT INTO projects(project_title, start_date, due_date, lead, status, priority, completion, cost, supervision_level, description, remark, email) VALUE('{$project_title}', '{$start_date}', '{$due_date}', '{$lead}', '{$status}', '{$priority}', '{$completion}', '{$cost}', '{$supervision_level}', '{$description}', '{$remark}', '{$email}')";
            $query = $this->connect->query($sql);
            return $query;
        }
        public function getProjects(){
            $sql = "SELECT * FROM projects";
            $query = $this->connect->query($sql);
            $data = [];
            while($row = $query->fetch_assoc()){
                array_push($data, $row);
            }
            return $data;
        }
        public function getProjectFiles($project_id){
            $sql = "SELECT * FROM project_files WHERE project_id = '$project_id'";
            $query = $this->connect->query($sql);
            $data = [];
            while($row = $query->fetch_assoc()){
                array_push($data, $row);
            }
            return $data;
        }
        
        public function saveWorkSiteTwo($data){
            // Initialize variables with default values if not set
            $description = isset($data['description']) ? $this->connect->real_escape_string(trim($data['description'])) : '';
            $delivery_date = isset($data['delivery_date']) ? $this->connect->real_escape_string(trim($data['delivery_date'])) : '';
            $done_percentage = isset($data['done_percentage']) ? $this->connect->real_escape_string(trim($data['done_percentage'])) : '';
            $work_in_progress = isset($data['work_in_progress']) ? $this->connect->real_escape_string(trim($data['work_in_progress'])) : '';
            $remark = isset($data['remark']) ? $this->connect->real_escape_string(trim($data['remark'])) : '';
            $address = isset($data['address']) ? $this->connect->real_escape_string(trim($data['address'])) : '';
            $action_party = isset($data['action_party']) ? $this->connect->real_escape_string(trim($data['action_party'])) : '';
            $action_close_date = isset($data['action_close_date']) ? $this->connect->real_escape_string(trim($data['action_close_date'])) : '';
            $next_step = isset($data['next_step']) ? $this->connect->real_escape_string(trim($data['next_step'])) : '';
            $period = isset($data['period']) ? $this->connect->real_escape_string(trim($data['period'])) : '';
            $challenge = isset($data['challenge']) ? $this->connect->real_escape_string(trim($data['challenge'])) : '';
            
            $columns = [
                'description' => 'LONGTEXT',
                'delivery_date' => 'VARCHAR(255)',
                'done_percentage' => 'VARCHAR(255)',
                'work_in_progress' => 'VARCHAR(255)',
                'remark' => 'LONGTEXT',
                'address' => 'VARCHAR(255)',
                'action_party' => 'VARCHAR(255)',
                'action_close_date' => 'VARCHAR(255)',
                'next_step' => 'VARCHAR(255)',
                'period' => 'VARCHAR(255)',
                'challenge' => 'VARCHAR(255)'
            ];
            $values = [
                $description, 
                $delivery_date, 
                $done_percentage, 
                $work_in_progress, 
                $remark, 
                $address, 
                $action_party, 
                $action_close_date, 
                $next_step, 
                $period, 
                $challenge
            ];
            $this->save('worksite_2', $columns, $values);
            return true;
        }
        public function updateWorkSiteTwo($data){
            // Assuming $data is your input array with keys as the column names
            $update_fields = [
                'description' => isset($data['description']) ? $this->connect->real_escape_string(trim($data['description'])) : '',
                'delivery_date' => isset($data['delivery_date']) ? $this->connect->real_escape_string(trim($data['delivery_date'])) : '',
                'done_percentage' => isset($data['done_percentage']) ? $this->connect->real_escape_string(trim($data['done_percentage'])) : '',
                'work_in_progress' => isset($data['work_in_progress']) ? $this->connect->real_escape_string(trim($data['work_in_progress'])) : '',
                'remark' => isset($data['remark']) ? $this->connect->real_escape_string(trim($data['remark'])) : '',
                'address' => isset($data['address']) ? $this->connect->real_escape_string(trim($data['address'])) : '',
                'action_party' => isset($data['action_party']) ? $this->connect->real_escape_string(trim($data['action_party'])) : '',
                'action_close_date' => isset($data['action_close_date']) ? $this->connect->real_escape_string(trim($data['action_close_date'])) : '',
                'next_step' => isset($data['next_step']) ? $this->connect->real_escape_string(trim($data['next_step'])) : '',
                'period' => isset($data['period']) ? $this->connect->real_escape_string(trim($data['period'])) : '',
                'challenge' => isset($data['challenge']) ? $this->connect->real_escape_string(trim($data['challenge'])) : ''
            ];
            
            $id = $this->connect->real_escape_string($data['id']); // Make sure to sanitize $id as well
            
            // Build the SQL query dynamically
            $update_query = "UPDATE worksite_2 SET ";
            
            $update_parts = [];
            foreach ($update_fields as $column => $value) {
                if (!empty($value)) { // Only include columns that have a value
                    $update_parts[] = "$column = '$value'";
                }
            }
            // Join the parts with commas
            $update_query .= implode(', ', $update_parts);
            $update_query .= " WHERE id = '$id'";
            // Execute the query
            if ($this->connect->query($update_query) === TRUE) {
                return true;
            } else {
                return false;
            }
        }

        // Audit

        public function saveAudit($data){
            $attribute = isset($data['attribute']) ? $this->connect->real_escape_string($data['attribute']) : null;
            $relevance = isset($data['relevance']) ? $this->connect->real_escape_string($data['relevance']) : null;
            $practice = isset($data['practice']) ? $this->connect->real_escape_string($data['practice']) : null;
            $assessment = isset($data['assessment']) ? $this->connect->real_escape_string($data['assessment']) : null;

            $result = $this->connect->query("SELECT MAX(order_num) AS max_order_num FROM project_audit");
            $row = $result->fetch_assoc();
            $maxOrderNum = $row['max_order_num'];

            $newOrderNum = $maxOrderNum !== null ? $maxOrderNum + 1 : 1;

            $sql = "INSERT INTO project_audit(attribute, relevance, practice, assessment, order_num) VALUE('{$attribute}', '{$relevance}', '{$practice}', '{$assessment}', '{$newOrderNum}')";
            $query = $this->connect->query($sql);
            return $query;
        }

        public function getAudit(){
            $sql = "SELECT * FROM project_audit";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        public function updateAudit($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $attribute = isset($data['attribute']) ? $this->connect->real_escape_string($data['attribute']) : null;
            $relevance = isset($data['relevance']) ? $this->connect->real_escape_string($data['relevance']) : null;
            $practice = isset($data['practice']) ? $this->connect->real_escape_string($data['practice']) : null;
            $assessment = isset($data['assessment']) ? $this->connect->real_escape_string($data['assessment']) : null;


            
            $sql = "UPDATE project_audit SET attribute = '$attribute', relevance = '$relevance', practice = '$practice', assessment = '$assessment' WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }


        public function deleteAudit($data){
            $id = $data['id'];
            $sql = "DELETE FROM project_audit WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function saveUnderAudit($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $attribute = isset($data['attribute']) ? $this->connect->real_escape_string($data['attribute']) : null;
            $relevance = isset($data['relevance']) ? $this->connect->real_escape_string($data['relevance']) : null;
            $practice = isset($data['practice']) ? $this->connect->real_escape_string($data['practice']) : null;
            $assessment = isset($data['assessment']) ? $this->connect->real_escape_string($data['assessment']) : null;

            $this->connect->query("UPDATE project_audit SET order_num = order_num + 1 WHERE id > '$id'");



            $result = $this->connect->query("SELECT order_num + 1 AS new_order_num FROM project_audit WHERE id = '$id'");
            $row = $result->fetch_assoc();
            $newOrderNum = $row['new_order_num'];

            $sql = "INSERT INTO project_audit(attribute, relevance, practice, assessment, order_num) VALUES ('{$attribute}', '{$relevance}', '{$practice}', '{$assessment}', '{$newOrderNum}')";
            $query = $this->connect->query($sql);

            return $query;
        }

        // Task Hazard

        public function saveTaskHard($data){
            $task_breakdown = isset($data['task_breakdown']) ? $this->connect->real_escape_string($data['task_breakdown']) : null;
            $hazard_threat = isset($data['hazard_threat']) ? $this->connect->real_escape_string($data['hazard_threat']) : null;
            $controls = isset($data['controls']) ? $this->connect->real_escape_string($data['controls']) : null;
            $responsible_person = isset($data['responsible_person']) ? $this->connect->real_escape_string($data['responsible_person']) : null;
            $controls_in_place = isset($data['controls_in_place']) ? $this->connect->real_escape_string($data['controls_in_place']) : null;

            $result = $this->connect->query("SELECT MAX(order_num) AS max_order_num FROM task_hazard");
            $row = $result->fetch_assoc();
            $maxOrderNum = $row['max_order_num'];

            $newOrderNum = $maxOrderNum !== null ? $maxOrderNum + 1 : 1;

            $sql = "INSERT INTO task_hazard(task_breakdown, hazard_threat, controls, responsible_person, controls_in_place, order_num) VALUE('{$task_breakdown}', '{$hazard_threat}', '{$controls}', '{$responsible_person}', '{$controls_in_place}', '{$newOrderNum}')";
            $query = $this->connect->query($sql);
            return $query;
        }

        public function getTaskHazard(){
            $sql = "SELECT * FROM task_hazard";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        public function updateTaskHazard($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $task_breakdown = isset($data['task_breakdown']) ? $this->connect->real_escape_string($data['task_breakdown']) : null;
            $hazard_threat = isset($data['hazard_threat']) ? $this->connect->real_escape_string($data['hazard_threat']) : null;
            $controls = isset($data['controls']) ? $this->connect->real_escape_string($data['controls']) : null;
            $responsible_person = isset($data['responsible_person']) ? $this->connect->real_escape_string($data['responsible_person']) : null;
            $controls_in_place = isset($data['controls_in_place']) ? $this->connect->real_escape_string($data['controls_in_place']) : null;


            
            $sql = "UPDATE task_hazard SET task_breakdown = '$task_breakdown', hazard_threat = '$hazard_threat', controls = '$controls', responsible_person = '$responsible_person', controls_in_place = '$controls_in_place' WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function deleteTaskHazard($data){
            $id = $data['id'];
            $sql = "DELETE FROM task_hazard WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function saveUnderTaskHazard($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;

            $task_breakdown = isset($data['task_breakdown']) ? $this->connect->real_escape_string($data['task_breakdown']) : null;
            $hazard_threat = isset($data['hazard_threat']) ? $this->connect->real_escape_string($data['hazard_threat']) : null;
            $controls = isset($data['controls']) ? $this->connect->real_escape_string($data['controls']) : null;
            $responsible_person = isset($data['responsible_person']) ? $this->connect->real_escape_string($data['responsible_person']) : null;
            $controls_in_place = isset($data['controls_in_place']) ? $this->connect->real_escape_string($data['controls_in_place']) : null;

            $this->connect->query("UPDATE task_hazard SET order_num = order_num + 1 WHERE id > '$id'");

            $result = $this->connect->query("SELECT order_num + 1 AS new_order_num FROM task_hazard WHERE id = '$id'");
            $row = $result->fetch_assoc();

            $newOrderNum = $row['new_order_num'];

            $sql = "INSERT INTO task_hazard(task_breakdown, hazard_threat, controls, responsible_person, controls_in_place, order_num) VALUE('{$task_breakdown}', '{$hazard_threat}', '{$controls}', '{$responsible_person}', '{$controls_in_place}', '{$newOrderNum}')";
            $query = $this->connect->query($sql);

            return $query;
        }


        // Risk Identification
        
        public function saveRiskIdentification($data){
            $facility_project = isset($data['facility_project']) ? $this->connect->real_escape_string($data['facility_project']) : null;
            $location = isset($data['location']) ? $this->connect->real_escape_string($data['location']) : null;
            $task = isset($data['task']) ? $this->connect->real_escape_string($data['task']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
            $time = isset($data['time']) ? $this->connect->real_escape_string($data['time']) : null;
            $ptw_no = isset($data['ptw_no']) ? $this->connect->real_escape_string($data['ptw_no']) : null;
            $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;
            $tbm_leader = isset($data['tbm_leader']) ? $this->connect->real_escape_string($data['tbm_leader']) : null;
            $permit_holder = isset($data['permit_holder']) ? $this->connect->real_escape_string($data['permit_holder']) : null;
            $project_supervisor = isset($data['project_supervisor']) ? $this->connect->real_escape_string($data['project_supervisor']) : null;
            $update_work = isset($data['update_work']) ? $this->connect->real_escape_string($data['update_work']) : null;
            $update_plans = isset($data['update_plans']) ? $this->connect->real_escape_string($data['update_plans']) : null;
            $feedback_others = isset($data['feedback_others']) ? $this->connect->real_escape_string($data['feedback_others']) : null;


            $image = '';
            if(isset($files['image'])){
                $upload_folder = "/home/oshea/public_html/backend/uploads/";
                $file = $files['image'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
            }

            $sql = "INSERT INTO risk_identification(facility_project, location, task, date, time, ptw_no, name,  tbm_leader, permit_holder, project_supervisor, update_work, update_plans, feedback_others, image ) VALUE('{$facility_project}', '{$location}', '{$task}', '{$date}', '{$time}', '{$ptw_no}', '{$name}', '{$tbm_leader}', '{$permit_holder}', '{$project_supervisor}', '{$update_work}', '{$update_plans}', '{$feedback_others}'), '{$image}') ";
            $query = $this->connect->query($sql);
            return $query;
        }

        public function getRiskIdentification(){
            $sql = "SELECT * FROM risk_identification";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        public function updateRiskIdentification($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $facility_project = isset($data['facility_project']) ? $this->connect->real_escape_string($data['facility_project']) : null;
            $location = isset($data['location']) ? $this->connect->real_escape_string($data['location']) : null;
            $task = isset($data['task']) ? $this->connect->real_escape_string($data['task']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
            $time = isset($data['time']) ? $this->connect->real_escape_string($data['time']) : null;
            $ptw_no = isset($data['ptw_no']) ? $this->connect->real_escape_string($data['ptw_no']) : null;
            $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;
            $tbm_leader = isset($data['tbm_leader']) ? $this->connect->real_escape_string($data['tbm_leader']) : null;
            $permit_holder = isset($data['permit_holder']) ? $this->connect->real_escape_string($data['permit_holder']) : null;
            $project_supervisor = isset($data['project_supervisor']) ? $this->connect->real_escape_string($data['project_supervisor']) : null;
            $update_work = isset($data['update_work']) ? $this->connect->real_escape_string($data['update_work']) : null;
            $update_plans = isset($data['update_plans']) ? $this->connect->real_escape_string($data['update_plans']) : null;
            $feedback_others = isset($data['feedback_others']) ? $this->connect->real_escape_string($data['feedback_others']) : null;



            
            $sql = "UPDATE risk_identification SET facility_project = '$facility_project', location = '$location', task = '$task', date = '$date', time = '$time', ptw_no = '$ptw_no', name = '$name', tbm_leader = '$tbm_leader', permit_holder = '$permit_holder', project_supervisor = '$project_supervisor', update_work = '$update_work', update_plans = '$update_plans', feedback_others = '$feedback_others' WHERE id = '$id'";
            
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function deleteRiskIdentification($data){
            $id = $data['id'];
            $sql = "DELETE FROM risk_identification WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }


        // Hazard/Risk Identification
        public function saveHazardRiskIdentification($data){
            $work_involve = isset($data['work_involve']) ? $this->connect->real_escape_string($data['work_involve']) : null;

            $sql = "INSERT INTO hazard_risk_identification(work_involve) VALUE('{$work_involve}') ";

            $query = $this->connect->query($sql);
            return $query;
        }

        public function getHazardRiskIdentification(){
            $sql = "SELECT * FROM hazard_risk_identification";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

        public function updateHazardRiskIdentification($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $work_involve = isset($data['work_involve']) ? $this->connect->real_escape_string($data['work_involve']) : null;

            $sql = "UPDATE hazard_risk_identification SET work_involve = '$work_involve' WHERE id = '$id'";
            
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function deleteHazardRiskIdentification($data){
            $id = $data['id'];
            $sql = "DELETE FROM hazard_risk_identification WHERE id = '$id'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        // Site ToolBox
        public function updateToolBox($data){
            $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
            $work_place = isset($data['work_place']) ? $this->connect->real_escape_string($data['work_place']) : null;
            $name_of_supervisor = isset($data['name_of_supervisor']) ? $this->connect->real_escape_string($data['name_of_supervisor']) : null;
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;
            $time = isset($data['time']) ? $this->connect->real_escape_string($data['time']) : null;

            $sql = "UPDATE toolbox_heading SET work_place = '$work_place', name_of_supervisor = '$name_of_supervisor', date = '$date', time = '$time' WHERE id = '$id'";
            
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }

        public function getToolBox(){
            $sql = "SELECT * FROM toolbox_heading";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }

            // Persons
            public function savePersons($data){
                $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;
    
                $image = '';
                if(isset($files['image'])){
                    $upload_folder = "/home/oshea/public_html/backend/uploads/";
                    $file = $files['image'];
                    $encrypted_name = uniqid(). '-' .$file['name'];
                    $directory = $upload_folder.$encrypted_name;
    
                    if(move_uploaded_file($file['tmp_name'], $directory)){
                        $image = $encrypted_name;
                    } else {
                        return false;
                    }
                }
    
                $sql = "INSERT INTO persons(name, signature) VALUE('{$name}', '{$image}') ";
    
                $query = $this->connect->query($sql);
                return $query;
            }
    
            public function getPersons(){
                $sql = "SELECT * FROM persons";
                $query = $this->connect->query($sql);
                if($query->num_rows > 0){
                    $data = [];
                    while($row = $query->fetch_assoc()){
                        array_push($data, $row);
                    }
                    return $data;
                }else{
                    return false;
                }
            }
    
            public function updatePersons($data){
                $id = isset($data['id']) ? $this->connect->real_escape_string($data['id']) : null;
                $name = isset($data['name']) ? $this->connect->real_escape_string($data['name']) : null;
    
                $sql = "UPDATE persons SET name = '$name' WHERE id = '$id'";
                
                $query = $this->connect->query($sql);
                if($query){
                    return true;
                }else{
                    return false;
                }
            }
    
            public function deletePersons($data){
                $id = $data['id'];
                $sql = "DELETE FROM persons WHERE id = '$id'";
                $query = $this->connect->query($sql);
                if($query){
                    return true;
                }else{
                    return false;
                }
            }

   
        //update stakeholder COMMUNICATION PLAN
        public function updateStakeComplan($data){

            $StakeholderComPlanId = isset($data['StakeholderComPlanId']) ? $this->connect->real_escape_string($data['StakeholderComPlanId']) : null;

            $projectTitle = isset($data['projectTitle']) ? $this->connect->real_escape_string($data['projectTitle']) : null;

            $datte = isset($data['datte']) ? $this->connect->real_escape_string($data['datte']) : null;
            
            $fileNo = isset($data['fileNo']) ? $this->connect->real_escape_string($data['fileNo']) : null;

            $datte2 = isset($data['datte2']) ? $this->connect->real_escape_string($data['datte2']) : null;

            $BidOppNo = isset($data['BidOppNo']) ? $this->connect->real_escape_string($data['BidOppNo']) : null;

            $stakeholder = isset($data['stakeholder']) ? $this->connect->real_escape_string($data['stakeholder']) : null;

            $Objective = isset($data['Objective']) ? $this->connect->real_escape_string($data['Objective']) : null;
            
            $Messages = isset($data['Messages']) ? $this->connect->real_escape_string($data['Messages']) : null;

            $Timing = isset($data['Timing']) ? $this->connect->real_escape_string($data['Timing']) : null;

            $deliveryMethod = isset($data['deliveryMethod']) ? $this->connect->real_escape_string($data['deliveryMethod']) : null;

            $byWho = isset($data['byWho']) ? $this->connect->real_escape_string($data['byWho']) : null;
            $FeedBackMechanism = isset($data['FeedBackMechanism']) ? $this->connect->real_escape_string($data['FeedBackMechanism']) : null;

            $description = isset($data['description']) ? $this->connect->real_escape_string($data['description']) : null;


            
            $sql = "UPDATE stakeholderComPlan_tbl SET projectTitle = '$projectTitle', datte = '$datte', fileNo = '$fileNo', datte2 = '$datte2', BidOppNo = '$BidOppNo', stakeholder = '$stakeholder', Objective = '$Objective', Messages = '$Messages', Timing = '$Timing', deliveryMethod = '$deliveryMethod', byWho = '$byWho', FeedBackMechanism = '$FeedBackMechanism', description = '$description' WHERE id = '$StakeholderComPlanId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //update stakeholder COMMUNICATION Ass
        public function updateStakeholder($data){
         

            $stakeholderId = isset($data['stakeholderId']) ? $this->connect->real_escape_string($data['stakeholderId']) : null;


            $projectTitle = isset($data['projectTitle']) ? $this->connect->real_escape_string($data['projectTitle']) : null;

            $description = isset($data['description']) ? $this->connect->real_escape_string($data['description']) : null;
            
            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $fileNo = isset($data['fileNo']) ? $this->connect->real_escape_string($data['fileNo']) : null;

            $BidOppNo = isset($data['BidOppNo']) ? $this->connect->real_escape_string($data['BidOppNo']) : null;

            $stakeholder = isset($data['stakeholder']) ? $this->connect->real_escape_string($data['stakeholder']) : null;

            $interestExpectations = isset($data['interestExpectations']) ? $this->connect->real_escape_string($data['interestExpectations']) : null;
            
            $importanceInfluence = isset($data['importanceInfluence']) ? $this->connect->real_escape_string($data['importanceInfluence']) : null;

            $assessmentOfImpact = isset($data['assessmentOfImpact']) ? $this->connect->real_escape_string($data['assessmentOfImpact']) : null;

            $strategySupport = isset($data['strategySupport']) ? $this->connect->real_escape_string($data['strategySupport']) : null;


            
            $sql = "UPDATE stakeholder_table SET project = '$projectTitle', description = '$description', date = '$date', fileNo = '$fileNo', BidOppNo = '$BidOppNo', stakeholder = '$stakeholder', intrestAndExpect = '$interestExpectations', impAndInfluence = '$importanceInfluence', assOfImp = '$assessmentOfImpact', strategyForSupport = '$strategySupport' WHERE id = '$stakeholderId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //update stakeholder Quality
        public function updateStakeholderQlt($data){
         
            $ScQualityDataId = isset($data['ScQualityDataId']) ? $this->connect->real_escape_string($data['ScQualityDataId']) : null;

            $docRevisionNo = isset($_POST['docRevisionNo']) ? $this->connect->real_escape_string($_POST['docRevisionNo']) : null;
            $changeInContent = isset($_POST['changeInContent']) ? $this->connect->real_escape_string($_POST['changeInContent']) : null;
            $dateReleased = isset($_POST['dateReleased']) ? $this->connect->real_escape_string($_POST['dateReleased']) : null;
            $releasedBy = isset($_POST['releasedBy']) ? $this->connect->real_escape_string($_POST['releasedBy']) : null;
            $documentRevisionNo = isset($_POST['documentRevisionNo']) ? $this->connect->real_escape_string($_POST['documentRevisionNo']) : null;
            $revisions = isset($_POST['revisions']) ? $this->connect->real_escape_string($_POST['revisions']) : null;
            $releasedDate = isset($_POST['releasedDateFinal']) ? $this->connect->real_escape_string($_POST['releasedDateFinal']) : null;
            $releasedByFinal = isset($_POST['releasedByFinal']) ? $this->connect->real_escape_string($_POST['releasedByFinal']) : null;
        
            
            $sql = "UPDATE ScQualityData_tbl SET docRevisionNo = '$docRevisionNo', changeInContent = '$changeInContent', dateReleased = '$dateReleased', releasedBy = '$releasedBy', documentRevisionNo = '$documentRevisionNo', revisions = '$revisions', datereleasedFinal = '$releasedDate', releasedByFinal = '$releasedByFinal' WHERE id = '$ScQualityDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
         //update stakeholder instruction
         public function updateScInstruction($data){
         
            $scInstructionDataId = isset($data['scInstructionDataId']) ? $this->connect->real_escape_string($data['scInstructionDataId']) : null;

            $Name = isset($_POST['Name']) ? $this->connect->real_escape_string($_POST['Name']) : null;
            $stakeHolderAss = isset($_POST['stakeHolderAss']) ? $this->connect->real_escape_string($_POST['stakeHolderAss']) : null;
        
            
            $sql = "UPDATE stakeHolderAss_table SET Name = '$Name', stakeHolderAss = '$stakeHolderAss' WHERE id = '$scInstructionDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //update RMP instruction
        public function updateRmpInstruction($data){
         
            $RmpInstructionId = isset($data['RmpInstructionId']) ? $this->connect->real_escape_string($data['RmpInstructionId']) : null;

            $Name = isset($_POST['Name']) ? $this->connect->real_escape_string($_POST['Name']) : null;
            $RmpInstruction = isset($_POST['RmpInstruction']) ? $this->connect->real_escape_string($_POST['RmpInstruction']) : null;
            
            $sql = "UPDATE RmpInstruction_table SET Name = '$Name', RmpInstruction = '$RmpInstruction' WHERE id = '$RmpInstructionId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //UPDATE RMP
        public function updateRmp($data){
                
            $RmpTemplateId = isset($data['RmpTemplateId']) ? $this->connect->real_escape_string($data['RmpTemplateId']) : null;

            $projectTitle = isset($_POST['projectTitle']) ? $this->connect->real_escape_string($_POST['projectTitle']) : null;

            $description = isset($_POST['description']) ? $this->connect->real_escape_string($_POST['description']) : null;

            $date = isset($_POST['date']) ? $this->connect->real_escape_string($_POST['date']) : null;

            $bizNo = isset($_POST['bizNo']) ? $this->connect->real_escape_string($_POST['bizNo']) : null;
            $BidOppNo = isset($_POST['BidOppNo']) ? $this->connect->real_escape_string($_POST['BidOppNo']) : null;
            $riskEvent = isset($_POST['riskEvent']) ? $this->connect->real_escape_string($_POST['riskEvent']) : null;
            $threatOpp = isset($_POST['threatOpp']) ? $this->connect->real_escape_string($_POST['threatOpp']) : null;
            $riskCause = isset($_POST['riskCause']) ? $this->connect->real_escape_string($_POST['riskCause']) : null;
            $UncertainEvent = isset($_POST['UncertainEvent']) ? $this->connect->real_escape_string($_POST['UncertainEvent']) : null;
            $riskSeverity = isset($_POST['riskSeverity']) ? $this->connect->real_escape_string($_POST['riskSeverity']) : null;
            $riskResponse = isset($_POST['riskResponse']) ? $this->connect->real_escape_string($_POST['riskResponse']) : null;
            $actionToTake = isset($_POST['actionToTake']) ? $this->connect->real_escape_string($_POST['actionToTake']) : null;
            $EfftObjectives = isset($_POST['EfftObjectives']) ? $this->connect->real_escape_string($_POST['EfftObjectives']) : null;
            $contingengyPlan = isset($_POST['contingengyPlan']) ? $this->connect->real_escape_string($_POST['contingengyPlan']) : null;
            $manageCost = isset($_POST['manageCost']) ? $this->connect->real_escape_string($_POST['manageCost']) : null;
            $riskOwner = isset($_POST['riskOwner']) ? $this->connect->real_escape_string($_POST['riskOwner']) : null;
            

            $sql = "UPDATE RmpTemplate_tabble
                SET 
                    project = '$projectTitle',
                    description = '$description',
                    date = '$date',
                    bizNo = '$bizNo',
                    BidOppNo = '$BidOppNo',
                    riskEvent = '$riskEvent',
                    threatOpp = '$threatOpp',
                    riskCause = '$riskCause',
                    UncertainEvent = '$UncertainEvent',
                    riskSeverity = '$riskSeverity',
                    riskResponse = '$riskResponse',
                    actionToTake = '$actionToTake',
                    EfftObjectives = '$EfftObjectives',
                    contingengyPlan = '$contingengyPlan',
                    manageCost = '$manageCost',
                    riskOwner = '$riskOwner'
                WHERE id = '$RmpTemplateId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
         //update RMP EX
        public function updateRmpEx($data){
                
            $RmpTemplateId = isset($data['RmpTemplateId']) ? $this->connect->real_escape_string($data['RmpTemplateId']) : null;

            $projectTitle = isset($_POST['projectTitle']) ? $this->connect->real_escape_string($_POST['projectTitle']) : null;

            $description = isset($_POST['description']) ? $this->connect->real_escape_string($_POST['description']) : null;

            $date = isset($_POST['date']) ? $this->connect->real_escape_string($_POST['date']) : null;

            $bizNo = isset($_POST['bizNo']) ? $this->connect->real_escape_string($_POST['bizNo']) : null;
            $BidOppNo = isset($_POST['BidOppNo']) ? $this->connect->real_escape_string($_POST['BidOppNo']) : null;
            $riskEvent = isset($_POST['riskEvent']) ? $this->connect->real_escape_string($_POST['riskEvent']) : null;
            $threatOpp = isset($_POST['threatOpp']) ? $this->connect->real_escape_string($_POST['threatOpp']) : null;
            $riskCause = isset($_POST['riskCause']) ? $this->connect->real_escape_string($_POST['riskCause']) : null;
            $UncertainEvent = isset($_POST['UncertainEvent']) ? $this->connect->real_escape_string($_POST['UncertainEvent']) : null;
            $riskSeverity = isset($_POST['riskSeverity']) ? $this->connect->real_escape_string($_POST['riskSeverity']) : null;
            $riskResponse = isset($_POST['riskResponse']) ? $this->connect->real_escape_string($_POST['riskResponse']) : null;
            $actionToTake = isset($_POST['actionToTake']) ? $this->connect->real_escape_string($_POST['actionToTake']) : null;
            $EfftObjectives = isset($_POST['EfftObjectives']) ? $this->connect->real_escape_string($_POST['EfftObjectives']) : null;
            $contingengyPlan = isset($_POST['contingengyPlan']) ? $this->connect->real_escape_string($_POST['contingengyPlan']) : null;
            $manageCost = isset($_POST['manageCost']) ? $this->connect->real_escape_string($_POST['manageCost']) : null;
            $riskOwner = isset($_POST['riskOwner']) ? $this->connect->real_escape_string($_POST['riskOwner']) : null;
            

            $sql = "UPDATE RmpTemplate_tabble_Ex
                SET 
                    project = '$projectTitle',
                    description = '$description',
                    date = '$date',
                    bizNo = '$bizNo',
                    BidOppNo = '$BidOppNo',
                    riskEvent = '$riskEvent',
                    threatOpp = '$threatOpp',
                    riskCause = '$riskCause',
                    UncertainEvent = '$UncertainEvent',
                    riskSeverity = '$riskSeverity',
                    riskResponse = '$riskResponse',
                    actionToTake = '$actionToTake',
                    EfftObjectives = '$EfftObjectives',
                    contingengyPlan = '$contingengyPlan',
                    manageCost = '$manageCost',
                    riskOwner = '$riskOwner'
                WHERE id = '$RmpTemplateId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //update RMP Quality
        public function updateRmpQlt($data){
         
            $RmpQTemplateDataId = isset($data['RmpQTemplateDataId']) ? $this->connect->real_escape_string($data['RmpQTemplateDataId']) : null;

            $docRevisionNo = isset($_POST['docRevisionNo']) ? $this->connect->real_escape_string($_POST['docRevisionNo']) : null;
            $changeInContent = isset($_POST['changeInContent']) ? $this->connect->real_escape_string($_POST['changeInContent']) : null;
            $dateReleased = isset($_POST['dateReleased']) ? $this->connect->real_escape_string($_POST['dateReleased']) : null;
            $releasedBy = isset($_POST['releasedBy']) ? $this->connect->real_escape_string($_POST['releasedBy']) : null;
            $documentRevisionNo = isset($_POST['documentRevisionNo']) ? $this->connect->real_escape_string($_POST['documentRevisionNo']) : null;
            $revisions = isset($_POST['revisions']) ? $this->connect->real_escape_string($_POST['revisions']) : null;
            $releasedDate = isset($_POST['releasedDateFinal']) ? $this->connect->real_escape_string($_POST['releasedDateFinal']) : null;
            $releasedByFinal = isset($_POST['releasedByFinal']) ? $this->connect->real_escape_string($_POST['releasedByFinal']) : null;
        
            
            $sql = "UPDATE RMPQualityData_table SET docRevisionNo = '$docRevisionNo', changeInContent = '$changeInContent', dateReleased = '$dateReleased', releasedBy = '$releasedBy', documentRevisionNo = '$documentRevisionNo', revisions = '$revisions', datereleasedFinal = '$releasedDate', releasedByFinal = '$releasedByFinal' WHERE id = '$RmpQTemplateDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
         //update FIELD info
        public function updateFieldInfo($data){
         
            $FieldInfoDataId = isset($data['FieldInfoDataId']) ? $this->connect->real_escape_string($data['FieldInfoDataId']) : null;

            $documentDate = isset($_POST['documentDate']) ? $this->connect->real_escape_string($_POST['documentDate']) : null;
            $fileNo = isset($_POST['fileNo']) ? $this->connect->real_escape_string($_POST['fileNo']) : null;
            $bidOppNo = isset($_POST['bidOppNo']) ? $this->connect->real_escape_string($_POST['bidOppNo']) : null;
            $priNo = isset($_POST['priNo']) ? $this->connect->real_escape_string($_POST['priNo']) : null;
            $distribution = isset($_POST['distribution']) ? $this->connect->real_escape_string($_POST['distribution']) : null;
            $issuedBy = isset($_POST['issuedBy']) ? $this->connect->real_escape_string($_POST['issuedBy']) : null;
            $reason = isset($_POST['reason']) ? $this->connect->real_escape_string($_POST['reason']) : null;
        
            
            $sql = "UPDATE FieldInfoData_table SET documentDate = '$documentDate', fileNo = '$fileNo', bidOppNo = '$bidOppNo', priNo = '$priNo', distribution = '$distribution', issuedBy = '$issuedBy', reason = '$reason' WHERE id = '$FieldInfoDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        //engrg correspondence data
        public function updateEngrData($data){

            $signature = '';
            if(isset($files['signature'])){
                $upload_folder = "/home/oshea/public_html/backend/uploads2/";
                $file = $files['signature'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
            }


         
            $EngnrDataId = isset($data['EngnrDataId']) ? $this->connect->real_escape_string($data['EngnrDataId']) : null;

            $From = isset($_POST['From']) ? $this->connect->real_escape_string($_POST['From']) : null;
            $To = isset($_POST['To']) ? $this->connect->real_escape_string($_POST['To']) : null;
            $Subject = isset($_POST['Subject']) ? $this->connect->real_escape_string($_POST['Subject']) : null;
            $Job_NO = isset($_POST['Job_NO']) ? $this->connect->real_escape_string($_POST['Job_NO']) : null;
            $Memo_NO = isset($data['Memo_NO']) ? $this->connect->real_escape_string($data['Memo_NO']) : null;
            $Date = isset($_POST['Date']) ? $this->connect->real_escape_string($_POST['Date']) : null;
            $Notes = isset($_POST['Notes']) ? $this->connect->real_escape_string($_POST['Notes']) : null;
            $signature = isset($_POST['signature']) ? $this->connect->real_escape_string($_POST['signature']) : null;
        
            
            $sql = "UPDATE EngnrData_tabble SET Fromm = '$From', Too= '$To', Subjectt = '$Subject', Job_NO = '$Job_NO', Memo_NO= '$Memo_NO', Datee = '$Date', Notes = '$Notes', Signature = '$signature' WHERE id = '$EngnrDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
      

    }


    



?>





