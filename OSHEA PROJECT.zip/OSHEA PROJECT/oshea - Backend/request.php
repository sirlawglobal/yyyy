<?php


error_reporting(E_ALL);           // Report all PHP errors
ini_set('display_errors', 1);     // Display errors on the page

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header("Access-Control-Allow-Headers: X-Requested-With");
    
    include('./config/Database.php');
    
    $db = new Database();
    
    if(isset($_GET['function'])){
        $function = $_GET['function'];
        
        if($function == "admin-login"){
            //login as an admin
            $user = $db->adminLogin($_POST['username'], $_POST['password']);
            if($user){
                echo json_encode(['user'=>$user]);
            }else{
                echo json_encode(['error'=>'Wrong username or password']);
            }
        }
        if($function == "save-contact"){
            //save contact
            $save = $db->saveContact($_POST);
            if($save){
                echo json_encode(['success'=>"Contact saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'update-contact'){
            $save = $db->updateContact($_POST);
            if($save){
                echo json_encode(['success'=>"Contact updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == "get-contacts"){
            //get contacts
            $contacts = $db->getContacts();
            if($contacts){
                echo json_encode(['contacts'=>$contacts]);
            }else{
                echo json_encode(['error'=>"No record found!"]);
            }
        }
        if($function == 'delete-contact'){
            $delete = $db->deleteContact($_POST);
            if($delete){
                echo json_encode(['success'=>"Contact deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'save-lead'){
            $save = $db->saveLead($_POST);
            if($save){
                echo json_encode(['success'=>"Lead saved!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'get-leads'){
            $leads = $db->getLeads();
            if($leads){
                echo json_encode(['leads'=>$leads]);
            }else{
                echo json_encode(['error'=>"No record found!"]);
            }
        }
        if($function == 'update-lead'){
            $save = $db->updateLead($_POST);
            if($save){
                echo json_encode(['success'=>"Lead updated!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'archive-lead'){
            $save = $db->archiveLead($_POST);
            if($save){
                echo json_encode(['success'=>"Lead archived!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'get-archives'){
            $archives = $db->getArchives();
            if($archives){
                echo json_encode(['archives'=>$archives]);
            }else{
                echo json_encode(['error'=>"No record found!"]);
            }
        }
        if($function == 'unarchive-lead'){
            $save = $db->unarchiveLead($_POST);
            if($save){
                echo json_encode(['success'=>"Lead unarchived!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'delete-archive'){
            $delete = $db->deleteArchive($_POST);
            if($delete){
                echo json_encode(['success'=>"Archive deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        if($function == 'delete-lead'){
            $delete = $db->deleteLead($_POST);
            if($delete){
                echo json_encode(['success'=>"Lead deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-activity-phase1
        if($function == 'save-activity-phase1'){
            $save = $db->saveActivityPhase1($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-activity-phase2
        if($function == 'save-activity-phase2'){
            $save = $db->saveActivityPhase2($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-activity-phase3
        if($function == 'save-activity-phase3'){
            $save = $db->saveActivityPhase3($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-activity-phase4
        if($function == 'save-activity-phase4'){
            $save = $db->saveActivityPhase4($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-activity-phase5
        if($function == 'save-activity-phase5'){
            $save = $db->saveActivityPhase5($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-planned-one
        if($function == 'save-planned-one'){
            $save = $db->savePlannedScope_1($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //save-planned-two
        if($function == 'save-planned-two'){
            $save = $db->savePlannedScope_2($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //update-activity-phase1
        if($function == 'update-activity-phase1'){
            $save = $db->updateActivityPhase1($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //update-activity-phase2
        if($function == 'update-activity-phase2'){
            $save = $db->updateActivityPhase2($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //update-activity-phase3
        if($function == 'update-activity-phase3'){
            $save = $db->updateActivityPhase3($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //update-activity-phase4
        if($function == 'update-activity-phase4'){
            $save = $db->updateActivityPhase4($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //update-activity-phase5
        if($function == 'update-activity-phase5'){
            $save = $db->updateActivityPhase5($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //get-activities
        if($function == 'get-activities'){
            $activities = $db->getActivities();
            echo json_encode($activities);
        }
        //delete-phase-one
        if($function == 'delete-phase-one'){
            $id = $_POST['id'];
            $delete = $db->delete('activity_phase_1',$id);
            echo json_encode(['success'=>'Item deleted!']);
        }
        //delete-phase-two
        if($function == 'delete-phase-two'){
            $id = $_POST['id'];
            $delete = $db->delete('activity_phase_2',$id);
            echo json_encode(['success'=>'Item deleted!']);
        }
        if($function == "delete-phase-four"){
            $id = $_POST['id'];
            $delete = $db->delete('activity_phase_4',$id);
            echo json_encode(['success'=>'Item deleted!']);
        }
        //save-project
        if($function == "save-project"){
            $save = $db->saveProject($_POST);
            if($save){
                echo json_encode(['success'=>"Success"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }
        //get-projects
        if($function == "get-projects"){
            $projects = $db->getProjects();
            echo json_encode(['projects'=>$projects]);
        }
        //upload-project-files
        if($function == "upload-project-files"){
            $project_id = $_POST['project_id'];
            $uploadDirectory = 'uploads/';
            foreach ($_FILES['files']['name'] as $key => $name) {
                $fileTmpName = $_FILES['files']['tmp_name'][$key];
                $fileExt = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                $newFileName = uniqid() . '.' . $fileExt;
                
                $destination = $uploadDirectory . $newFileName;
                if (move_uploaded_file($fileTmpName, $destination)) {
                    $sql = "INSERT INTO project_files(project_id, document_type, document_name) VALUES('{$project_id}', '{$fileExt}', '{$newFileName}')";
                    $db->query($sql);
                }
            }
            
            echo json_encode(['success'=>"Files uploaded successfully!"]);
        }
        if($function == "get-project-files"){
            $project_id = $_GET['project_id'];
            $files = $db->getProjectFiles($project_id);
            echo json_encode(['files'=>$files]);
        }
        if($function == "save-worksite-two"){
            $save = $db->saveWorkSiteTwo($_POST);
            if($save){
                echo json_encode(['success'=>"Data saved successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to save data"]);
            }
        }
        if($function == 'get-worksite-two'){
            $worksites = $db->get('worksite_2');
            echo json_encode(['worksites'=>$worksites]);
        }
        if($function == 'update-worksite-two'){
            $save = $db->updateWorkSiteTwo($_POST);
            if($save){
                echo json_encode(['success'=>"Data updated successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to update data"]);
            }
        }
        if($function == "delete-worksite-2"){
            $db->delete('worksite_2', $_POST['worksite_id']);
            echo json_encode(['success'=>"Data deleted successfully!"]); 
        }

        // Audit
        if($function == "save-audit"){
            $save = $db->saveAudit($_POST);
            if($save){
                echo json_encode(['success'=>"Data saved successfully!"]);
            }else{ 
                echo json_encode(['error'=>"Failed to save data"]);
            }
        }

            if($function == "get-audit"){
                $audit = $db->getAudit();
                if($audit){
                    echo json_encode(['audit'=>$audit]);
                }
    
            }

            if($function == 'update-audit'){
                $save = $db->updateAudit($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            if($function == 'delete-audit'){
                $save = $db->deleteAudit($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }
           

            if($function == "save-under-audit"){
                $save = $db->saveUnderAudit($_POST);
                if($save){
                    echo json_encode(['success'=>"Data saved successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to save data"]);
                }
            }

            // Task Hazard

            if($function == "save-task-hazard"){
                $save = $db->saveTaskHard($_POST);
                if($save){
                    echo json_encode(['success'=>"Data saved successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to save data"]);
                }
            }
           
            if($function == "get-task-hazard"){
                $task = $db->getTaskHazard();
                if($task){
                    echo json_encode(['task'=>$task]);
                }
    
            }

            if($function == 'update-task-hazard'){
                $save = $db->updateTaskHazard($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            if($function == 'delete-task-hazard'){
                $save = $db->deleteTaskHazard($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            if($function == "save-under-row-task-hazard"){
                $save = $db->saveUnderTaskHazard($_POST);
                if($save){
                    echo json_encode(['success'=>"Data saved successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to save data"]);
                }
            }

            // Risk Indentification
            if($function == "save-risk-identification"){
                $save = $db->saveRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data saved successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to save data"]);
                }
            }
            
            if($function == "get-risk-identification"){
                $risk = $db->getRiskIdentification();
                if($risk){
                    echo json_encode(['risk'=>$risk]);
                }
            }

            if($function == 'update-risk-identification'){
                $save = $db->updateRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            if($function == 'delete-risk-identification'){
                $save = $db->deleteRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            // Hazard/Risk Identification
            if($function == "save-hazard-risk-identification"){
                $save = $db->saveHazardRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data saved successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to save data"]);
                }
            }

            if($function == "get-hazard-risk-identification"){
                $risk = $db->getHazardRiskIdentification();
                if($risk){
                    echo json_encode(['risk'=>$risk]);
                }
            }

            if($function == 'update-hazard-risk-identification'){
                $save = $db->updateHazardRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            if($function == 'delete-hazard-risk-identification'){
                $save = $db->deleteHazardRiskIdentification($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            // Site toolkit
            if($function == 'update-toolbox'){
                $toolbox = $db->updateToolBox($_POST);
                if($toolbox){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            
            if($function == "get-toolbox"){
                $toolbox = $db->getToolBox();
                if($toolbox){
                    echo json_encode(['toolbox'=>$toolbox]);
                }
            }

                        // Persons 
                        if($function == "save-persons"){
                            $save = $db->savePersons($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data saved successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to save data"]);
                            }
                        }
            
                        if($function == "get-persons"){
                            $persons = $db->getPersons();
                            if($persons){
                                echo json_encode(['persons'=>$persons]);
                            }
                        }
            
                        if($function == 'update-persons'){
                            $save = $db->updatePersons($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data updated successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to update data"]);
                            }
                        }
            
                        if($function == 'delete-persons'){
                            $save = $db->deletePersons($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data updated successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to update data"]);
                            }
                        }

                        // Meeting Agenda
                        if($function == "save-meeting-agenda"){
                            $save = $db->saveMeetingAgenda($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data saved successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to save data"]);
                            }
                        }

                        if($function == "get-meeting-agenda"){
                            $meeting = $db->getMeetingAgenda();
                            if($meeting){
                                echo json_encode(['meeting'=>$meeting]);
                            }
                        }

                        if($function == 'update-meeting-agenda'){
                            $save = $db->updateMeeting($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data updated successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to update data"]);
                            }
                        }

                        if($function == 'delete-meeting-agenda'){
                            $save = $db->deleteMeetingAgenda($_POST);
                            if($save){
                                echo json_encode(['success'=>"Data updated successfully!"]);
                            }else{ 
                                echo json_encode(['error'=>"Failed to update data"]);
                            }
                        }


            



            

                //STAKEHOLDER COMMUNICATION ASSESSMENT
            if($function == "save-stakeholder"){

                    $values = [
                        isset($_POST['projectTitle']) ? $db->real_escape($_POST['projectTitle']) : null,
                        isset($_POST['description']) ? $db->real_escape($_POST['description']) : null,
                        isset($_POST['date']) ? $db->real_escape($_POST['date']) : null,
                        isset($_POST['fileNo']) ? $db->real_escape($_POST['fileNo']) : null,
                        isset($_POST['BidOppNo']) ? $db->real_escape($_POST['BidOppNo']) : null,
                        isset($_POST['stakeholder']) ? $db->real_escape($_POST['stakeholder']) : null,
                        isset($_POST['interestExpectations']) ? $db->real_escape($_POST['interestExpectations']) : null,  
                        isset($_POST['importanceInfluence']) ? $db->real_escape($_POST['importanceInfluence']) : null,  
                        isset($_POST['assessmentOfImpact']) ? $db->real_escape($_POST['assessmentOfImpact']) : null,  
                        isset($_POST['strategySupport']) ? $db->real_escape($_POST['strategySupport']) : null  
                    ];

                    $columns = [
                        'project' => 'LONGTEXT',
                        'description' => 'VARCHAR(255)',
                        'date' => 'VARCHAR(255)',
                        'fileNo' => 'VARCHAR(255)',
                        'BidOppNo' => 'VARCHAR(255)',
                        'stakeholder' => 'LONGTEXT',
                        'intrestAndExpect' => 'VARCHAR(255)', 
                        'impAndInfluence' => 'VARCHAR(255)', 
                        'assOfImp' => 'VARCHAR(255)',
                        'strategyForSupport' => 'VARCHAR(255)'
                    ];

                    $save=$db->save('stakeholder_table', $columns, $values);

                    if ($save) {
                        echo json_encode(['save' => 'success']);
                    } else {
                        $errorMessage = $db->error; 
                        error_log($errorMessage); 
                        echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                    }
            }
            if($function == "get-stakeholder"){
                    $stakeholderData = $db->get('stakeholder_table');
                    echo json_encode(['stakeholderData'=>$stakeholderData]);
            }
            if($function == 'delete-stakeholderData'){
                    $delete = $db->delete('stakeholder_table',$_POST['stakeholderId']);
                    echo json_encode(['success'=>'Item deleted!']);
            }
            if($function == 'update-stakeholder'){

                $save = $db->updateStakeholder($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }


            //STAKEHOLDER COMMUNICATION PLAN
            if($function == "save-stakeholderplan"){
            
                    // isset($_POST['fileNo']) ? $db->real_escape($_POST['fileNo']) : null;

                $values = [
                    isset($_POST['projectTitle']) ? $db->real_escape($_POST['projectTitle']) : null,
                    isset($_POST['datte']) ? $db->real_escape($_POST['datte']) : null,
                    isset($_POST['fileNo']) ? $db->real_escape($_POST['fileNo']) : null,
                    isset($_POST['datte2']) ? $db->real_escape($_POST['datte2']) : null,
                    isset($_POST['BidOppNo']) ? $db->real_escape($_POST['BidOppNo']) : null,
                    isset($_POST['stakeholder']) ? $db->real_escape($_POST['stakeholder']) : null,
                    isset($_POST['Objective']) ? $db->real_escape($_POST['Objective']) : null,  
                    isset($_POST['Messages']) ? $db->real_escape($_POST['Messages']) : null,  
                    isset($_POST['Timing']) ? $db->real_escape($_POST['Timing']) : null,  
                    isset($_POST['deliveryMethod']) ? $db->real_escape($_POST['deliveryMethod']) : null,  
                    isset($_POST['byWho']) ? $db->real_escape($_POST['byWho']) : null ,
                    isset($_POST['FeedBackMechanism']) ? $db->real_escape($_POST['FeedBackMechanism']) : null , 
                    isset($_POST['description']) ? $db->real_escape($_POST['description']) : null
                ];
            
                $columns = [
                    'projectTitle' => 'LONGTEXT',
                    'datte' => 'VARCHAR(255)',
                    'fileNo' => 'VARCHAR(255)',
                    'datte2' => 'VARCHAR(255)',
                    'BidOppNo' => 'VARCHAR(255)',
                    'stakeholder' => 'LONGTEXT',
                    'Objective' => 'VARCHAR(255)', 
                    'Messages' => 'VARCHAR(255)', 
                    'Timing' => 'VARCHAR(255)',
                    'deliveryMethod' => 'VARCHAR(255)',
                    'byWho' => 'VARCHAR(255)',
                    'FeedBackMechanism' => 'VARCHAR(255)',
                    'description' => 'VARCHAR(255)'
                ];
            
                $save=$db->save('stakeholderComPlan_tbl', $columns, $values);
            
                if ($save) {
                    echo json_encode(['save' => 'success', $_POST]);
                } else {
                    $errorMessage = $db->error; 
                    error_log($errorMessage); 
                    echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                }
            }
            if($function == "get-stakeholderplan"){ 
                $StakeholderComPlanData = $db->get('stakeholderComPlan_tbl');
                if( $StakeholderComPlanData){
                    echo json_encode(['StakeholderComPlanData'=>$StakeholderComPlanData]);
                }
                else{
                    echo json_encode(['error'=>'there was an error']);
                }
            }
            if($function == 'delete-stakeholderplan'){
                $delete = $db->delete('stakeholderComPlan_tbl',$_POST['StakeholderComPlanId']);
                echo json_encode(['success'=>'Item deleted!']);
            }
            if($function == 'update-stakeholderplan'){

                $save = $db->updateStakeComplan($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }
            

            //saving sc DOCUMENT QUALITY  data
              // update-ScQualityData
            if($function == "save-ScQualityData"){

                $values = [
                    $docRevisionNo = isset($_POST['docRevisionNo']) ? $db->real_escape($_POST['docRevisionNo']) : null,
                    $changeInContent = isset($_POST['changeInContent']) ? $db->real_escape($_POST['changeInContent']) : null,
                    $dateReleased = isset($_POST['dateReleased']) ? $db->real_escape($_POST['dateReleased']) : null,
                    $releasedBy = isset($_POST['releasedBy']) ? $db->real_escape($_POST['releasedBy']) : null,
                    $documentRevisionNo = isset($_POST['documentRevisionNo']) ? $db->real_escape($_POST['documentRevisionNo']) : null,
                    $revisions = isset($_POST['revisions']) ? $db->real_escape($_POST['revisions']) : null,
                    $releasedDate = isset($_POST['releasedDateFinal']) ? $db->real_escape($_POST['releasedDateFinal']) : null,
                    $releasedByFinal = isset($_POST['releasedByFinal']) ? $db->real_escape($_POST['releasedByFinal']) : null
                ];
            
                $columns = [
                    'docRevisionNo' => 'LONGTEXT',
                    'changeInContent' => 'VARCHAR(255)',
                    'dateReleased' => 'VARCHAR(255)',
                    'releasedBy' => 'VARCHAR(255)',
                    'revisions' => 'VARCHAR(255)',
                    'documentRevisionNo' => 'VARCHAR(255)',
                    'datereleasedFinal' => 'VARCHAR(255)',
                    'releasedByFinal' => 'VARCHAR(255)'
                ];
            
                $save=$db->save('ScQualityData_tbl', $columns, $values);
            
                if ($save) {
                    echo json_encode(['save' => 'success', $_POST]);
                } else {
                    $errorMessage = $db->error; 
                    error_log($errorMessage); 
                    echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                }
            
            }

            if($function == "get-ScQualityData"){
                $ScQualityData = $db->get('ScQualityData_tbl');
                if( $ScQualityData){
                    echo json_encode(['ScQualityData'=>$ScQualityData]);
                }
                else{
                    echo json_encode(['error'=>'there was an error']);
                }
            }
            if($function == 'delete-ScQualityData'){
                $delete = $db->delete('ScQualityData_tbl',$_POST['ScQualityDataId']);
                echo json_encode(['success'=>'Item deleted!']);
            }

            if($function == 'update-ScQualityData'){

                $save = $db->updateStakeholderQlt($_POST);
                if($save){
                    echo json_encode(['success'=>"Data updated successfully!"]);
                }else{ 
                    echo json_encode(['error'=>"Failed to update data"]);
                }
            }

            //StakeHOLDER INstruction
            // update-scInstructionData
            if($function == "save-scInstructionData"){

                $values = [
                            $docRevisionNo = isset($_POST['Name']) ? $db->real_escape($_POST['Name']) : "",
                            $changeInContent = isset($_POST['stakeHolderAss']) ? $db->real_escape($_POST['stakeHolderAss']) : null
                ];
                   $columns = [
                       'Name' => 'LONGTEXT',
                       'stakeHolderAss' => 'LONGTEXT'
                   ];

               
               $save=$db->save('stakeHolderAss_table', $columns, $values);
               
                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }
           if($function == "get-scInstructionData"){

            $ScInstructionData = $db->get('stakeHolderAss_table');
            
            if( $ScInstructionData){
                echo json_encode(['ScInstructionData'=>$ScInstructionData]);
            }
            else{
                echo json_encode(['error'=>'there was an error']);
            }

         }
            if($function == 'delete-scInstructionData'){
                    $delete = $db->delete('stakeHolderAss_table',$_POST['scInstructionDataId']);
                    echo json_encode(['success'=>'Item deleted!']);
            }

            if($function == "update-scInstructionData"){

                $save = $db->updateScInstruction($_POST);

                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }
           
           

            //RMPTEMPLATE Ordinary
            if($function == "save-RmpTemplate"){

                $values = [
                    isset($_POST['projectTitle']) ? $db->real_escape($_POST['projectTitle']) : null,
                    isset($_POST['description']) ? $db->real_escape($_POST['description']) : null,
                    isset($_POST['date']) ? $db->real_escape($_POST['date']) : null,
                    isset($_POST['bizNo']) ? $db->real_escape($_POST['bizNo']) : null,
                    isset($_POST['BidOppNo']) ? $db->real_escape($_POST['BidOppNo']) : null,
                    isset($_POST['riskEvent']) ? $db->real_escape($_POST['riskEvent']) : null,
                    isset($_POST['threatOpp']) ? $db->real_escape($_POST['threatOpp']) : null,
                    isset($_POST['riskCause']) ? $db->real_escape($_POST['riskCause']) : null,
                    isset($_POST['UncertainEvent']) ? $db->real_escape($_POST['UncertainEvent']) : null,
                    isset($_POST['riskSeverity']) ? $db->real_escape($_POST['riskSeverity']) : null,
                    isset($_POST['riskResponse']) ? $db->real_escape($_POST['riskResponse']) : null,
                    isset($_POST['actionToTake']) ? $db->real_escape($_POST['actionToTake']) : null,
                    isset($_POST['EfftObjectives']) ? $db->real_escape($_POST['EfftObjectives']) : null,
                    isset($_POST['contingengyPlan']) ? $db->real_escape($_POST['contingengyPlan']) : null,
                    isset($_POST['manageCost']) ? $db->real_escape($_POST['manageCost']) : null,
                    isset($_POST['riskOwner']) ? $db->real_escape($_POST['riskOwner']) : null
                ];

                $columns = [
                    'project' => 'LONGTEXT',
                    'description' => 'VARCHAR(255)',
                    'date' => 'VARCHAR(255)',
                    'bizNo' => 'VARCHAR(255)',
                    'BidOppNo' => 'VARCHAR(255)',
                    'riskEvent' => 'LONGTEXT',
                    'threatOpp' => 'VARCHAR(255)',
                    'riskCause' => 'VARCHAR(255)',
                    'UncertainEvent' => 'VARCHAR(255)',
                    'riskSeverity' => 'VARCHAR(255)',
                    'riskResponse' => 'VARCHAR(255)',
                    'actionToTake' => 'VARCHAR(255)',
                    'EfftObjectives' => 'VARCHAR(255)',
                    'contingengyPlan' => 'VARCHAR(255)',
                    'manageCost' => 'VARCHAR(255)',
                    'riskOwner' => 'VARCHAR(255)'
                ];

                $save =  $db->save('RmpTemplate_tabble', $columns, $values);

                if( $save){
                    echo json_encode(['save'=>'success']);
                }
                else{
                    echo json_encode(['error'=>'there was an error']);
                }
                
            }
            if($function == "get-RmpTemplate"){
                $RmpTemplateData = $db->get('RmpTemplate_tabble');
                echo json_encode(['RmpTemplateData'=>$RmpTemplateData]);
            }
            if($function == 'delete-RmpTemplate'){
                $delete = $db->delete('RmpTemplate_tabble',$_POST['RmpTemplateId']);
                echo json_encode(['success'=>'Item deleted!']);
            }
            if($function == "upadte-RmpTemplate"){

                $save = $db->updateRmp($_POST);

                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }

            //RMPTEMPLATE EX
            if($function == "save-RmpTemplateEx"){

                $values = [
                    isset($_POST['projectTitle']) ? $db->real_escape($_POST['projectTitle']) : null,
                    isset($_POST['description']) ? $db->real_escape($_POST['description']) : null,
                    isset($_POST['date']) ? $db->real_escape($_POST['date']) : null,
                    isset($_POST['bizNo']) ? $db->real_escape($_POST['bizNo']) : null,
                    isset($_POST['BidOppNo']) ? $db->real_escape($_POST['BidOppNo']) : null,
                    isset($_POST['riskEvent']) ? $db->real_escape($_POST['riskEvent']) : null,
                    isset($_POST['threatOpp']) ? $db->real_escape($_POST['threatOpp']) : null,
                    isset($_POST['riskCause']) ? $db->real_escape($_POST['riskCause']) : null,
                    isset($_POST['UncertainEvent']) ? $db->real_escape($_POST['UncertainEvent']) : null,
                    isset($_POST['riskSeverity']) ? $db->real_escape($_POST['riskSeverity']) : null,
                    isset($_POST['riskResponse']) ? $db->real_escape($_POST['riskResponse']) : null,
                    isset($_POST['actionToTake']) ? $db->real_escape($_POST['actionToTake']) : null,
                    isset($_POST['EfftObjectives']) ? $db->real_escape($_POST['EfftObjectives']) : null,
                    isset($_POST['contingengyPlan']) ? $db->real_escape($_POST['contingengyPlan']) : null,
                    isset($_POST['manageCost']) ? $db->real_escape($_POST['manageCost']) : null,
                    isset($_POST['riskOwner']) ? $db->real_escape($_POST['riskOwner']) : null
                ];

                $columns = [
                    'project' => 'LONGTEXT',
                    'description' => 'VARCHAR(255)',
                    'date' => 'VARCHAR(255)',
                    'bizNo' => 'VARCHAR(255)',
                    'BidOppNo' => 'VARCHAR(255)',
                    'riskEvent' => 'LONGTEXT',
                    'threatOpp' => 'VARCHAR(255)',
                    'riskCause' => 'VARCHAR(255)',
                    'UncertainEvent' => 'VARCHAR(255)',
                    'riskSeverity' => 'VARCHAR(255)',
                    'riskResponse' => 'VARCHAR(255)',
                    'actionToTake' => 'VARCHAR(255)',
                    'EfftObjectives' => 'VARCHAR(255)',
                    'contingengyPlan' => 'VARCHAR(255)',
                    'manageCost' => 'VARCHAR(255)',
                    'riskOwner' => 'VARCHAR(255)'
                ];

                $save =  $db->save('RmpTemplate_tabble_Ex', $columns, $values);

                if( $save){
                    echo json_encode(['save'=>'success']);
                }
                else{
                    echo json_encode(['error'=>'there was an error']);
                }
                
            }
            if($function == "get-RmpTemplateEx"){
                $RmpTemplateExData = $db->get('RmpTemplate_tabble_Ex');
                echo json_encode(['RmpTemplateExData'=>$RmpTemplateExData ]);
            }
            if($function == 'delete-RmpTemplateEx'){
                $delete = $db->delete('RmpTemplate_tabble_Ex',$_POST['RmpTemplateId']);
                echo json_encode(['success'=>'Item deleted!']);
            }

            if($function == "update-RmpTemplateEx"){

                $save = $db->updateRmpEx($_POST);

                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }

            //RMP QUALITY 
            if($function == "save-RmpQTemplateData"){

                $values = [
                    $docRevisionNo = isset($_POST['docRevisionNo']) ? $db->real_escape($_POST['docRevisionNo']) : null,
                    $changeInContent = isset($_POST['changeInContent']) ? $db->real_escape($_POST['changeInContent']) : null,
                    $dateReleased = isset($_POST['dateReleased']) ? $db->real_escape($_POST['dateReleased']) : null,
                    $releasedBy = isset($_POST['releasedBy']) ? $db->real_escape($_POST['releasedBy']) : null,
                    $documentRevisionNo = isset($_POST['documentRevisionNo']) ? $db->real_escape($_POST['documentRevisionNo']) : null,
                    $revisions = isset($_POST['revisions']) ? $db->real_escape($_POST['revisions']) : null,
                    $releasedDate = isset($_POST['releasedDateFinal']) ? $db->real_escape($_POST['releasedDateFinal']) : null,
                    $releasedByFinal = isset($_POST['releasedByFinal']) ? $db->real_escape($_POST['releasedByFinal']) : null
                ];
                
                $columns = [
                    'docRevisionNo' => 'LONGTEXT',
                    'changeInContent' => 'VARCHAR(255)',
                    'dateReleased' => 'VARCHAR(255)',
                    'releasedBy' => 'VARCHAR(255)',
                    'revisions' => 'VARCHAR(255)',
                    'documentRevisionNo' => 'VARCHAR(255)',
                    'datereleasedFinal' => 'VARCHAR(255)',
                    'releasedByFinal' => 'VARCHAR(255)'
                ];
                
                $save=$db->save('RMPQualityData_table', $columns, $values);
                
                    if ($save) {
                        echo json_encode(['save' => 'success', $_POST]);
                    } else {
                        $errorMessage = $db->error; 
                        error_log($errorMessage); 
                        echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                    }
                
            }
            if($function == "get-RmpQTemplateData"){
                    $RmpQTemplateData = $db->get('RMPQualityData_table');
                    if( $RmpQTemplateData){
                        echo json_encode(['RmpQTemplateData'=>$RmpQTemplateData]);
                    }
                    else{
                        echo json_encode(['error'=>'there was an error']);
                    }
            }
            if($function == 'delete-RmpQTemplateData'){
                    $delete = $db->delete('RMPQualityData_table',$_POST['RmpQTemplateDataId']);
                    echo json_encode(['success'=>'Item deleted!']);
            }
            if($function == "update-RmpQTemplateData"){

                $save = $db->updateRmpQlt($_POST);
                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }

            //Field informstion.
            if($function == "save-FieldInfoData"){

                 $values = [
                        $documentDate = isset($_POST['documentDate']) ? $db->real_escape($_POST['documentDate']) : null,
                        $fileNo = isset($_POST['fileNo']) ? $db->real_escape($_POST['fileNo']) : null,
                        $bidOppNo = isset($_POST['bidOppNo']) ? $db->real_escape($_POST['bidOppNo']) : null,
                        $priNo = isset($_POST['priNo']) ? $db->real_escape($_POST['priNo']) : null,
                        $distribution = isset($_POST['distribution']) ? $db->real_escape($_POST['distribution']) : null,
                        $issuedBy = isset($_POST['issuedBy']) ? $db->real_escape($_POST['issuedBy']) : null,
                        $reason = isset($_POST['reason']) ? $db->real_escape($_POST['reason']) : null
                ];
                
                    $columns = [
                        'documentDate' => 'LONGTEXT',
                        'fileNo' => 'VARCHAR(255)',
                        'bidOppNo' => 'VARCHAR(255)',
                        'priNo' => 'VARCHAR(255)',
                        'distribution' => 'VARCHAR(255)',
                        'issuedBy' => 'LONGTEXT',
                        'reason' => 'VARCHAR(255)'
                    ];
                
                $save=$db->save('FieldInfoData_table', $columns, $values);
                
                    if ($save) {
                        echo json_encode(['save' => 'success', $_POST]);
                    } else {
                        $errorMessage = $db->error; 
                        error_log($errorMessage); 
                        echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                    }
                
            }
            if($function == "get-FieldInfoData"){

                    $FieldInfoData = $db->get('FieldInfoData_table');
                    if( $FieldInfoData){
                        echo json_encode(['FieldInfoData'=>$FieldInfoData]);
                    }
                    else{
                        echo json_encode(['error'=>'there was an error']);
                    }
            }
            if($function == 'delete-FieldInfoData'){
                    $delete = $db->delete('FieldInfoData_table',$_POST['FieldInfoDataId']);
                    echo json_encode(['success'=>'Item deleted!']);
            }
            if($function == "update-FieldInfoData"){

                $save = $db->updateFieldInfo($_POST);
                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
           }


            

            //RMP INstruction
            if($function == "save-RmpInstructionData"){

                $values = [
                            $docRevisionNo = isset($_POST['Name']) ? $db->real_escape($_POST['Name']) : "",
                            $changeInContent = isset($_POST['RmpInstruction']) ? $db->real_escape($_POST['RmpInstruction']) : null
                ];
                   $columns = [
                       'Name' => 'LONGTEXT',
                       'RmpInstruction' => 'LONGTEXT'
                   ];

               
               $save=$db->save('RmpInstruction_table', $columns, $values);
               
                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
        }

           if($function == "get-RmpInstructionData"){

            $RmpInstructionData = $db->get('RmpInstruction_table');
            
            if( $RmpInstructionData){
                echo json_encode(['RmpInstructionData'=>$RmpInstructionData]);
            }
            else{
                echo json_encode(['error'=>'there was an error']);
            }

        }
            if($function == 'delete-RmpInstructionData'){
                    $delete = $db->delete('RmpInstruction_table',$_POST['RmpInstructionId']);
                    echo json_encode(['success'=>'Item deleted!']);
        }

            if($function == "update-RmpInstructionData"){

                $save = $db->updateRmpInstruction($_POST);

                   if ($save) {
                       echo json_encode(['save' => 'success', $_POST]);
                   } else {
                       $errorMessage = $db->error; 
                       error_log($errorMessage); 
                       echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                   }
               
        }


                // Engineering corresponse
            if($function == "save-EngrData"){

                    $signature = '';
                    if(isset($files['signature'])){
                        $upload_folder = "/home/oshea/public_html/backend/uploads2/";
                        $file = $files['signature'];
                        $encrypted_name = uniqid(). '-' .$file['name'];
                        $directory = $upload_folder.$encrypted_name;

                        if(move_uploaded_file($file['tmp_name'], $directory)){
                            $image = $encrypted_name;
                        } else {
                            return false;
                        }
                    }

                    $values = [
                        $From = isset($_POST['From']) ? $db->connect->real_escape_string($_POST['From']) : null,
                        $To = isset($_POST['To']) ? $db->connect->real_escape_string($_POST['To']) : null,
                        $Subject = isset($_POST['Subject']) ? $db->connect->real_escape_string($_POST['Subject']) : null,
                        $Job_NO = isset($_POST['Job_NO']) ? $db->connect->real_escape_string($_POST['Job_NO']) : null,
                        $Memo_NO = isset($_POST['Memo_NO']) ? $db->connect->real_escape_string($_POST['Memo_NO']) : null,
                        $Date = isset($_POST['Date']) ? $db->connect->real_escape_string($_POST['Date']) : null,
                        $Notes = isset($_POST['Notes']) ? $db->connect->real_escape_string($_POST['Notes']) : null,
                        $signature = isset($_POST['signature']) ? $db->connect->real_escape_string($_POST['signature']) : null
                    ];
                    $columns = [
                        'Fromm' => 'LONGTEXT',
                        'Too' => 'VARCHAR(255)',
                        'Subjectt' => 'VARCHAR(255)',
                        'Job_NO' => 'VARCHAR(255)',
                        'Memo_NO' => 'VARCHAR(255)',
                        'Datee' => 'LONGTEXT',
                        'Notes' => 'VARCHAR(255)',
                        'Signature' => 'VARCHAR(255)'

                    ];
                
                $save=$db->save('EngnrData_tabble', $columns, $values);
                
                    if ($save) {
                        echo json_encode(['save' => 'success', $_POST]);
                    } else {
                        $errorMessage = $db->error; 
                        error_log($errorMessage); 
                        echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                    }
                
            }
            if($function == "get-EngrData"){    

                $EngnrData = $db->get('EngnrData_tabble');
                
                if( $EngnrData){
                    echo json_encode(['EngnrData'=>$EngnrData]);
                }
                else{
                    echo json_encode(['error'=>'there was an error']);
                }
            }
            if($function == "update-EngrData"){

                $save = $db-> updateEngrData($_POST);
                if ($save) {
                    echo json_encode(['save' => 'success', $_POST]);
                } else {
                    $errorMessage = $db->error; 
                    error_log($errorMessage); 
                    echo json_encode(['error' => 'Database error: ' . $errorMessage]);
                }
            
        }

            if($function == 'delete-EngnrData'){

                $delete = $db->delete('EngnrData_tabble',$_POST['EngnrDataId']);
                echo json_encode(['success'=>'Item deleted!']);
            }
            
        










    
    }

    
        

?>