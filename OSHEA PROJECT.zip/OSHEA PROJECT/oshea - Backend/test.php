<?php
//  ENGINEERING CORRESPONDENCE
            if($function == "save-EngrData"){
                    $values = [
                        isset($_POST['From']) ? $db->real_escape($_POST['From']) : null,
                        isset($_POST['To']) ? $db->real_escape($_POST['To']) : null,
                        isset($_POST['Subject']) ? $db->real_escape($_POST['Subject']) : null,
                        isset($_POST['Job_NO']) ? $db->real_escape($_POST['Job_NO']) : null,
                        isset($_POST['Memo_NO']) ? $db->real_escape($_POST['Memo_NO']) : null,
                        isset($_POST['Date']) ? $db->real_escape($_POST['Date']) : null,
                        isset($_POST['Notes']) ? $db->real_escape($_POST['Notes']) : null,
                    ];

                    $columns = [
                        'Fromm' => 'LONGTEXT',
                        'Too' => 'VARCHAR(255)',
                        'Subjectt' => 'VARCHAR(255)',
                        'Job_NO' => 'VARCHAR(255)',
                        'Memo_NO' => 'VARCHAR(255)',
                        'Datee' => 'LONGTEXT',
                        'Notes' => 'VARCHAR(255)'
                    ];

                    $save =  $db->save('EngnrData_table', $columns, $values);
                    if( $save){
                        echo json_encode(['save'=>'success']);
                    }
                    else{
                        echo json_encode(['error'=>'there was an error']);
                    }
                
            }
            if($function == "get-EngnrData"){
                
                    // echo json_encode(['save'=>"sucess"]);
                    $EngnrData = $db->get('EngnrData_table');
                
                    if( $EngnrData){
                        echo json_encode(['EngnrData'=>$EngnrData]);
                    }
                    else{
                        echo json_encode(['error'=>'there was an error']);
                    }
                
            }
            if($function == 'delete-EngnrData'){
                $delete = $db->delete('EngnrData_table',$_POST['EngnrDataId']);
                echo json_encode(['success'=>'Item deleted!']);
            }



            $From = isset($data['From']) ? $this->connect->real_escape_string($data['From']) : null;
            $To = isset($data['To']) ? $this->connect->real_escape_string($data['To']) : null;
            $Subject = isset($data['Subject']) ? $this->connect->real_escape_string($data['Subject']) : null;
            $Job_NO = isset($data['Job_NO']) ? $this->connect->real_escape_string($data['Job_NO']) : null;
            $Memo_NO = isset($data['Memo_NO']) ? $this->connect->real_escape_string($data['Memo_NO']) : null;
            $Date = isset($data['Date']) ? $this->connect->real_escape_string($data['Date']) : null;
            $Notes = isset($data['Notes']) ? $this->connect->real_escape_string($data['Notes']) : null;